# EchoTrip REDCowork import

Upload the provided ZIP as a Vite/React project. The ZIP root already contains
`package.json`, `src/`, `public/`, and the build configuration.

Use these commands if REDCowork asks for them:

- Install: `npm install`
- Build: `npm run build`
- Preview: `npm run dev -- --host 0.0.0.0`

The frontend is already configured in `public/echotrip/runtime-config.js` to use
the published EchoTrip API. Do not add `OPENAI_API_KEY` or any server secret to
REDCowork. Database, media storage, AI analysis, token limits, and anonymous
sessions continue to run on the existing backend.

After publishing, verify the flow with up to 10 photos:

1. Trips → 新建旅程 → 选择照片。
2. The local Timeline should open within five seconds.
3. The AI status pill should disappear after background enrichment finishes.
4. Refresh and confirm the trip and photos remain available.
