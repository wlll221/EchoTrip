# EchoTrip → REDCowork deployment contract

REDCowork hosts the static web interface. The independent EchoTrip API owns
database access, image storage, OpenAI calls, cost controls, and secrets.

## Runtime topology

```text
REDCowork web page
  └─ HTTPS + signed anonymous session
       └─ EchoTrip API
            ├─ D1: trips, photo metadata, Timeline, Moments, memories, usage
            ├─ R2: original photos, analysis previews, voice files
            └─ OpenAI Responses API: low-detail photo understanding only
```

The OpenAI key and session-signing secret must exist only in the API service.
They must never appear in `runtime-config.js`, browser storage, a REDCowork
prompt, or exported frontend source.

## Backend production settings

Set these server-side environment values:

| Variable | Purpose | Recommended initial value |
| --- | --- | --- |
| `OPENAI_API_KEY` | Photo understanding | secret |
| `OPENAI_VISION_MODEL` | Vision model | `gpt-4o` |
| `ECHOTRIP_SESSION_SECRET` | Signs anonymous sessions and photo links | random 32+ byte secret |
| `DAILY_AI_TOKEN_LIMIT` | Per-installation daily hard limit | `10000` |
| `MAX_PHOTOS_PER_TRIP` | Upload hard limit | `10` |
| `CORS_ALLOWED_ORIGINS` | Extra exact frontend origins | empty unless a new publish origin is introduced |

The Worker already allows the exact origins
`https://redcowork.xiaohongshu.com` and
`https://redcoworkdev.xiaohongshu.com`. It does not use wildcard CORS.

## REDCowork frontend setting

In the exported frontend, load `runtime-config.js` before `cloud-api.js` and set
only the public API origin:

```js
window.ECHOTRIP_CONFIG = {
  apiBase: "https://echotrip-ai-preview.liuhc2000.chatgpt.site"
};
```

Do not include `/api/v1` in `apiBase`; the client appends it. Same-origin local
and private previews keep `apiBase` empty.

## Security and data behavior

- The browser creates an anonymous installation identity and exchanges it for a
  signed, 30-day API session. An expired session is refreshed once automatically.
- Protected API routes ignore the installation ID supplied in the request body
  when signed sessions are enabled and use the signed identity instead.
- Photo responses use one-hour, photo-scoped signed URLs, so REDCowork `<img>`
  elements work cross-origin without exposing a general API token.
- AI analysis is cached per photo and analysis version. Timeline, Moment,
  Memory Card, voice transcription, and Echo reasons do not call OpenAI.
- The API rejects unapproved origins, over-limit photo uploads, and analysis
  after the daily token budget is reached.

## Release verification

Before a production switch:

1. Confirm D1 and R2 bindings plus `OPENAI_API_KEY` are healthy.
2. Set `ECHOTRIP_SESSION_SECRET` before making the API public.
3. Publish the API and insert its origin into REDCowork `runtime-config.js`.
4. From the published REDCowork page, create a trip and upload photos.
5. Refresh the page and verify signed photo URLs still render.
6. Verify Timeline photo counts equal uploaded counts and every photo appears in
   exactly one Timeline node.
7. Save a voice/text memory and confirm it persists after refresh.
8. Grant foreground location once and verify Echo returns either a reasoned
   match or an explicit no-match result.
9. Check `ai_usage_events`; only `photo_vision` rows should exist.
10. Test an unapproved origin and an expired/bad token; both must be rejected.

The current Sites API is publicly reachable at the origin above. Its D1, R2,
OpenAI key, session secret, daily 10,000-token limit, and 10-photo trip limit
remain server-side. REDCowork only hosts the frontend and must not receive or
store those secrets.
