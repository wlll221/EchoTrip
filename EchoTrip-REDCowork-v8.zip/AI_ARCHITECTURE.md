# EchoTrip minimum-token AI architecture

## Decision

The product runtime does **not** use a conversational main agent plus several
LLM sub-agents. The main coordinator is deterministic application code. It
passes a compact, versioned `PhotoAnalysis` record to Timeline, Moment and Echo
modules. This prevents repeated context transmission and makes costs and
failures predictable.

Only photo understanding calls the OpenAI API in the MVP. Everything else is
metadata processing, deterministic scoring/templates, browser speech
recognition, or on-device inference.

## End-to-end pipeline

1. **Ingest (0 API tokens)**
   - Keep the original photo in R2.
   - Read capture time and GPS in the browser.
   - Create a small analysis JPEG; the original is never sent to the model.
2. **Place resolution (0 API tokens)**
   - Reverse-geocode GPS using Nominatim.
   - Round coordinates and cache Chinese place results in D1.
3. **Photo understanding (the only paid AI step)**
   - Up to 16 low-detail analysis images in one Responses API request.
   - Strict compact schema; no prose caption and no per-photo generated
     question.
   - Results are cached on each photo under `vision-v3-lean`; repeat reads do
     not call the model.
4. **Timeline (0 API tokens)**
   - Cluster by day, time continuity, region/GPS, place, scene, semantic event,
     activity and landmark.
   - Distance is one signal, never a hard 600 m boundary.
   - Every uploaded photo belongs to exactly one Timeline node.
5. **Moment recommendations (0 API tokens)**
   - Rank compact visual salience and diversify across Timeline nodes.
   - Build each question from the Timeline title/place and photo
     subject/activity using deterministic Chinese templates.
6. **Voice and Memory Card (0 API tokens)**
   - Browser SpeechRecognition first; on-device Whisper fallback; manual text
     remains available.
   - Preserve the user's words. Card title and context come from the selected
     Moment and Timeline evidence.
7. **Echo (0 API tokens)**
   - Score current location, weather and anniversary proximity against stored
     photos.
   - Generate the reason from the strongest matched evidence and photo hook.

## The one production prompt

```text
按 PHOTO_ID 顺序分析旅行照片。只写可见事实，中文短语；不认人。
地点或地标不确定填 null。event_title_zh 用不超过8个汉字概括活动而非地名；
memory_hook 写最值得追问的可见线索。
```

The strict response fields are:

- `photo_id`
- `scene`
- `subject` (max 24 characters)
- `activities` (max 3 short items)
- `landmark_guess`
- `event_title_zh` (max 8 Chinese characters)
- `place_name_zh`
- `semantic_group`
- `weather`
- `memory_score`
- `memory_hook` (max 24 characters)
- `confidence`

## Moment question templates

No LLM prompt is used. Examples of real runtime templates:

- Food: `在{place}{timelineTitle}时，{subject}最让你记住的味道或细节是什么？`
- People: `在{place}{timelineTitle}时，和你一起经历{subject}的人当时说了什么？`
- Nature: `在{place}{timelineTitle}时，看到{subject}的第一感受是什么？`
- Sightseeing: `在{place}{timelineTitle}时，{subject}和你原先想象的一样吗？`
- Fallback: `关于{place}的{timelineTitle}，{subject}背后发生了什么？`

These questions combine final Timeline context and per-photo visual evidence;
the vision model is not asked to invent a question before the Timeline exists.

## Echo strategy and reasons

Candidate score currently combines:

- visual memory score;
- current weather matching the photo;
- distance from the current coarse location;
- proximity to the old calendar date.

At least one current-context match is required. The reason is assembled from
evidence, for example:

```text
今天与照片里同为雨天；你再次靠近贝尔格莱德。因此把「河畔观鸟」这张照片送回给你。
```

This is deliberately not another text-model call.

## Cost guardrails

- Maximum 16 photos per paid request.
- `detail: low`, `store: false`, strict schema and explicit output-token cap.
- One analysis version per photo prevents repeat charges.
- Client stops if analysis makes no progress; no infinite retry loop.
- `ai_usage_events` stores model, input/output/cached tokens and image count for
  every successful vision batch.
- Speech, Memory Card, Timeline, Moment and Echo must issue zero OpenAI calls.

Expected API request count for a new trip containing `N` photos:

```text
ceil(N / 16) vision requests + 0 other OpenAI requests
```

