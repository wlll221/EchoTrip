import assert from "node:assert/strict";
import test from "node:test";
import { __analyzeWithVisionForTest as analyzeWithVision } from "../worker/index.js";

test("vision uses one low-detail compact structured request and returns usage", async () => {
  const photos = Array.from({ length:4 }, (_, index) => ({
    id:`photo_${index + 1}`,
    object_key:`original/${index + 1}.jpg`,
    analysis_object_key:`analysis/${index + 1}.jpg`,
    mime_type:"image/jpeg",
    analysis_mime_type:"image/jpeg",
  }));
  let requestBody;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (_url, init) => {
    requestBody = JSON.parse(init.body);
    const result = photos.map((photo) => ({
      photo_id:photo.id, scene:"nature", subject:"湖边树林", activities:["散步"], landmark_guess:null,
      event_title_zh:"湖边散步", place_name_zh:null, semantic_group:"nature", weather:"sunny",
      memory_score:.7, memory_hook:"湖面的倒影", confidence:.8,
    }));
    return Response.json({ model:"gpt-4o-test", usage:{ input_tokens:500, output_tokens:200, input_tokens_details:{ cached_tokens:0 } }, output:[{ type:"message", content:[{ type:"output_text", text:JSON.stringify({ photos:result }) }] }] });
  };
  try {
    const result = await analyzeWithVision({
      OPENAI_API_KEY:"test-only",
      MEDIA:{ get:async () => ({ arrayBuffer:async () => new Uint8Array([1, 2, 3]).buffer }) },
    }, photos);
    assert.equal(result.photos.length, photos.length);
    assert.equal(result.usage.input_tokens, 500);
    assert.equal(requestBody.model, "gpt-4o");
    assert.equal(requestBody.store, false);
    assert.equal(requestBody.input[0].content.filter((item) => item.type === "input_image").length, photos.length);
    assert.ok(requestBody.input[0].content.filter((item) => item.type === "input_image").every((item) => item.detail === "low"));
    assert.equal(requestBody.text.format.type, "json_schema");
    assert.equal(requestBody.text.format.strict, true);
    assert.ok(requestBody.max_output_tokens <= photos.length * 220 || requestBody.max_output_tokens === 1200);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
