import assert from "node:assert/strict";
import { access } from "node:fs/promises";
import test from "node:test";
import worker, { __analyzeWithVisionRecoveryForTest, __validatedVisionResultsForTest } from "../worker/index.js";

function visionPhoto(photo_id) {
  return { photo_id, scene:"street", subject:"街景", activities:["散步"], landmark_guess:null, event_title_zh:"街区漫步", place_name_zh:null, semantic_group:"sightseeing", weather:"sunny", memory_score:.6, memory_hook:"当时看见了什么", confidence:.8 };
}

test("keeps valid vision rows and reports only missing or duplicated photo ids", () => {
  const requested = [{ id:"p1" }, { id:"p2" }, { id:"p3" }];
  const result = __validatedVisionResultsForTest(requested, [visionPhoto("p1"), visionPhoto("p2"), visionPhoto("p2"), visionPhoto("unknown")]);
  assert.deepEqual(result.accepted.map((item) => item.photo_id), ["p1"]);
  assert.deepEqual(result.missing.map((item) => item.id), ["p2", "p3"]);
});

test("vision recovery retries only the missing photos", async () => {
  const originalFetch = globalThis.fetch;
  const calls = [];
  const batches = [];
  globalThis.fetch = async (_url, options) => {
    const body = JSON.parse(options.body);
    const ids = body.input[0].content.filter((item) => item.type === "input_text" && item.text.startsWith("PHOTO_ID:"))
      .map((item) => item.text.replace("PHOTO_ID:", "").trim());
    calls.push(ids);
    const returned = calls.length === 1 ? [visionPhoto("p1"), visionPhoto("p3")] : ids.map(visionPhoto);
    return Response.json({ output_text:JSON.stringify({ photos:returned }), usage:{ input_tokens:10, output_tokens:5 }, model:"test-model" });
  };
  try {
    const photos = ["p1", "p2", "p3"].map((id) => ({ id, object_key:id, mime_type:"image/jpeg" }));
    const result = await __analyzeWithVisionRecoveryForTest({
      OPENAI_API_KEY:"test-key",
      MEDIA:{ get:async () => ({ arrayBuffer:async () => new Uint8Array([1, 2, 3]).buffer }) },
    }, photos, { onBatch:async ({ batch, accepted }) => batches.push({ requested:batch.map((item) => item.id), accepted:accepted.map((item) => item.photo_id) }) });
    assert.deepEqual(calls, [["p1", "p2", "p3"], ["p2"]]);
    assert.deepEqual(batches, [
      { requested:["p1", "p2", "p3"], accepted:["p1", "p3"] },
      { requested:["p2"], accepted:["p2"] },
    ]);
    assert.deepEqual(result, { analyzed:3, calls:2 });
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("serves existing static assets without a fallback", async () => {
  const calls = [];
  const response = await worker.fetch(new Request("https://example.test/assets/app.js"), {
    ASSETS: {
      fetch: async (request) => {
        calls.push(new URL(request.url).pathname);
        return new Response("asset", { status: 200 });
      },
    },
  });

  assert.equal(response.status, 200);
  assert.deepEqual(calls, ["/assets/app.js"]);
});

test("falls back to index.html for an unknown app route", async () => {
  const calls = [];
  const response = await worker.fetch(
    new Request("https://example.test/flow/step-two?source=share", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async (request) => {
          const url = new URL(request.url);
          calls.push(url.pathname + url.search);
          return new Response(url.pathname === "/index.html" ? "app" : "missing", {
            status: url.pathname === "/index.html" ? 200 : 404,
          });
        },
      },
    },
  );

  assert.equal(response.status, 200);
  assert.deepEqual(calls, ["/flow/step-two?source=share", "/index.html"]);
});

test("does not turn write requests into the app shell", async () => {
  for (const request of [new Request("https://example.test/flow", { method: "POST", headers: { accept: "text/html" } })]) {
    let calls = 0;
    const response = await worker.fetch(request, {
      ASSETS: {
        fetch: async () => {
          calls += 1;
          return new Response("missing", { status: 404 });
        },
      },
    });

    assert.equal(response.status, 404);
    assert.equal(calls, 1);
  }
});

test("serves API health and returns JSON 404s without touching static assets", async () => {
  let assetCalls = 0;
  const statement = { bind(){ return this; }, async run(){ return {}; }, async first(){ return null; }, async all(){ return { results: [] }; } };
  const env = {
    DB: { prepare(){ return Object.create(statement); }, async batch(){ return []; } },
    MEDIA: { get: async () => null },
    ASSETS: { fetch: async () => { assetCalls += 1; return new Response("missing", { status: 404 }); } },
  };

  const health = await worker.fetch(new Request("https://example.test/api/v1/health"), env);
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), {
    ok: true,
    storage: { d1: true, r2: true },
    aiConfigured: false,
    capabilities: { vision: false, transcription: "local-only", memoryGeneration: "deterministic", echoRecommendation: "deterministic" },
  });

  const missing = await worker.fetch(new Request("https://example.test/api/v1/missing"), env);
  assert.equal(missing.status, 404);
  assert.equal((await missing.json()).error.code, "NOT_FOUND");
  assert.equal(assetCalls, 0);
});

test("cloud audio transcription is disabled because speech stays local", async () => {
  const statement = { bind(){ return this; }, async run(){ return {}; }, async first(){ return null; }, async all(){ return { results: [] }; } };
  const env = {
    DB: { prepare(){ return Object.create(statement); }, async batch(){ return []; } },
    MEDIA: {},
    ASSETS: { fetch: async () => new Response("missing", { status: 404 }) },
  };
  const form = new FormData();
  form.set("installationId", "install_test");
  form.set("audio", new File([new Uint8Array([1, 2, 3])], "memory.webm", { type:"audio/webm" }));
  const response = await worker.fetch(new Request("https://example.test/api/v1/audio/transcriptions", { method:"POST", body:form }), env);
  assert.equal(response.status, 410);
  assert.equal((await response.json()).error.code, "LOCAL_TRANSCRIPTION_ONLY");
});

test("allows REDCowork CORS preflight but rejects unknown web origins", async () => {
  const allowed = await worker.fetch(new Request("https://api.example.test/api/v1/trips", {
    method:"OPTIONS",
    headers:{ origin:"https://redcoworkdev.xiaohongshu.com", "access-control-request-method":"POST" },
  }), {});
  assert.equal(allowed.status, 204);
  assert.equal(allowed.headers.get("access-control-allow-origin"), "https://redcoworkdev.xiaohongshu.com");

  const blocked = await worker.fetch(new Request("https://api.example.test/api/v1/trips", {
    method:"OPTIONS",
    headers:{ origin:"https://attacker.example", "access-control-request-method":"POST" },
  }), {});
  assert.equal(blocked.status, 403);
  assert.equal(blocked.headers.get("access-control-allow-origin"), null);
});

test("issues a signed anonymous session and requires it on protected APIs", async () => {
  const statement = { bind(){ return this; }, async run(){ return {}; }, async first(){ return null; }, async all(){ return { results: [] }; } };
  const env = {
    ECHOTRIP_SESSION_SECRET:"test-only-session-secret",
    DB:{ prepare(){ return Object.create(statement); }, async batch(){ return []; } },
    MEDIA:{}, ASSETS:{ fetch:async () => new Response("missing", { status:404 }) },
  };
  const sessionResponse = await worker.fetch(new Request("https://api.example.test/api/v1/sessions/anonymous", {
    method:"POST", headers:{ "content-type":"application/json", origin:"https://redcowork.xiaohongshu.com" },
    body:JSON.stringify({ installationId:"install_12345678-1234-1234-1234-123456789012", locale:"zh-CN" }),
  }), env);
  assert.equal(sessionResponse.status, 201);
  assert.equal(sessionResponse.headers.get("access-control-allow-origin"), "https://redcowork.xiaohongshu.com");
  const session = await sessionResponse.json();
  assert.match(session.token, /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);

  const unauthorized = await worker.fetch(new Request("https://api.example.test/api/v1/echoes"), env);
  assert.equal(unauthorized.status, 401);
  assert.equal((await unauthorized.json()).error.code, "SESSION_REQUIRED");

  const authorized = await worker.fetch(new Request("https://api.example.test/api/v1/echoes", {
    headers:{ authorization:`Bearer ${session.token}` },
  }), env);
  assert.equal(authorized.status, 200);
  assert.deepEqual((await authorized.json()).echoes, []);
});

test("returns absolute photo-scoped URLs that load without an authorization header", async () => {
  const installationId = "install_aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee";
  const statement = {
    sql:"", args:[],
    bind(...args){ this.args = args; return this; }, async run(){ return {}; },
    async first(){
      if(this.sql.includes("FROM trips WHERE")) return { id:"trip_1", installation_id:installationId, status:"ready" };
      if(this.sql.includes("FROM photos WHERE id=")) return { object_key:"photos/photo_1.jpg", mime_type:"image/jpeg" };
      return null;
    },
    async all(){
      if(this.sql.includes("FROM photos WHERE trip_id=")) return { results:[{ id:"photo_1", original_name:"one.jpg", mime_type:"image/jpeg", analysis_status:"complete", analysis_json:"{}", sort_order:0 }] };
      return { results:[] };
    },
  };
  const env = {
    ECHOTRIP_SESSION_SECRET:"test-only-session-secret",
    DB:{ prepare(sql){ return Object.assign(Object.create(statement), { sql, args:[] }); }, async batch(){ return []; } },
    MEDIA:{ get:async () => ({ body:new Uint8Array([1, 2, 3]) }) },
    ASSETS:{ fetch:async () => new Response("missing", { status:404 }) },
  };
  const session = await (await worker.fetch(new Request("https://api.example.test/api/v1/sessions/anonymous", {
    method:"POST", headers:{ "content-type":"application/json" }, body:JSON.stringify({ installationId }),
  }), env)).json();
  const tripResponse = await worker.fetch(new Request("https://api.example.test/api/v1/trips/trip_1", {
    headers:{ authorization:`Bearer ${session.token}` },
  }), env);
  assert.equal(tripResponse.status, 200);
  const trip = (await tripResponse.json()).trip;
  assert.match(trip.photos[0].mediaUrl, /^https:\/\/api\.example\.test\/api\/v1\/photos\/photo_1\/content\?media_token=/);

  const photoResponse = await worker.fetch(new Request(trip.photos[0].mediaUrl), env);
  assert.equal(photoResponse.status, 200);
  assert.equal(photoResponse.headers.get("content-type"), "image/jpeg");
  assert.deepEqual(new Uint8Array(await photoResponse.arrayBuffer()), new Uint8Array([1, 2, 3]));
});

test("emits the files required by Sites packaging", async () => {
  await access(new URL("../dist/client/index.html", import.meta.url));
  await access(new URL("../dist/server/index.js", import.meta.url));
  await access(new URL("../dist/.openai/hosting.json", import.meta.url));
});
