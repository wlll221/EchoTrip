import assert from "node:assert/strict";
import test from "node:test";
import { __buildTimelineForTest as buildTimeline, __buildMomentsForTest as buildMoments } from "../worker/index.js";

const photo = (id, takenAt, latitude, longitude, locationName, semanticGroup = "sightseeing", eventTitle = "城市地标漫游") => ({
  id,
  taken_at: takenAt,
  latitude,
  longitude,
  location_name: locationName,
  city: "东京",
  country_code: "JP",
  sort_order: Number(id.replace(/\D/g, "")) || 0,
  analysis_json: JSON.stringify({ scene: "street", setting: "城市街道", caption: "旅行照片", semantic_group: semanticGroup, event_title_zh: eventTitle, place_name_zh: null, activities: ["步行"], confidence: .9 }),
});

const aiLocatedPhoto = (id, takenAt, landmarkGuess) => ({
  id,
  taken_at: takenAt,
  latitude: null,
  longitude: null,
  location_name: null,
  sort_order: Number(id.replace(/\D/g, "")) || 0,
  analysis_json: JSON.stringify({ scene: "landmark", setting: "景点", caption: "旅行照片", landmark_guess: landmarkGuess, confidence: .8 }),
});

test("timeline combines one continuous travel event instead of splitting at a fixed distance", () => {
  const photos = [
    photo("p1", "2026-03-03T09:00:00.000Z", 35.6586, 139.7454, "东京 · 芝公园"),
    photo("p2", "2026-03-03T09:08:00.000Z", 35.6587, 139.7455, "东京 · 芝公园"),
    photo("p3", "2026-03-03T09:45:00.000Z", 35.7101, 139.8107, "东京 · 押上"),
    photo("p4", "2026-03-03T09:51:00.000Z", 35.7102, 139.8108, "东京 · 押上"),
    photo("p5", "2026-03-03T11:20:00.000Z", 35.6764, 139.6993, "东京 · 明治神宫"),
    photo("p6", "2026-03-03T11:34:00.000Z", 35.6765, 139.6992, "东京 · 明治神宫"),
    photo("p7", "2026-03-03T13:00:00.000Z", 35.6595, 139.7005, "东京 · 涩谷"),
    photo("p8", "2026-03-03T13:15:00.000Z", 35.6596, 139.7006, "东京 · 涩谷"),
    photo("p9", "2026-03-03T15:10:00.000Z", 35.6655, 139.7122, "东京 · 表参道", "shopping", "街区购物"),
    photo("p10", "2026-03-03T15:22:00.000Z", 35.6656, 139.7123, "东京 · 表参道", "shopping", "街区购物"),
    photo("p11", "2026-03-03T19:00:00.000Z", 35.6938, 139.7034, "东京 · 新宿", "food", "品尝当地美食"),
    photo("p12", "2026-03-03T19:12:00.000Z", 35.6939, 139.7035, "东京 · 新宿", "food", "品尝当地美食"),
  ];
  const timeline = buildTimeline(photos);
  assert.equal(timeline.length, 3);
  assert.deepEqual(timeline.map((node) => node.photo_ids.length), [8, 2, 2]);
  assert.deepEqual(timeline.map((node) => node.title), ["城市地标漫游", "街区购物", "品尝当地美食"]);
  assert.equal(timeline.reduce((sum, node) => sum + node.photo_ids.length, 0), photos.length);
  assert.equal(new Set(timeline.flatMap((node) => node.photo_ids)).size, photos.length);
});

test("timeline still creates coherent time blocks when GPS is missing", () => {
  const photos = [
    photo("p1", "2026-03-03T09:00:00.000Z", null, null, "咖啡馆"),
    photo("p2", "2026-03-03T10:10:00.000Z", null, null, "咖啡馆"),
    photo("p3", "2026-03-03T10:15:00.000Z", null, null, "美术馆"),
    photo("p4", "2026-03-03T10:45:00.000Z", null, null, null),
    photo("p5", "2026-03-04T09:00:00.000Z", null, null, null),
  ];
  const timeline = buildTimeline(photos);
  assert.equal(timeline.length, 2);
  assert.deepEqual(timeline[0].photo_ids, ["p1", "p2", "p3", "p4"]);
  assert.equal(timeline.reduce((sum, node) => sum + node.photo_ids.length, 0), photos.length);
});

test("timeline resolves foreign-script coordinates to a known Chinese district", () => {
  const item = photo("p1", "2026-03-04T08:00:00.000Z", 44.8125, 20.4612, "Градско");
  item.city = "Београд";
  item.country_code = "RS";
  item.analysis_json = JSON.stringify({ scene:"animal", semantic_group:"nature", event_title_zh:"公园观鸟", place_name_zh:null, activities:["观鸟"], confidence:.8 });
  const timeline = buildTimeline([item]);
  assert.equal(timeline[0].title, "公园观鸟");
  assert.match(timeline[0].place_name, /^[\u3400-\u9fff]/);
  assert.equal(timeline[0].place_name, "贝尔格莱德");
});

test("timeline recognizes Zemun and Zlatibor from aliases or coordinates", () => {
  const zemun = photo("p1", "2026-03-04T08:00:00.000Z", 44.845, 20.39, "Градско");
  zemun.city = "Београд"; zemun.country_code = "RS";
  const zlatibor = photo("p2", "2026-03-05T11:00:00.000Z", null, null, "Zlatibor");
  zlatibor.city = "Zlatibor"; zlatibor.country_code = "RS";
  const timeline = buildTimeline([zemun, zlatibor]);
  assert.deepEqual(timeline.map((node) => node.place_name), ["泽蒙", "兹拉蒂博尔"]);
});

test("timeline titles are unique within one day even when AI suggestions repeat", () => {
  const photos = [
    photo("p1", "2026-03-04T08:00:00.000Z", 44.845, 20.39, "Zemun"),
    photo("p2", "2026-03-04T12:00:00.000Z", 44.846, 20.391, "Zemun"),
    photo("p3", "2026-03-04T16:00:00.000Z", 44.847, 20.392, "Zemun"),
  ];
  photos.forEach((item) => { item.city = "Zemun"; item.country_code = "RS"; });
  const timeline = buildTimeline(photos);
  assert.equal(timeline.length, 3);
  assert.equal(new Set(timeline.map((node) => node.title)).size, 3);
  assert.ok(timeline.every((node) => Array.from(node.title).length <= 8));
});

test("timeline infers a missing district only when nearby nodes agree", () => {
  const first = photo("p1", "2026-03-04T08:00:00.000Z", 44.845, 20.39, "Zemun", "nature", "公园观鸟");
  const missing = photo("p2", "2026-03-04T09:40:00.000Z", null, null, null, "food", "当地午餐");
  const last = photo("p3", "2026-03-04T11:20:00.000Z", 44.846, 20.391, "Zemun", "sightseeing", "小镇眺望");
  [first, missing, last].forEach((item) => { item.city = null; item.country_code = "RS"; });
  first.analysis_json = JSON.stringify({ scene:"animal", semantic_group:"nature", event_title_zh:"公园观鸟", place_name_zh:null, activities:["观鸟"], confidence:.8 });
  missing.analysis_json = JSON.stringify({ scene:"food", semantic_group:"food", event_title_zh:"当地午餐", place_name_zh:null, activities:["用餐"], confidence:.8 });
  last.analysis_json = JSON.stringify({ scene:"architecture", semantic_group:"sightseeing", event_title_zh:"小镇眺望", place_name_zh:null, activities:["参观"], confidence:.8 });
  const timeline = buildTimeline([first, missing, last]);
  assert.equal(timeline.length, 3);
  assert.deepEqual(timeline.map((node) => node.place_name), ["泽蒙", "泽蒙", "泽蒙"]);
});

test("timeline can group a repeated visual landmark without inventing GPS", () => {
  const photos = [
    aiLocatedPhoto("p1", "2026-03-03T09:00:00.000Z", "浅草寺"),
    aiLocatedPhoto("p2", "2026-03-03T09:35:00.000Z", "浅草寺"),
    aiLocatedPhoto("p3", "2026-03-03T10:00:00.000Z", "东京晴空塔"),
  ];
  const timeline = buildTimeline(photos);
  assert.equal(timeline.length, 2);
  assert.deepEqual(timeline[0].photo_ids, ["p1", "p2"]);
  assert.equal(timeline[0].place_name, "浅草寺");
  assert.equal(timeline.reduce((sum, node) => sum + node.photo_ids.length, 0), photos.length);
});

test("moment questions combine final timeline context with photo understanding without another AI call", () => {
  const photos = [
    photo("p1", "2026-03-03T12:00:00.000Z", 35.67, 139.70, "东京 · 涩谷", "food", "当地午餐"),
    photo("p2", "2026-03-03T12:08:00.000Z", 35.67, 139.70, "东京 · 涩谷", "food", "当地午餐"),
    photo("p3", "2026-03-03T17:30:00.000Z", 35.68, 139.71, "东京 · 代代木", "nature", "公园散步"),
  ];
  photos[0].analysis_json = JSON.stringify({ scene:"food", subject:"热汤面", activities:["用餐"], semantic_group:"food", event_title_zh:"当地午餐", memory_score:.9, memory_hook:"桌上的热汤面", weather:"indoor", confidence:.9 });
  photos[1].analysis_json = JSON.stringify({ scene:"people", subject:"同行朋友", activities:["聚餐"], semantic_group:"food", event_title_zh:"当地午餐", memory_score:.7, memory_hook:"一起吃饭的人", weather:"indoor", confidence:.9 });
  photos[2].analysis_json = JSON.stringify({ scene:"nature", subject:"落日树林", activities:["散步"], semantic_group:"nature", event_title_zh:"公园散步", memory_score:.8, memory_hook:"落日穿过树林", weather:"sunny", confidence:.9 });
  const timeline = buildTimeline(photos);
  const moments = buildMoments(photos, timeline);
  assert.ok(moments.length >= 2);
  assert.ok(moments.some((moment) => moment.prompt.includes("东京") && moment.prompt.includes("热汤面")));
  assert.ok(moments.some((moment) => moment.evidence.timeline_title && moment.evidence.timeline_id));
  assert.ok(moments.every((moment) => moments.filter((other) => other.photo_id === moment.photo_id).length === 1));
});
