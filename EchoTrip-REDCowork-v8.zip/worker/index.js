const API_PREFIX = "/api/v1";
const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;
const MAX_AUDIO_BYTES = 20 * 1024 * 1024;
const ANALYSIS_BATCH_SIZE = 16;
const ANALYSIS_VERSION = "vision-v3-lean";
const DEFAULT_DAILY_AI_TOKEN_LIMIT = 10000;
const DEFAULT_MAX_PHOTOS_PER_TRIP = 10;
const SESSION_TTL_SECONDS = 30 * 24 * 60 * 60;
const MEDIA_TTL_SECONDS = 60 * 60;

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS installations (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, timezone TEXT, locale TEXT)`,
  `CREATE TABLE IF NOT EXISTS trips (id TEXT PRIMARY KEY, installation_id TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', destination TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'draft', start_date TEXT, end_date TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS photos (id TEXT PRIMARY KEY, trip_id TEXT NOT NULL, installation_id TEXT NOT NULL, object_key TEXT NOT NULL UNIQUE, analysis_object_key TEXT, original_name TEXT, mime_type TEXT NOT NULL, analysis_mime_type TEXT, byte_size INTEGER NOT NULL, width INTEGER, height INTEGER, taken_at TEXT, time_source TEXT, latitude REAL, longitude REAL, altitude REAL, location_source TEXT, location_name TEXT, city TEXT, country TEXT, country_code TEXT, sort_order INTEGER NOT NULL DEFAULT 0, analysis_status TEXT NOT NULL DEFAULT 'pending', analysis_json TEXT, analysis_version TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS geocode_cache (coordinate_key TEXT PRIMARY KEY, latitude REAL NOT NULL, longitude REAL NOT NULL, location_name TEXT, city TEXT, country TEXT, country_code TEXT, provider TEXT NOT NULL, response_json TEXT, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS analysis_jobs (id TEXT PRIMARY KEY, trip_id TEXT NOT NULL, installation_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued', provider_job_id TEXT, error_code TEXT, error_message TEXT, created_at TEXT NOT NULL, started_at TEXT, completed_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS timeline_nodes (id TEXT PRIMARY KEY, trip_id TEXT NOT NULL, installation_id TEXT NOT NULL, starts_at TEXT, ends_at TEXT, latitude REAL, longitude REAL, place_name TEXT, title TEXT NOT NULL, category TEXT NOT NULL, photo_ids_json TEXT NOT NULL, sort_order INTEGER NOT NULL, confidence REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS moments (id TEXT PRIMARY KEY, trip_id TEXT NOT NULL, installation_id TEXT NOT NULL, photo_id TEXT NOT NULL, title TEXT NOT NULL, reason TEXT NOT NULL, prompt TEXT NOT NULL, score REAL NOT NULL, evidence_json TEXT NOT NULL, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS memory_cards (id TEXT PRIMARY KEY, moment_id TEXT NOT NULL, trip_id TEXT NOT NULL, installation_id TEXT NOT NULL, transcript TEXT, edited_memory TEXT, audio_object_key TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS memory_card_payloads (card_id TEXT PRIMARY KEY, payload_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS context_events (id TEXT PRIMARY KEY, installation_id TEXT NOT NULL, event_type TEXT NOT NULL, occurred_at TEXT NOT NULL, latitude_coarse REAL, longitude_coarse REAL, weather_code TEXT, temperature_c REAL, source TEXT NOT NULL, payload_json TEXT, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS echoes (id TEXT PRIMARY KEY, installation_id TEXT NOT NULL, memory_card_id TEXT, photo_id TEXT NOT NULL, trigger_event_id TEXT, reason TEXT NOT NULL, evidence_json TEXT NOT NULL, score REAL NOT NULL, status TEXT NOT NULL DEFAULT 'ready', created_at TEXT NOT NULL, delivered_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS ai_usage_events (id TEXT PRIMARY KEY, installation_id TEXT NOT NULL, trip_id TEXT, feature TEXT NOT NULL, model TEXT NOT NULL, input_tokens INTEGER NOT NULL DEFAULT 0, output_tokens INTEGER NOT NULL DEFAULT 0, cached_tokens INTEGER NOT NULL DEFAULT 0, image_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_trips_installation_updated ON trips(installation_id, updated_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_photos_trip_sort ON photos(trip_id, sort_order)`,
  `CREATE INDEX IF NOT EXISTS idx_photos_analysis_pending ON photos(trip_id, analysis_status) WHERE analysis_status != 'complete'`,
  `CREATE INDEX IF NOT EXISTS idx_jobs_trip_created ON analysis_jobs(trip_id, created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_timeline_trip_sort ON timeline_nodes(trip_id, sort_order)`,
  `CREATE INDEX IF NOT EXISTS idx_moments_trip_score ON moments(trip_id, score DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_context_installation_time ON context_events(installation_id, occurred_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_echoes_installation_status ON echoes(installation_id, status, created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_geocode_cache_created ON geocode_cache(created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_ai_usage_installation_time ON ai_usage_events(installation_id, created_at DESC)`,
];

let schemaReady = false;
let lastGeocodeAt = 0;
let geocodeQueue = Promise.resolve();

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers },
  });
}

function error(code, message, status = 400, details) {
  return json({ error: { code, message, ...(details ? { details } : {}) } }, status);
}

function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }
function now() { return new Date().toISOString(); }
function requiredInstallation(request, body) {
  const url = new URL(request.url);
  return request.headers.get("x-echotrip-installation") || body?.installationId || body?.installation_id || url.searchParams.get("installation") || "";
}

function utf8(value) { return new TextEncoder().encode(value); }
function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function fromBase64Url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  return Uint8Array.from(atob(normalized), (character) => character.charCodeAt(0));
}
async function hmac(env, value) {
  const key = await crypto.subtle.importKey("raw", utf8(env.ECHOTRIP_SESSION_SECRET), { name:"HMAC", hash:"SHA-256" }, false, ["sign", "verify"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, utf8(value)));
}
async function signPayload(env, payload) {
  const encoded = base64Url(utf8(JSON.stringify(payload)));
  return `${encoded}.${base64Url(await hmac(env, encoded))}`;
}
async function verifyPayload(env, token, expectedType) {
  if (!token || !env.ECHOTRIP_SESSION_SECRET) return null;
  const [encoded, signature, extra] = token.split(".");
  if (!encoded || !signature || extra) return null;
  const expected = await hmac(env, encoded); const actual = fromBase64Url(signature);
  if (expected.length !== actual.length) return null;
  let mismatch = 0; for (let index = 0; index < expected.length; index += 1) mismatch |= expected[index] ^ actual[index];
  if (mismatch) return null;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromBase64Url(encoded)));
    if (payload.type !== expectedType || Number(payload.exp || 0) <= Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch { return null; }
}
function bearerToken(request) {
  const header = request.headers.get("authorization") || "";
  return header.toLowerCase().startsWith("bearer ") ? header.slice(7).trim() : "";
}
async function createAnonymousSession(request, env) {
  const body = await readJson(request) || {};
  const candidate = String(body.installationId || "");
  const installationId = /^install_[a-z0-9-]{16,80}$/i.test(candidate) ? candidate : id("install");
  await touchInstallation(env, installationId, body);
  if (!env.ECHOTRIP_SESSION_SECRET) return json({ installationId, token:null, security:"legacy-local" }, 201);
  const issuedAt = Math.floor(Date.now() / 1000);
  const token = await signPayload(env, { type:"session", installationId, iat:issuedAt, exp:issuedAt + SESSION_TTL_SECONDS });
  return json({ installationId, token, expiresAt:new Date((issuedAt + SESSION_TTL_SECONDS) * 1000).toISOString() }, 201);
}
async function authorizeApiRequest(request, env) {
  if (!env.ECHOTRIP_SESSION_SECRET) return request;
  const payload = await verifyPayload(env, bearerToken(request), "session");
  if (!payload?.installationId) return null;
  const headers = new Headers(request.headers); headers.set("x-echotrip-installation", payload.installationId);
  return new Request(request, { headers });
}
function allowedOrigins(env) {
  return new Set([
    "https://redcowork.xiaohongshu.com",
    "https://redcoworkdev.xiaohongshu.com",
    ...String(env.CORS_ALLOWED_ORIGINS || "").split(",").map((item) => item.trim()).filter(Boolean),
  ]);
}
function corsHeaders(request, env) {
  const origin = request.headers.get("origin");
  if (!origin) return {};
  const local = /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(origin);
  if (!local && !allowedOrigins(env).has(origin)) return {};
  return {
    "access-control-allow-origin":origin,
    "access-control-allow-methods":"GET, POST, OPTIONS",
    "access-control-allow-headers":"Authorization, Content-Type, X-EchoTrip-Installation, Accept-Language",
    "access-control-max-age":"86400",
    "vary":"Origin",
  };
}
function withCors(response, request, env) {
  const headers = new Headers(response.headers);
  for (const [name, value] of Object.entries(corsHeaders(request, env))) headers.set(name, value);
  return new Response(response.body, { status:response.status, statusText:response.statusText, headers });
}

async function ensureSchema(env) {
  if (schemaReady) return;
  if (!env.DB) throw new Error("D1 binding DB is not configured");
  await env.DB.batch(SCHEMA.map((statement) => env.DB.prepare(statement)));
  schemaReady = true;
}

async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}

async function touchInstallation(env, installationId, body = {}) {
  const timestamp = now();
  await env.DB.prepare(
    `INSERT INTO installations (id, created_at, last_seen_at, timezone, locale)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET last_seen_at=excluded.last_seen_at,
       timezone=COALESCE(excluded.timezone, installations.timezone),
       locale=COALESCE(excluded.locale, installations.locale)`,
  ).bind(installationId, timestamp, timestamp, body.timezone || null, body.locale || null).run();
}

async function assertTripOwner(env, tripId, installationId) {
  return env.DB.prepare("SELECT id FROM trips WHERE id=? AND installation_id=?").bind(tripId, installationId).first();
}

function safeNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
function hasUsableCoordinates(latitude, longitude) {
  return latitude !== null && longitude !== null && !(latitude === 0 && longitude === 0);
}
function safeDate(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}
function roundCoarse(value) {
  const number = safeNumber(value);
  return number === null ? null : Math.round(number * 100) / 100;
}
function weatherCategory(code) {
  if (code === 0) return "sunny";
  if ([1, 2, 3].includes(code)) return "cloudy";
  if ([45, 48].includes(code)) return "fog";
  if ([71, 73, 75, 77, 85, 86].includes(code)) return "snow";
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99].includes(code)) return "rain";
  return "unknown";
}
async function currentWeather(latitude, longitude) {
  if (latitude == null || longitude == null) return null;
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", latitude);
  url.searchParams.set("longitude", longitude);
  url.searchParams.set("current", "temperature_2m,weather_code");
  url.searchParams.set("forecast_days", "1");
  const response = await fetch(url);
  if (!response.ok) return null;
  const payload = await response.json();
  return { code: weatherCategory(Number(payload.current?.weather_code)), temperatureC: safeNumber(payload.current?.temperature_2m), provider: "open-meteo" };
}
function locationFromNominatim(payload) {
  const address = payload?.address || {};
  const names = payload?.namedetails || {};
  const city = address.city || address.town || address.village || address.municipality || address.county || null;
  const detail = address.attraction || address.tourism || address.building || address.neighbourhood || address.suburb || address.road || null;
  const preferredName = names["name:zh-Hans"] || names["name:zh"] || names["name:zh-Hant"] || null;
  const locationName = preferredName || [city, detail].filter((value, index, array) => value && array.indexOf(value) === index).join(" · ") || payload?.name || payload?.display_name?.split(",").slice(0, 2).join(" · ") || null;
  return { locationName, city, country:address.country || null, countryCode:(address.country_code || "").toUpperCase() || null, provider:"openstreetmap-nominatim" };
}
async function reverseGeocode(env, latitude, longitude, language = "zh-CN") {
  if (!hasUsableCoordinates(latitude, longitude)) return null;
  const lat = Math.round(latitude * 1000) / 1000; const lon = Math.round(longitude * 1000) / 1000;
  const key = `${lat.toFixed(3)},${lon.toFixed(3)},${String(language).slice(0, 5)}`;
  const cached = await env.DB.prepare("SELECT location_name,city,country,country_code,provider FROM geocode_cache WHERE coordinate_key=?").bind(key).first();
  if (cached) return { locationName:cached.location_name, city:cached.city, country:cached.country, countryCode:cached.country_code, provider:cached.provider, cached:true };
  const task = async () => {
    const url = new URL(env.GEOCODING_API_URL || "https://nominatim.openstreetmap.org/reverse");
    url.searchParams.set("format", "jsonv2"); url.searchParams.set("lat", lat); url.searchParams.set("lon", lon);
    url.searchParams.set("zoom", "16"); url.searchParams.set("addressdetails", "1"); url.searchParams.set("namedetails", "1"); url.searchParams.set("accept-language", "zh-CN,zh;q=0.9");
    const wait = Math.max(0, 1050 - (Date.now() - lastGeocodeAt));
    if (wait) await new Promise((resolve) => setTimeout(resolve, wait));
    const response = await fetch(url, { headers:{ "accept":"application/json", "user-agent":env.GEOCODING_USER_AGENT || "EchoTrip/0.1" } });
    lastGeocodeAt = Date.now();
    if (!response.ok) return null;
    const payload = await response.json(); const result = locationFromNominatim(payload);
    await env.DB.prepare("INSERT OR REPLACE INTO geocode_cache (coordinate_key,latitude,longitude,location_name,city,country,country_code,provider,response_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .bind(key, lat, lon, result.locationName, result.city, result.country, result.countryCode, result.provider, JSON.stringify(payload), now()).run();
    return result;
  };
  /* Nominatim 要求限速；串行化并发请求，避免批量上传时只有前几张成功。 */
  geocodeQueue = geocodeQueue.then(task, task);
  return geocodeQueue;
}
function toBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunk) binary += String.fromCharCode(...bytes.subarray(offset, offset + chunk));
  return btoa(binary);
}
function outputText(response) {
  if (typeof response?.output_text === "string" && response.output_text) return response.output_text;
  for (const item of response.output || []) {
    if (item.type !== "message") continue;
    for (const content of item.content || []) if (content.type === "output_text" && content.text) return content.text;
  }
  return "";
}

const PHOTO_ANALYSIS_SCHEMA = {
  type: "object", additionalProperties: false, required: ["photos"], properties: {
    photos: { type: "array", items: {
      type: "object", additionalProperties: false,
      required: ["photo_id", "scene", "subject", "activities", "landmark_guess", "event_title_zh", "place_name_zh", "semantic_group", "weather", "memory_score", "memory_hook", "confidence"],
      properties: {
        photo_id: { type: "string" },
        scene: { type: "string", enum: ["people", "food", "architecture", "nature", "transport", "indoor", "street", "animal", "document", "other"] },
        subject: { type: "string", maxLength: 24 },
        activities: { type: "array", items: { type: "string", maxLength: 8 }, maxItems: 3 },
        landmark_guess: { type: ["string", "null"] },
        event_title_zh: { type: "string", maxLength: 8 },
        place_name_zh: { type: ["string", "null"] },
        semantic_group: { type: "string", enum: ["sightseeing", "food", "transport", "shopping", "nature", "people", "lodging", "leisure", "other"] },
        weather: { type: "string", enum: ["sunny", "cloudy", "rain", "snow", "fog", "indoor", "unknown"] },
        memory_score: { type: "number", minimum: 0, maximum: 1 },
        memory_hook: { type: "string", maxLength: 24 }, confidence: { type: "number", minimum: 0, maximum: 1 },
      },
    } },
  },
};

async function analyzeWithVision(env, photos) {
  if (!env.OPENAI_API_KEY) {
    const configurationError = new Error("Missing server configuration: OPENAI_API_KEY");
    configurationError.code = "AI_NOT_CONFIGURED";
    throw configurationError;
  }
  const content = [{ type: "input_text", text: "按 PHOTO_ID 顺序分析旅行照片。只写可见事实，中文短语；不认人。地点或地标不确定填 null。event_title_zh 用不超过8个汉字概括活动而非地名；memory_hook 写最值得追问的可见线索。" }];
  for (const photo of photos) {
    const object = await env.MEDIA.get(photo.analysis_object_key || photo.object_key);
    if (!object) throw new Error(`Photo object missing: ${photo.id}`);
    const bytes = new Uint8Array(await object.arrayBuffer());
    content.push({ type: "input_text", text: `PHOTO_ID: ${photo.id}` });
    content.push({ type: "input_image", image_url: `data:${photo.analysis_mime_type || photo.mime_type};base64,${toBase64(bytes)}`, detail: "low" });
  }
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${env.OPENAI_API_KEY}` },
    body: JSON.stringify({ model: env.OPENAI_VISION_MODEL || "gpt-4o", store: false, max_output_tokens: Math.max(1200, photos.length * 220), input: [{ role: "user", content }], text: { format: { type: "json_schema", name: "echotrip_photo_analysis", strict: true, schema: PHOTO_ANALYSIS_SCHEMA } } }),
  });
  if (!response.ok) {
    const message = await response.text();
    const providerError = new Error(`Vision provider returned ${response.status}: ${message.slice(0, 500)}`);
    providerError.code = "AI_PROVIDER_ERROR";
    throw providerError;
  }
  const payload = await response.json();
  const text = outputText(payload);
  if (!text) {
    const refusal = (payload.output || []).flatMap((item) => item.content || []).find((item) => item.type === "refusal")?.refusal;
    const reason = payload.incomplete_details?.reason || refusal || payload.status || "empty output";
    throw Object.assign(new Error(`Vision provider returned no structured output: ${reason}`), { code:"AI_INCOMPLETE_OUTPUT" });
  }
  return { photos:JSON.parse(text).photos, usage:payload.usage || null, model:payload.model || env.OPENAI_VISION_MODEL || "gpt-4o" };
}

function validatedVisionResults(requestedPhotos, returnedPhotos) {
  const expected = new Set(requestedPhotos.map((photo) => photo.id));
  const counts = new Map();
  for (const item of returnedPhotos || []) {
    if (expected.has(item?.photo_id)) counts.set(item.photo_id, (counts.get(item.photo_id) || 0) + 1);
  }
  const accepted = (returnedPhotos || []).filter((item) => expected.has(item?.photo_id) && counts.get(item.photo_id) === 1);
  const acceptedIds = new Set(accepted.map((item) => item.photo_id));
  return { accepted, missing:requestedPhotos.filter((photo) => !acceptedIds.has(photo.id)) };
}

async function analyzeWithVisionRecovery(env, photos, hooks = {}) {
  const queue = [photos];
  const completed = new Set();
  let calls = 0;
  while (queue.length) {
    const batch = queue.shift().filter((photo) => !completed.has(photo.id));
    if (!batch.length) continue;
    if (++calls > photos.length * 2 + 2) {
      throw Object.assign(new Error("Vision recovery exceeded the safe retry limit"), { code:"AI_RESPONSE_MISMATCH" });
    }
    await hooks.beforeCall?.({ batch, calls });
    let result;
    try {
      result = await analyzeWithVision(env, batch);
    } catch (cause) {
      if (cause.code === "AI_INCOMPLETE_OUTPUT" && batch.length > 1) {
        const middle = Math.ceil(batch.length / 2);
        queue.unshift(batch.slice(middle), batch.slice(0, middle));
        continue;
      }
      throw cause;
    }
    const { accepted, missing } = validatedVisionResults(batch, result.photos);
    await hooks.onBatch?.({ batch, result, accepted, missing, calls });
    accepted.forEach((item) => completed.add(item.photo_id));
    if (!missing.length) continue;
    if (batch.length === 1) {
      throw Object.assign(new Error(`Vision response did not return PHOTO_ID ${batch[0].id}`), { code:"AI_RESPONSE_MISMATCH" });
    }
    for (let offset = 0; offset < missing.length; offset += 3) queue.push(missing.slice(offset, offset + 3));
  }
  return { analyzed:completed.size, calls };
}

function aiConfigurationError(){
  const cause = new Error("Missing server configuration: OPENAI_API_KEY");
  cause.code = "AI_NOT_CONFIGURED";
  return cause;
}


function deterministicMemoryCard(moment, transcript) {
  const evidence = moment.evidence || {};
  const context = [evidence.timeline_title, evidence.location, evidence.taken_at ? String(evidence.taken_at).slice(0, 10) : null].filter(Boolean).join(" · ");
  return { title:String(moment.title || "旅行回忆").slice(0, 18), memory:transcript, context:context.slice(0, 120) };
}

function distanceKm(a, b) {
  if (a.latitude == null || a.longitude == null || b.latitude == null || b.longitude == null) return null;
  const toRad = (value) => value * Math.PI / 180;
  const dLat = toRad(b.latitude - a.latitude); const dLon = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude); const lat2 = toRad(b.latitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function placeKey(value) { return String(value || "").trim().toLowerCase().replace(/[·,，\s]+/g, ""); }
function dateKey(value) { return value ? String(value).slice(0, 10) : ""; }
function commonValue(values) {
  const counts = new Map();
  for (const value of values.filter(Boolean)) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
}
function hasChinese(value) { return /[\u3400-\u9fff]/.test(String(value || "")); }
function countryNameZh(code) {
  if (!code) return null;
  try { return new Intl.DisplayNames(["zh-CN"], { type:"region" }).of(String(code).toUpperCase()) || null; }
  catch { return null; }
}
const PLACE_ZH_ALIASES = [
  [/zlatibor|златибор/i, "兹拉蒂博尔"],
  [/zemun|земун/i, "泽蒙"],
  [/novi\s*beograd|нови\s*београд/i, "新贝尔格莱德"],
  [/beograd|belgrade|београд/i, "贝尔格莱德"],
  [/novi\s*sad|нови\s*сад/i, "诺维萨德"],
];
function knownPlaceFromText(values) {
  const text = (values || []).filter(Boolean).join(" · ");
  return PLACE_ZH_ALIASES.find(([pattern]) => pattern.test(text))?.[1] || null;
}
function knownPlaceFromCoordinates(photo) {
  const lat = Number(photo?.latitude); const lon = Number(photo?.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  if (lat >= 43.55 && lat <= 43.86 && lon >= 19.45 && lon <= 19.98) return "兹拉蒂博尔";
  if (lat >= 44.79 && lat <= 44.95 && lon >= 20.25 && lon <= 20.45) return "泽蒙";
  if (lat >= 44.68 && lat <= 44.94 && lon >= 20.25 && lon <= 20.68) return "贝尔格莱德";
  if (lat >= 45.15 && lat <= 45.38 && lon >= 19.65 && lon <= 20.05) return "诺维萨德";
  return null;
}
function chinesePlace(photo, analysis = {}) {
  const candidates = [analysis.place_name_zh, analysis.landmark_guess, photo.location_name, photo.city];
  const known = knownPlaceFromCoordinates(photo) || knownPlaceFromText(candidates);
  if (known) return known;
  const chinese = candidates.find((value) => hasChinese(value));
  if (chinese) return String(chinese).trim().slice(0, 24);
  const country = countryNameZh(photo.country_code);
  return country ? `${country}·当地街区` : "地点待补充";
}
function commonChinesePlace(photos) {
  const values = photos.map((item) => chinesePlace(item, item.__analysis));
  const specific = values.filter((value) => value && value !== "地点待补充" && !value.endsWith("·当地街区"));
  return commonValue(specific) || commonValue(values) || "地点待补充";
}
function stringSet(values) { return new Set((values || []).map((value) => placeKey(value)).filter(Boolean)); }
function overlapCount(a, b) { let count = 0; for (const value of a) if (b.has(value)) count += 1; return count; }
function timelineTitle(photos) {
  const analyses = photos.map((item) => item.__analysis || {});
  const explicit = commonValue(analyses.map((item) => item.event_title_zh));
  if (explicit && hasChinese(explicit)) return Array.from(explicit).slice(0, 8).join("");
  const group = commonValue(analyses.map((item) => item.semantic_group)) || "other";
  const titles = { sightseeing:"探访城市地标", food:"品尝当地美食", transport:"旅途移动", shopping:"街区购物", nature:"亲近自然", people:"旅伴相聚", lodging:"入住休息", leisure:"悠闲漫步", other:"旅行途中" };
  return titles[group] || titles.other;
}
function timelineTitleCandidates(node) {
  const place = String(node.place_name || "");
  const category = node.category || "other";
  const hour = Number(String(node.starts_at || "").slice(11, 13));
  const period = hour < 7 ? "清晨" : hour < 12 ? "上午" : hour < 18 ? "午后" : "夜间";
  const placeTitles = [];
  if (place.includes("泽蒙")) placeTitles.push("泽蒙小镇漫步", "泽蒙河畔时光");
  if (place.includes("兹拉蒂博尔")) placeTitles.push("兹拉蒂博尔游览", "山间自然时光");
  if (place.includes("贝尔格莱德")) placeTitles.push("贝城文化漫游", "老城街头漫步");
  if (place.includes("诺维萨德")) placeTitles.push("诺城街区漫步");
  const byCategory = {
    nature:["湖畔漫步", "公园观鸟", "山野时光", "自然风光"], food:["品尝当地美食", "午间用餐", "街头美食", "旅途晚餐"],
    sightseeing:["探访城市地标", "老城建筑漫游", "文化景点参观"], shopping:["街区购物", "逛店买手信"],
    transport:["旅途移动", "沿途风景"], people:["旅伴相聚", "旅途合影"], leisure:["悠闲漫步", "小镇慢时光"],
    other:["沿途见闻", "城市随拍", "街区漫步", "旅途片段"],
  };
  return [...placeTitles, ...(byCategory[category] || byCategory.other), `${period}沿途见闻`, `${period}旅途片段`]
    .map((value) => Array.from(value).slice(0, 8).join(""));
}
function fillTimelineLocations(nodes) {
  const isSpecific = (value) => value && value !== "地点待补充" && !value.endsWith("·当地街区");
  for (let index = 0; index < nodes.length; index += 1) {
    const node = nodes[index];
    if (isSpecific(node.place_name) || !node.starts_at) continue;
    const nodeTime = Date.parse(node.starts_at);
    const nearby = nodes.map((candidate, candidateIndex) => ({ candidate, candidateIndex }))
      .filter(({ candidate }) => candidate.starts_at && dateKey(candidate.starts_at) === dateKey(node.starts_at) && isSpecific(candidate.place_name))
      .map((item) => ({ ...item, gap:Math.abs(Date.parse(item.candidate.starts_at) - nodeTime) / 60000, orderGap:Math.abs(item.candidateIndex - index) }))
      .filter((item) => item.gap <= 180)
      .sort((a, b) => a.gap - b.gap || a.orderGap - b.orderGap);
    if (!nearby.length) continue;
    const closePlaces = [...new Set(nearby.filter((item) => item.gap <= 120).map((item) => item.candidate.place_name))];
    if (closePlaces.length === 1 || (nearby[1] && nearby[0].candidate.place_name === nearby[1].candidate.place_name)) {
      node.place_name = nearby[0].candidate.place_name;
      node.location_inferred = true;
    }
  }
  return nodes;
}
function polishTimelineTitles(nodes) {
  const usedByDay = new Map();
  for (const node of nodes) {
    const day = dateKey(node.starts_at) || "unknown";
    const used = usedByDay.get(day) || new Set(); usedByDay.set(day, used);
    let title = Array.from(node.title || "").slice(0, 8).join("");
    const generic = /^(上午|午后|清晨|夜间)?城市漫游$|^旅行途中$/.test(title);
    if (generic || used.has(title)) title = timelineTitleCandidates(node).find((candidate) => !used.has(candidate)) || title;
    if (used.has(title)) title = Array.from(`${title}${used.size + 1}`).slice(0, 8).join("");
    node.title = title || "旅途片段"; used.add(node.title);
  }
  return nodes;
}
function shouldMergeTimelinePhoto(node, photo) {
  const previous = node.__lastPhoto;
  if (!previous?.taken_at || !photo.taken_at || dateKey(previous.taken_at) !== dateKey(photo.taken_at)) return false;
  const gapMinutes = (Date.parse(photo.taken_at) - Date.parse(previous.taken_at)) / 60000;
  const durationMinutes = (Date.parse(photo.taken_at) - Date.parse(node.starts_at)) / 60000;
  if (gapMinutes < 0 || gapMinutes > 180 || durationMinutes > 300) return false;
  const distance = distanceKm(previous, photo);
  const previousPlace = placeKey(previous.location_name), currentPlace = placeKey(photo.location_name);
  const previousAnalysis = previous.__analysis || {}, currentAnalysis = photo.__analysis || {};
  let score = gapMinutes <= 30 ? 4 : gapMinutes <= 75 ? 3 : gapMinutes <= 120 ? 2 : 1;
  if (distance != null) {
    if (distance <= 2) score += 3;
    else if (distance <= 8) score += 2;
    else if (distance <= 25) score += 0;
    else if (distance <= 80) score -= 2;
    else score -= 5;
  }
  if (previousPlace && currentPlace) score += previousPlace === currentPlace ? 3 : 0;
  if (previous.city && photo.city && placeKey(previous.city) === placeKey(photo.city)) score += 1;
  if (previous.country_code && photo.country_code && previous.country_code === photo.country_code) score += 1;
  if (previousAnalysis.semantic_group && previousAnalysis.semantic_group === currentAnalysis.semantic_group) score += 2;
  if (previousAnalysis.scene && previousAnalysis.scene === currentAnalysis.scene) score += 1;
  score += Math.min(2, overlapCount(stringSet(previousAnalysis.activities), stringSet(currentAnalysis.activities)));
  const previousLandmark = placeKey(previousAnalysis.landmark_guess), currentLandmark = placeKey(currentAnalysis.landmark_guess);
  if (previousLandmark && currentLandmark) score += previousLandmark === currentLandmark ? 2 : -1;
  /* 近距离连拍是同一事件；其余情况由多维证据共同决定，不再使用固定距离硬切。 */
  return gapMinutes <= 15 || score >= 5;
}

function buildTimeline(photos) {
  const sorted = [...photos].sort((a, b) => {
    const at = a.taken_at ? Date.parse(a.taken_at) : Infinity; const bt = b.taken_at ? Date.parse(b.taken_at) : Infinity;
    return at - bt || a.sort_order - b.sort_order;
  });
  const nodes = [];
  for (const photo of sorted) {
    const analysis = photo.analysis_json ? JSON.parse(photo.analysis_json) : {};
    const effectivePhoto = { ...photo, location_name:photo.location_name || analysis.landmark_guess || null, __analysis:analysis };
    const previous = nodes[nodes.length - 1];
    if (previous && shouldMergeTimelinePhoto(previous, effectivePhoto)) {
      previous.photo_ids.push(photo.id); previous.ends_at = photo.taken_at || previous.ends_at;
      previous.confidence = Math.min(previous.confidence, analysis.confidence ?? 0.5);
      previous.__lastPhoto = effectivePhoto; previous.__photos.push(effectivePhoto);
      previous.place_name = commonChinesePlace(previous.__photos);
      previous.title = timelineTitle(previous.__photos);
      previous.category = commonValue(previous.__photos.map((item) => item.__analysis?.semantic_group || item.__analysis?.scene)) || previous.category;
      continue;
    }
    const place = chinesePlace(photo, analysis);
    nodes.push({ id: id("node"), starts_at: photo.taken_at, ends_at: photo.taken_at, latitude: photo.latitude, longitude: photo.longitude, place_name: place,
      title: timelineTitle([effectivePhoto]), category: analysis.semantic_group || analysis.scene || "other", photo_ids: [photo.id], confidence: analysis.confidence ?? 0.5,
      __lastPhoto:effectivePhoto, __photos:[effectivePhoto] });
  }
  const cleaned = nodes.map((node) => { delete node.__lastPhoto; delete node.__photos; return node; });
  return polishTimelineTitles(fillTimelineLocations(cleaned));
}

function momentQuestion(analysis, node) {
  const place = node?.place_name && node.place_name !== "地点待补充" ? node.place_name : "这里";
  const event = node?.title || analysis.event_title_zh || "这个瞬间";
  const subject = analysis.subject || analysis.memory_hook || "眼前这一幕";
  const templates = {
    food:`在${place}${event}时，${subject}最让你记住的味道或细节是什么？`,
    people:`在${place}${event}时，和你一起经历${subject}的人当时说了什么？`,
    nature:`在${place}${event}时，看到${subject}的第一感受是什么？`,
    transport:`从${place}出发或经过这里时，${subject}让你想到了什么？`,
    shopping:`在${place}${event}时，为什么会留意到${subject}？`,
    sightseeing:`在${place}${event}时，${subject}和你原先想象的一样吗？`,
  };
  return (templates[analysis.semantic_group] || `关于${place}的${event}，${subject}背后发生了什么？`).slice(0, 80);
}

function buildMoments(photos, timeline) {
  const nodeByPhoto = new Map();
  for (const node of timeline) for (const photoId of node.photo_ids || []) nodeByPhoto.set(photoId, node);
  const candidates = photos.map((photo) => {
    const analysis = photo.analysis_json ? JSON.parse(photo.analysis_json) : {};
    const node = nodeByPhoto.get(photo.id);
    return { photo, analysis, node, score:Number(analysis.memory_score || 0) + Math.min(.12, ((node?.photo_ids?.length || 1) - 1) * .02) };
  }).sort((a, b) => b.score - a.score);
  const limit = Math.min(8, Math.max(3, Math.ceil(photos.length / 4)));
  const selected = [];
  const selectedIds = new Set();
  /* First represent different Timeline events, then fill by score. This avoids
     asking several nearly identical questions about one burst of photos. */
  for (const node of timeline) {
    const best = candidates.find((item) => item.node?.id === node.id && !selectedIds.has(item.photo.id));
    if (best && selected.length < limit) { selected.push(best); selectedIds.add(best.photo.id); }
  }
  for (const item of candidates) {
    if (selected.length >= limit) break;
    if (!selectedIds.has(item.photo.id)) { selected.push(item); selectedIds.add(item.photo.id); }
  }
  return selected.sort((a, b) => b.score - a.score).map(({ photo, analysis, node, score }) => {
    const hook = analysis.memory_hook || analysis.subject || node?.title || "值得记住的瞬间";
    return { id:id("moment"), photo_id:photo.id, title:String(hook).slice(0, 18),
      reason:`${node?.title || "这段行程"}中的「${hook}」具有较强的回忆线索。`, prompt:momentQuestion(analysis, node), score,
      evidence:{ scene:analysis.scene, subject:analysis.subject, activities:analysis.activities || [], weather:analysis.weather, taken_at:photo.taken_at,
        location:node?.place_name || analysis.place_name_zh || analysis.landmark_guess || null, timeline_id:node?.id || null, timeline_title:node?.title || null } };
  });
}

async function rebuildTripDerivedData(env, tripId, installationId) {
  const photos = (await env.DB.prepare("SELECT * FROM photos WHERE trip_id=? AND installation_id=? ORDER BY sort_order").bind(tripId, installationId).all()).results || [];
  const timeline = buildTimeline(photos); const moments = buildMoments(photos, timeline); const createdAt = now();
  const statements = [env.DB.prepare("DELETE FROM timeline_nodes WHERE trip_id=? AND installation_id=?").bind(tripId, installationId), env.DB.prepare("DELETE FROM moments WHERE trip_id=? AND installation_id=?").bind(tripId, installationId)];
  timeline.forEach((node, index) => statements.push(env.DB.prepare("INSERT INTO timeline_nodes (id,trip_id,installation_id,starts_at,ends_at,latitude,longitude,place_name,title,category,photo_ids_json,sort_order,confidence,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .bind(node.id, tripId, installationId, node.starts_at, node.ends_at, node.latitude, node.longitude, node.place_name, node.title, node.category, JSON.stringify(node.photo_ids), index, node.confidence, createdAt)));
  moments.forEach((moment) => statements.push(env.DB.prepare("INSERT INTO moments (id,trip_id,installation_id,photo_id,title,reason,prompt,score,evidence_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
    .bind(moment.id, tripId, installationId, moment.photo_id, moment.title, moment.reason, moment.prompt, moment.score, JSON.stringify(moment.evidence), createdAt)));
  statements.push(env.DB.prepare("UPDATE trips SET status='ready', updated_at=? WHERE id=? AND installation_id=?").bind(createdAt, tripId, installationId));
  await env.DB.batch(statements);
}

async function createTrip(request, env) {
  const body = await readJson(request);
  if (!body) return error("INVALID_JSON", "Request body must be JSON");
  const installationId = requiredInstallation(request, body);
  if (!installationId) return error("INSTALLATION_REQUIRED", "installationId is required");
  await touchInstallation(env, installationId, body);
  const tripId = id("trip"); const timestamp = now();
  await env.DB.prepare("INSERT INTO trips (id,installation_id,name,destination,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)")
    .bind(tripId, installationId, String(body.name || ""), String(body.destination || ""), "draft", timestamp, timestamp).run();
  return json({ trip: { id: tripId, installationId, name: body.name || "", destination: body.destination || "", status: "draft", photos: [], timeline: [], moments: [] } }, 201);
}

async function uploadPhoto(request, env, tripId) {
  if (!env.MEDIA) return error("STORAGE_NOT_CONFIGURED", "R2 binding MEDIA is not configured", 503);
  const form = await request.formData(); const installationId = requiredInstallation(request, Object.fromEntries(form));
  if (!installationId) return error("INSTALLATION_REQUIRED", "installationId is required");
  if (!await assertTripOwner(env, tripId, installationId)) return error("TRIP_NOT_FOUND", "Trip not found", 404);
  const photoCount = await env.DB.prepare("SELECT COUNT(*) AS count FROM photos WHERE trip_id=? AND installation_id=?").bind(tripId, installationId).first();
  const maxPhotos = Math.max(1, Number(env.MAX_PHOTOS_PER_TRIP || DEFAULT_MAX_PHOTOS_PER_TRIP));
  if (Number(photoCount?.count || 0) >= maxPhotos) return error("TRIP_PHOTO_LIMIT", `A trip can contain at most ${maxPhotos} photos`, 429);
  const file = form.get("photo"); const analysisFile = form.get("analysisPhoto");
  if (!(file instanceof File)) return error("PHOTO_REQUIRED", "photo file is required");
  if (!file.type.startsWith("image/")) return error("INVALID_PHOTO_TYPE", "Only image files are accepted", 415);
  if (file.size > MAX_UPLOAD_BYTES) return error("PHOTO_TOO_LARGE", "Photo exceeds 20 MB limit", 413);
  let metadata = {}; try { metadata = JSON.parse(String(form.get("metadata") || "{}")); } catch { return error("INVALID_METADATA", "metadata must be valid JSON"); }
  const photoId = id("photo"); const extension = (file.name.split(".").pop() || "bin").replace(/[^a-z0-9]/gi, "").toLowerCase();
  const objectKey = `installations/${installationId}/trips/${tripId}/photos/${photoId}.${extension}`;
  await env.MEDIA.put(objectKey, file.stream(), { httpMetadata: { contentType: file.type }, customMetadata: { tripId, photoId } });
  let analysisObjectKey = null, analysisMimeType = null;
  if (analysisFile instanceof File && analysisFile.type.startsWith("image/") && analysisFile.size <= 3 * 1024 * 1024) {
    analysisObjectKey = `installations/${installationId}/trips/${tripId}/analysis/${photoId}.jpg`;
    analysisMimeType = analysisFile.type;
    await env.MEDIA.put(analysisObjectKey, analysisFile.stream(), { httpMetadata: { contentType:analysisFile.type }, customMetadata:{ tripId, photoId, purpose:"ai-analysis" } });
  }
  const timestamp = now(); const takenAt = safeDate(metadata.takenAt || metadata.taken_at || file.lastModified);
  let latitude = safeNumber(metadata.latitude); let longitude = safeNumber(metadata.longitude);
  if (!hasUsableCoordinates(latitude, longitude)) { latitude = null; longitude = null; }
  const location = metadata.locationName ? { locationName:metadata.locationName, city:metadata.city || null, country:metadata.country || null, countryCode:metadata.countryCode || null, provider:metadata.locationSource || "client" }
    : await reverseGeocode(env, latitude, longitude, metadata.locale || "zh-CN");
  await env.DB.prepare("INSERT INTO photos (id,trip_id,installation_id,object_key,analysis_object_key,original_name,mime_type,analysis_mime_type,byte_size,width,height,taken_at,time_source,latitude,longitude,altitude,location_source,location_name,city,country,country_code,sort_order,analysis_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .bind(photoId, tripId, installationId, objectKey, analysisObjectKey, file.name, file.type, analysisMimeType, file.size, safeNumber(metadata.width), safeNumber(metadata.height), takenAt, metadata.timeSource || metadata.time_source || null, latitude, longitude, safeNumber(metadata.altitude), location?.provider || (latitude != null && longitude != null ? "exif" : null), location?.locationName || null, location?.city || null, location?.country || null, location?.countryCode || null, safeNumber(metadata.sortOrder) || 0, "pending", timestamp, timestamp).run();
  await env.DB.prepare("UPDATE trips SET status='uploaded', updated_at=? WHERE id=? AND installation_id=?").bind(timestamp, tripId, installationId).run();
  return json({ photo: { id: photoId, tripId, takenAt, latitude, longitude, location, analysisStatus: "pending" } }, 201);
}

async function getTrip(request, env, tripId) {
  const installationId = requiredInstallation(request);
  if (!installationId) return error("INSTALLATION_REQUIRED", "x-echotrip-installation header is required");
  const trip = await env.DB.prepare("SELECT * FROM trips WHERE id=? AND installation_id=?").bind(tripId, installationId).first();
  if (!trip) return error("TRIP_NOT_FOUND", "Trip not found", 404);
  const [photos, timeline, moments, cards] = await Promise.all([
    env.DB.prepare("SELECT id,original_name,mime_type,byte_size,width,height,taken_at,time_source,latitude,longitude,location_source,location_name,city,country,country_code,sort_order,analysis_status,analysis_json FROM photos WHERE trip_id=? AND installation_id=? ORDER BY sort_order").bind(tripId, installationId).all(),
    env.DB.prepare("SELECT * FROM timeline_nodes WHERE trip_id=? AND installation_id=? ORDER BY sort_order").bind(tripId, installationId).all(),
    env.DB.prepare("SELECT * FROM moments WHERE trip_id=? AND installation_id=? ORDER BY score DESC").bind(tripId, installationId).all(),
    env.DB.prepare("SELECT m.*,p.payload_json FROM memory_cards m LEFT JOIN memory_card_payloads p ON p.card_id=m.id WHERE m.trip_id=? AND m.installation_id=? ORDER BY m.created_at DESC").bind(tripId, installationId).all(),
  ]);
  const requestUrl = new URL(request.url);
  const photoPayloads = await Promise.all((photos.results || []).map(async (photo) => {
    const mediaUrl = new URL(`${API_PREFIX}/photos/${photo.id}/content`, requestUrl.origin);
    if (env.ECHOTRIP_SESSION_SECRET) {
      const issuedAt = Math.floor(Date.now() / 1000);
      mediaUrl.searchParams.set("media_token", await signPayload(env, { type:"media", photoId:photo.id, installationId, iat:issuedAt, exp:issuedAt + MEDIA_TTL_SECONDS }));
    } else mediaUrl.searchParams.set("installation", installationId);
    return { ...photo, analysis: photo.analysis_json ? JSON.parse(photo.analysis_json) : null, analysis_json: undefined, mediaUrl:mediaUrl.toString() };
  }));
  return json({ trip: { ...trip,
    photos: photoPayloads,
    timeline: (timeline.results || []).map((node) => ({ ...node, photo_ids: JSON.parse(node.photo_ids_json), photo_ids_json: undefined })),
    moments: (moments.results || []).map((moment) => ({ ...moment, evidence: JSON.parse(moment.evidence_json), evidence_json: undefined })),
    cards: (cards.results || []).map((card) => ({ ...card, payload:card.payload_json ? JSON.parse(card.payload_json) : null, payload_json:undefined })),
  } });
}

async function getPhotoContent(request, env, photoId) {
  const url = new URL(request.url);
  let installationId = requiredInstallation(request);
  if (env.ECHOTRIP_SESSION_SECRET) {
    const payload = await verifyPayload(env, url.searchParams.get("media_token"), "media");
    if (!payload || payload.photoId !== photoId) return error("MEDIA_TOKEN_INVALID", "Photo link is invalid or expired", 401);
    installationId = payload.installationId;
  }
  if (!installationId) return error("INSTALLATION_REQUIRED", "x-echotrip-installation header is required");
  const photo = await env.DB.prepare("SELECT object_key,mime_type FROM photos WHERE id=? AND installation_id=?").bind(photoId, installationId).first();
  if (!photo) return error("PHOTO_NOT_FOUND", "Photo not found", 404);
  const object = await env.MEDIA.get(photo.object_key);
  if (!object) return error("PHOTO_BYTES_NOT_FOUND", "Photo bytes not found", 404);
  return new Response(object.body, { headers: { "content-type": photo.mime_type, "cache-control": "private, max-age=3600" } });
}

async function transcribeAudio(request, env) {
  return error("LOCAL_TRANSCRIPTION_ONLY", "EchoTrip uses browser speech recognition or on-device Whisper; no cloud transcription endpoint is enabled", 410);
}

async function saveMemory(request, env, tripId, momentId) {
  const form = await request.formData();
  const installationId = requiredInstallation(request, Object.fromEntries(form));
  if (!installationId) return error("INSTALLATION_REQUIRED", "installationId is required");
  if (!await assertTripOwner(env, tripId, installationId)) return error("TRIP_NOT_FOUND", "Trip not found", 404);
  const moment = await env.DB.prepare("SELECT * FROM moments WHERE id=? AND trip_id=? AND installation_id=?").bind(momentId, tripId, installationId).first();
  if (!moment) return error("MOMENT_NOT_FOUND", "Moment not found", 404);
  moment.evidence = moment.evidence_json ? JSON.parse(moment.evidence_json) : {};
  const audio = form.get("audio");
  let transcript = String(form.get("transcript") || "").trim();
  let transcriptSource = String(form.get("transcriptSource") || "user-text");
  try {
    if (!transcript) return error("MEMORY_REQUIRED", "Transcript or written memory is required");
    const generated = deterministicMemoryCard(moment, transcript);
    const cardId = id("card"); const timestamp = now();
    let audioObjectKey = null;
    if (audio instanceof File && audio.size) {
      if (!env.MEDIA) return error("STORAGE_NOT_CONFIGURED", "R2 binding MEDIA is not configured", 503);
      if (audio.size > MAX_AUDIO_BYTES) return error("AUDIO_TOO_LARGE", "Audio exceeds 20 MB limit", 413);
      const extension = (audio.name?.split(".").pop() || (audio.type.includes("mp4") ? "m4a" : "webm")).replace(/[^a-z0-9]/gi, "").toLowerCase();
      audioObjectKey = `installations/${installationId}/trips/${tripId}/audio/${cardId}.${extension}`;
      await env.MEDIA.put(audioObjectKey, audio.stream(), { httpMetadata:{ contentType:audio.type || "audio/webm" }, customMetadata:{ tripId, momentId, cardId } });
    }
    const payload = { ...generated, transcriptSource, audioMimeType:audio instanceof File ? audio.type : null, audioDuration:Number(form.get("audioDuration") || 0) || 0 };
    await env.DB.batch([
      env.DB.prepare("DELETE FROM memory_card_payloads WHERE card_id IN (SELECT id FROM memory_cards WHERE moment_id=? AND trip_id=? AND installation_id=?)").bind(momentId, tripId, installationId),
      env.DB.prepare("DELETE FROM memory_cards WHERE moment_id=? AND trip_id=? AND installation_id=?").bind(momentId, tripId, installationId),
      env.DB.prepare("INSERT INTO memory_cards (id,moment_id,trip_id,installation_id,transcript,edited_memory,audio_object_key,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)")
        .bind(cardId, momentId, tripId, installationId, transcript, generated.memory, audioObjectKey, timestamp, timestamp),
      env.DB.prepare("INSERT INTO memory_card_payloads (card_id,payload_json,created_at,updated_at) VALUES (?,?,?,?)")
        .bind(cardId, JSON.stringify(payload), timestamp, timestamp),
    ]);
    return json({ card:{ id:cardId, momentId, tripId, transcript, audioStored:!!audioObjectKey, ...payload } }, 201);
  } catch (cause) {
    return error(cause.code || "MEMORY_GENERATION_FAILED", cause.message || "Memory generation failed", cause.code === "AI_NOT_CONFIGURED" ? 503 : 502);
  }
}

async function analyzeTrip(request, env, tripId) {
  const body = await readJson(request) || {}; const installationId = requiredInstallation(request, body);
  if (!installationId) return error("INSTALLATION_REQUIRED", "installationId is required");
  if (!await assertTripOwner(env, tripId, installationId)) return error("TRIP_NOT_FOUND", "Trip not found", 404);
  const dailyLimit = Math.max(0, Number(env.DAILY_AI_TOKEN_LIMIT ?? DEFAULT_DAILY_AI_TOKEN_LIMIT));
  if (dailyLimit) {
    const startOfDay = new Date(); startOfDay.setUTCHours(0, 0, 0, 0);
    const usage = await env.DB.prepare("SELECT COALESCE(SUM(input_tokens + output_tokens), 0) AS tokens FROM ai_usage_events WHERE installation_id=? AND created_at>=?").bind(installationId, startOfDay.toISOString()).first();
    if (Number(usage?.tokens || 0) >= dailyLimit) return error("AI_DAILY_LIMIT", "今日 AI 分析额度已用完，请明天再试", 429, { dailyLimit, used:Number(usage?.tokens || 0) });
  }
  const pending = (await env.DB.prepare("SELECT * FROM photos WHERE trip_id=? AND installation_id=? AND (analysis_status!='complete' OR analysis_version IS NULL OR analysis_version!=?) ORDER BY sort_order LIMIT ?").bind(tripId, installationId, ANALYSIS_VERSION, ANALYSIS_BATCH_SIZE).all()).results || [];
  if (!pending.length) { await rebuildTripDerivedData(env, tripId, installationId); return getTrip(new Request(request.url, { headers: { "x-echotrip-installation": installationId } }), env, tripId); }
  const jobId = id("job"); const timestamp = now();
  await env.DB.prepare("INSERT INTO analysis_jobs (id,trip_id,installation_id,status,created_at,started_at) VALUES (?,?,?,?,?,?)").bind(jobId, tripId, installationId, "running", timestamp, timestamp).run();
  await env.DB.prepare("UPDATE trips SET status='analyzing', updated_at=? WHERE id=? AND installation_id=?").bind(timestamp, tripId, installationId).run();
  try {
    const recovery = await analyzeWithVisionRecovery(env, pending, {
      beforeCall: async ({ calls }) => {
        if (calls === 1 || !dailyLimit) return;
        const startOfDay = new Date(); startOfDay.setUTCHours(0, 0, 0, 0);
        const current = await env.DB.prepare("SELECT COALESCE(SUM(input_tokens + output_tokens), 0) AS tokens FROM ai_usage_events WHERE installation_id=? AND created_at>=?").bind(installationId, startOfDay.toISOString()).first();
        if (Number(current?.tokens || 0) >= dailyLimit) throw Object.assign(new Error("今日 AI 分析额度已用完，请明天再试"), { code:"AI_DAILY_LIMIT" });
      },
      onBatch: async ({ batch, result, accepted }) => {
        if (accepted.length) {
          await env.DB.batch(accepted.map((analysis) => env.DB.prepare("UPDATE photos SET analysis_status='complete',analysis_json=?,analysis_version=?,updated_at=? WHERE id=? AND installation_id=?")
            .bind(JSON.stringify(analysis), ANALYSIS_VERSION, now(), analysis.photo_id, installationId)));
        }
        const usage = result.usage || {};
        await env.DB.prepare("INSERT INTO ai_usage_events (id,installation_id,trip_id,feature,model,input_tokens,output_tokens,cached_tokens,image_count,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
          .bind(id("usage"), installationId, tripId, "photo_vision", result.model, Number(usage.input_tokens || 0), Number(usage.output_tokens || 0), Number(usage.input_tokens_details?.cached_tokens || 0), batch.length, now()).run();
      },
    });
    const remaining = await env.DB.prepare("SELECT COUNT(*) AS count FROM photos WHERE trip_id=? AND installation_id=? AND (analysis_status!='complete' OR analysis_version IS NULL OR analysis_version!=?)").bind(tripId, installationId, ANALYSIS_VERSION).first();
    if (!remaining?.count) await rebuildTripDerivedData(env, tripId, installationId);
    await env.DB.prepare("UPDATE analysis_jobs SET status='complete',completed_at=? WHERE id=?").bind(now(), jobId).run();
    return json({ job: { id: jobId, status: "complete", analyzed: recovery.analyzed, remaining: Number(remaining?.count || 0), recoveryCalls:recovery.calls }, tripReady: !remaining?.count });
  } catch (cause) {
    const code = cause.code || "ANALYSIS_FAILED";
    await env.DB.prepare("UPDATE analysis_jobs SET status='failed',error_code=?,error_message=?,completed_at=? WHERE id=?").bind(code, String(cause.message || cause).slice(0, 1000), now(), jobId).run();
    await env.DB.prepare("UPDATE trips SET status='analysis_failed',updated_at=? WHERE id=? AND installation_id=?").bind(now(), tripId, installationId).run();
    return error(code, cause.message || "Photo analysis failed", code === "AI_NOT_CONFIGURED" ? 503 : 502, { jobId });
  }
}

async function recordContext(request, env) {
  const body = await readJson(request);
  if (!body) return error("INVALID_JSON", "Request body must be JSON");
  const installationId = requiredInstallation(request, body);
  if (!installationId) return error("INSTALLATION_REQUIRED", "installationId is required");
  await touchInstallation(env, installationId, body);
  const eventId = id("ctx"); const occurredAt = safeDate(body.occurredAt) || now(); const latitude = roundCoarse(body.latitude); const longitude = roundCoarse(body.longitude);
  const weather = body.weatherCode ? null : await currentWeather(latitude, longitude);
  const weatherCode = body.weatherCode || weather?.code || null;
  const temperatureC = safeNumber(body.temperatureC) ?? weather?.temperatureC ?? null;
  await env.DB.prepare("INSERT INTO context_events (id,installation_id,event_type,occurred_at,latitude_coarse,longitude_coarse,weather_code,temperature_c,source,payload_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
    .bind(eventId, installationId, body.eventType || "foreground_context", occurredAt, latitude, longitude, weatherCode, temperatureC, body.source || "web_foreground", JSON.stringify({ ...(body.payload || {}), weatherProvider:weather?.provider || body.weatherProvider || null }), now()).run();
  const rows = (await env.DB.prepare("SELECT p.id,p.taken_at,p.latitude,p.longitude,p.location_name,p.city,p.analysis_json,mc.id AS memory_card_id FROM photos p LEFT JOIN moments mo ON mo.photo_id=p.id AND mo.trip_id=p.trip_id AND mo.installation_id=p.installation_id LEFT JOIN memory_cards mc ON mc.moment_id=mo.id AND mc.trip_id=p.trip_id AND mc.installation_id=p.installation_id WHERE p.installation_id=? AND p.analysis_status='complete' ORDER BY p.taken_at DESC LIMIT 200").bind(installationId).all()).results || [];
  const current = { latitude, longitude };
  const candidates = rows.map((photo) => { const analysis = photo.analysis_json ? JSON.parse(photo.analysis_json) : {}; let score = (analysis.memory_score || 0) * 0.35; const evidence = [];
    if (weatherCode && analysis.weather === weatherCode) { score += 0.3; evidence.push(`同样是${weatherCode}`); }
    const km = distanceKm(current, photo); if (km != null && km < 10) { score += 0.3 * (1 - km / 10); evidence.push(`距离旧照片约 ${Math.max(0.1, km).toFixed(1)} km`); }
    if (photo.taken_at) { const old = new Date(photo.taken_at); const currentDate = new Date(occurredAt); if (old.getMonth() === currentDate.getMonth() && Math.abs(old.getDate() - currentDate.getDate()) <= 2) { score += 0.2; evidence.push("接近往年同一日期"); } }
    return { photo, analysis, score, evidence }; }).filter((item) => item.evidence.length && item.score >= 0.45).sort((a, b) => b.score - a.score);
  const best = candidates[0]; if (!best) return json({ contextEvent: { id: eventId }, echo: null });
  const weatherZh = { sunny:"晴天", cloudy:"多云", rain:"雨天", snow:"雪天", fog:"雾天" };
  const place = chinesePlace(best.photo, best.analysis);
  const hook = best.analysis.memory_hook || best.analysis.subject || best.analysis.event_title_zh || "过去的旅程";
  const reasonParts = [];
  if (best.evidence.some((item) => item.startsWith("同样是"))) reasonParts.push(`今天与照片里同为${weatherZh[weatherCode] || "相似天气"}`);
  if (best.evidence.some((item) => item.startsWith("距离旧照片"))) reasonParts.push(`你再次靠近${place}`);
  if (best.evidence.includes("接近往年同一日期")) reasonParts.push("时间也接近当年的这一天");
  const echoId = id("echo"); const reason = `${reasonParts.join("；")}。因此把「${hook}」这张照片送回给你。`;
  await env.DB.prepare("INSERT INTO echoes (id,installation_id,memory_card_id,photo_id,trigger_event_id,reason,evidence_json,score,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
    .bind(echoId, installationId, best.photo.memory_card_id || null, best.photo.id, eventId, reason, JSON.stringify(best.evidence), best.score, "ready", now()).run();
  return json({ contextEvent: { id: eventId }, echo: { id: echoId, photoId: best.photo.id, reason, score: best.score } }, 201);
}

async function listEchoes(request, env) {
  const installationId = requiredInstallation(request);
  if (!installationId) return error("INSTALLATION_REQUIRED", "x-echotrip-installation header is required");
  const echoes = (await env.DB.prepare("SELECT * FROM echoes WHERE installation_id=? ORDER BY created_at DESC LIMIT 30").bind(installationId).all()).results || [];
  return json({ echoes: echoes.map((item) => ({ ...item, evidence: JSON.parse(item.evidence_json), evidence_json: undefined })) });
}

async function handleApi(request, env, url) {
  await ensureSchema(env);
  const path = url.pathname.slice(API_PREFIX.length) || "/";
  if (request.method === "GET" && path === "/health") return json({ ok: true, storage: { d1: !!env.DB, r2: !!env.MEDIA }, aiConfigured: !!env.OPENAI_API_KEY, capabilities:{ vision:!!env.OPENAI_API_KEY, transcription:"local-only", memoryGeneration:"deterministic", echoRecommendation:"deterministic" } });
  if (request.method === "POST" && path === "/sessions/anonymous") return createAnonymousSession(request, env);
  let match = path.match(/^\/photos\/([^/]+)\/content$/);
  if (request.method === "GET" && match) return getPhotoContent(request, env, match[1]);
  const authorizedRequest = await authorizeApiRequest(request, env);
  if (!authorizedRequest) return error("SESSION_REQUIRED", "A valid EchoTrip session is required", 401);
  request = authorizedRequest;
  if (request.method === "GET" && path === "/geocode/reverse") {
    const latitude = safeNumber(url.searchParams.get("lat")); const longitude = safeNumber(url.searchParams.get("lon"));
    if (latitude == null || longitude == null) return error("COORDINATES_REQUIRED", "Valid lat and lon are required");
    return json({ location:await reverseGeocode(env, latitude, longitude, request.headers.get("accept-language") || "zh-CN") });
  }
  if (request.method === "POST" && path === "/trips") return createTrip(request, env);
  if (request.method === "POST" && path === "/audio/transcriptions") return transcribeAudio(request, env);
  match = path.match(/^\/trips\/([^/]+)\/photos$/);
  if (request.method === "POST" && match) return uploadPhoto(request, env, match[1]);
  match = path.match(/^\/trips\/([^/]+)\/analyze$/);
  if (request.method === "POST" && match) return analyzeTrip(request, env, match[1]);
  match = path.match(/^\/trips\/([^/]+)\/moments\/([^/]+)\/memory$/);
  if (request.method === "POST" && match) return saveMemory(request, env, match[1], match[2]);
  match = path.match(/^\/trips\/([^/]+)$/);
  if (request.method === "GET" && match) return getTrip(request, env, match[1]);
  if (request.method === "POST" && path === "/context-events") return recordContext(request, env);
  if (request.method === "GET" && path === "/echoes") return listEchoes(request, env);
  return error("NOT_FOUND", "API route not found", 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith(API_PREFIX)) {
      if (request.method === "OPTIONS") {
        const headers = corsHeaders(request, env);
        return new Response(null, { status:Object.keys(headers).length ? 204 : 403, headers });
      }
      let response;
      try { response = await handleApi(request, env, url); }
      catch (cause) { response = error("INTERNAL_ERROR", cause.message || "Unexpected server error", 500); }
      return withCors(response, request, env);
    }
    const response = await env.ASSETS.fetch(request);
    const acceptsHtml = request.headers.get("accept")?.includes("text/html");
    if (response.status !== 404 || !acceptsHtml || !["GET", "HEAD"].includes(request.method)) return response;
    const indexUrl = new URL(request.url); indexUrl.pathname = "/index.html"; indexUrl.search = "";
    return env.ASSETS.fetch(new Request(indexUrl, request));
  },
};

export { analyzeWithVision as __analyzeWithVisionForTest, analyzeWithVisionRecovery as __analyzeWithVisionRecoveryForTest, validatedVisionResults as __validatedVisionResultsForTest, buildTimeline as __buildTimelineForTest, buildMoments as __buildMomentsForTest };
