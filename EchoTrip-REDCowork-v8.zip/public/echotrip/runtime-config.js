/*
 * Deployment-only configuration. Keep secrets on the API server.
 * REDCowork should set apiBase to the public EchoTrip API origin, for example:
 * window.ECHOTRIP_CONFIG = { apiBase: "https://api.example.com" };
 */
window.ECHOTRIP_CONFIG = window.ECHOTRIP_CONFIG || {
  apiBase: "https://echotrip-ai-preview.liuhc2000.chatgpt.site"
};
