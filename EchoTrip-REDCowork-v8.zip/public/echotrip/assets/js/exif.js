/* ============================================================
   EchoTrip · exif.js
   轻量 JPEG / HEIC EXIF 读取：提取拍摄时间与 GPS（若原图包含）。
   读取失败静默返回 {} —— Metadata 只是锦上添花，绝不阻塞流程。
   HEIC 使用内嵌 TIFF/Exif 签名兜底；读取不到时按导入顺序排列。
   ============================================================ */

const EXIF = (() => {

  async function read(file){
    try{
      const buf = await file.arrayBuffer();
      const dv = new DataView(buf);
      if(dv.byteLength < 8) return {};
      if(dv.getUint16(0) === 0xFFD8){
        let off = 2;
        while(off < dv.byteLength - 4){
          if(dv.getUint8(off) !== 0xFF) break;
          const marker = dv.getUint8(off + 1);
          if(marker === 0xD8 || marker === 0x01 || (marker >= 0xD0 && marker <= 0xD7)){ off += 2; continue; }
          const size = dv.getUint16(off + 2);
          if(marker === 0xE1 && size > 8 && getStr(dv, off + 4, 4) === 'Exif') return parseTiff(dv, off + 10);
          off += 2 + size;
        }
      }
      /* HEIC/HEIF 的 Exif item 在 ISO-BMFF 容器中，扫描其 TIFF 起始签名。
         这避免解码整张 HEIC；若容器不暴露标准 Exif item 则安全返回空。 */
      const base = findEmbeddedTiff(dv);
      if(base != null) return parseTiff(dv, base);
    }catch(e){ /* 静默 */ }
    return {};
  }

  function findEmbeddedTiff(dv){
    for(let i = 0; i <= dv.byteLength - 10; i++){
      if(dv.getUint32(i, false) === 0x45786966){
        const base = i + 6;
        if(isTiffHeader(dv, base)) return base;
      }
    }
    for(let i = 0; i <= dv.byteLength - 8; i++){
      const signature = dv.getUint32(i, false);
      if((signature === 0x49492A00 || signature === 0x4D4D002A) && isTiffHeader(dv, i)) return i;
    }
    return null;
  }

  function isTiffHeader(dv, off){
    if(off < 0 || off + 8 > dv.byteLength) return false;
    const order = dv.getUint16(off);
    if(order === 0x4949) return dv.getUint16(off + 2, true) === 0x002A;
    if(order === 0x4D4D) return dv.getUint16(off + 2, false) === 0x002A;
    return false;
  }

  function parseTiff(dv, base){
    if(!isTiffHeader(dv, base)) return {};
    const le = dv.getUint16(base) === 0x4949; // "II" little-endian
    const g16 = o => dv.getUint16(o, le);
    const g32 = o => dv.getUint32(o, le);
    if(g16(base + 2) !== 0x002A) return {}; // TIFF magic
    const ifd0 = base + g32(base + 4);
    if(ifd0 < base || ifd0 + 2 > dv.byteLength) return {};

    let exifIfd = null, gpsIfd = null, fallbackDate = null;
    const n = g16(ifd0);
    for(let i = 0; i < n; i++){
      const e = ifd0 + 2 + i * 12;
      if(e + 12 > dv.byteLength) break;
      const tag = g16(e);
      if(tag === 0x8769) exifIfd = base + g32(e + 8); // ExifIFD 指针
      if(tag === 0x8825) gpsIfd = base + g32(e + 8);  // GPSIFD 指针
      if(tag === 0x0132){
        const cnt = g32(e + 4), valOff = cnt > 4 ? base + g32(e + 8) : e + 8;
        fallbackDate = parseDate(getStr(dv, valOff, Math.min(cnt, 19)));
      }
    }

    const result = fallbackDate ? { date:fallbackDate } : {};
    if(exifIfd && exifIfd + 2 <= dv.byteLength){
      const m = g16(exifIfd);
      for(let i = 0; i < m; i++){
        const e = exifIfd + 2 + i * 12;
        if(e + 12 > dv.byteLength) break;
        if(g16(e) === 0x9003){ // DateTimeOriginal
          const cnt = g32(e + 4);
          const valOff = cnt > 4 ? base + g32(e + 8) : e + 8;
          const date = parseDate(getStr(dv, valOff, Math.min(cnt, 19)));
          if(date) result.date = date;
        }
      }
    }
    if(gpsIfd && gpsIfd + 2 <= dv.byteLength) Object.assign(result, parseGps(dv, base, gpsIfd, le));
    return result;
  }

  function parseGps(dv, base, ifd, le){
    const g16 = o => dv.getUint16(o, le), g32 = o => dv.getUint32(o, le);
    const values = {};
    const count = g16(ifd);
    for(let i = 0; i < count; i++){
      const e = ifd + 2 + i * 12;
      if(e + 12 > dv.byteLength) break;
      const tag = g16(e), type = g16(e + 2), len = g32(e + 4);
      const valueOff = (type === 2 && len <= 4) ? e + 8 : base + g32(e + 8);
      if(tag === 1 || tag === 3) values[tag] = getStr(dv, valueOff, Math.max(1, len - 1));
      if((tag === 2 || tag === 4) && type === 5 && len === 3){
        values[tag] = [0, 1, 2].map(index => {
          const o = valueOff + index * 8, denominator = g32(o + 4);
          return denominator ? g32(o) / denominator : 0;
        });
      }
      if(tag === 5) values[tag] = dv.getUint8(e + 8);
      if(tag === 6 && type === 5){
        const denominator = g32(valueOff + 4);
        values[tag] = denominator ? g32(valueOff) / denominator : null;
      }
    }
    const decimal = parts => parts && parts.length === 3 ? parts[0] + parts[1] / 60 + parts[2] / 3600 : null;
    let latitude = decimal(values[2]), longitude = decimal(values[4]);
    if(latitude != null && String(values[1]).toUpperCase() === 'S') latitude *= -1;
    if(longitude != null && String(values[3]).toUpperCase() === 'W') longitude *= -1;
    const result = {};
    if(latitude != null && longitude != null){ result.latitude = latitude; result.longitude = longitude; }
    if(values[6] != null) result.altitude = values[5] === 1 ? -values[6] : values[6];
    return result;
  }

  function getStr(dv, off, len){
    let s = '';
    for(let i = 0; i < len; i++) s += String.fromCharCode(dv.getUint8(off + i));
    return s;
  }

  /* "YYYY:MM:DD HH:MM:SS" → Date */
  function parseDate(s){
    const m = /^(\d{4}):(\d{2}):(\d{2})[ ](\d{2}):(\d{2}):(\d{2})/.exec(s || '');
    if(!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  }

  return { read };
})();
