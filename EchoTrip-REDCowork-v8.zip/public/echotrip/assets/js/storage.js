/* EchoTrip local repository.
   Stores real image blobs in IndexedDB so imported journeys survive refreshes.
   The API intentionally mirrors a future remote repository. */
const LocalDB = (() => {
  const DB_NAME = 'echotrip-local';
  const DB_VERSION = 2;
  const TRIPS = 'trips';
  const PHOTOS = 'photos';
  const AUDIO = 'audio';
  const objectUrls = new Set();

  function request(req){
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('IndexedDB request failed'));
    });
  }

  function transactionDone(tx){
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
      tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
    });
  }

  function open(){
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if(!db.objectStoreNames.contains(TRIPS)) db.createObjectStore(TRIPS, { keyPath: 'id' });
        if(!db.objectStoreNames.contains(PHOTOS)){
          const store = db.createObjectStore(PHOTOS, { keyPath: 'id' });
          store.createIndex('tripId', 'tripId', { unique: false });
        }
        if(!db.objectStoreNames.contains(AUDIO)){
          const store = db.createObjectStore(AUDIO, { keyPath: 'id' });
          store.createIndex('tripId', 'tripId', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('Unable to open local database'));
    });
  }

  function iso(value){
    if(value instanceof Date) return value.toISOString();
    return value || null;
  }

  function stripRuntime(value){
    if(Array.isArray(value)) return value.map(stripRuntime);
    if(!value || typeof value !== 'object' || value instanceof Blob || value instanceof Date) return value;
    const out = {};
    Object.entries(value).forEach(([key, child]) => {
      if(key === 'src' && typeof child === 'string' && child.startsWith('blob:')) return;
      if(key === 'imageSrc' && typeof child === 'string' && child.startsWith('blob:')) return;
      if(key === 'audioUrl' && typeof child === 'string' && child.startsWith('blob:')) return;
      if(key === 'blob' || key === '_blob' || key === 'audioBlob' || key.startsWith('__')) return;
      out[key] = key === 'time' || key === 'date' ? iso(child) : stripRuntime(child);
    });
    return out;
  }

  async function saveTrips(trips){
    const db = await open();
    const tx = db.transaction([TRIPS, PHOTOS, AUDIO], 'readwrite');
    const tripStore = tx.objectStore(TRIPS);
    const photoStore = tx.objectStore(PHOTOS);
    const audioStore = tx.objectStore(AUDIO);
    tripStore.clear();
    photoStore.clear();
    audioStore.clear();

    trips.forEach(trip => {
      const record = stripRuntime(trip);
      record.photos = (trip.photos || []).map(photo => {
        const clean = stripRuntime(photo);
        const blob = photo.blob || photo._blob;
        if(blob instanceof Blob){
          photoStore.put({ id: clean.id, tripId: trip.id, blob, name: clean.name || '', type: blob.type || clean.type || '', size: blob.size, time: iso(photo.time), location: clean.location || '', alt: clean.alt || '' });
          delete clean.src;
        }
        return clean;
      });
      record.cards = (trip.cards || []).map(card => {
        const clean = stripRuntime(card);
        if(card.audioBlob instanceof Blob){
          audioStore.put({
            id: clean.id, tripId: trip.id, blob: card.audioBlob,
            mimeType: card.audioMimeType || card.audioBlob.type || '',
            duration: card.audioDuration || 0,
          });
        }
        return clean;
      });
      tripStore.put(record);
    });

    await transactionDone(tx);
    db.close();
  }

  async function loadTrips(){
    const db = await open();
    const tx = db.transaction([TRIPS, PHOTOS, AUDIO], 'readonly');
    const trips = await request(tx.objectStore(TRIPS).getAll());
    const photoRows = await request(tx.objectStore(PHOTOS).getAll());
    const audioRows = await request(tx.objectStore(AUDIO).getAll());
    await transactionDone(tx);
    db.close();

    const photosById = new Map(photoRows.map(row => [row.id, row]));
    const audioById = new Map(audioRows.map(row => [row.id, row]));
    return trips.map(trip => {
      const srcById = new Map();
      trip.photos = (trip.photos || []).map(photo => {
        const row = photosById.get(photo.id);
        if(!row) return photo;
        const src = URL.createObjectURL(row.blob);
        objectUrls.add(src);
        srcById.set(photo.id, src);
        return { ...photo, src, blob: row.blob, time: photo.time || row.time, name: photo.name || row.name, location: photo.location || row.location, alt: photo.alt || row.alt };
      });
      trip.coverSrc = (trip.coverPhotoId && srcById.get(trip.coverPhotoId)) || trip.coverSrc;
      trip.moments = (trip.moments || []).map(moment => ({ ...moment, imageSrc: (moment.photoId && srcById.get(moment.photoId)) || moment.imageSrc }));
      trip.cards = (trip.cards || []).map(card => {
        const row = audioById.get(card.id);
        let audioUrl = card.audioUrl;
        if(row && row.blob){ audioUrl = URL.createObjectURL(row.blob); objectUrls.add(audioUrl); }
        return {
          ...card,
          imageSrc: (card.photoId && srcById.get(card.photoId)) || card.imageSrc,
          audioBlob: row ? row.blob : undefined,
          audioUrl,
          audioMimeType: (row && row.mimeType) || card.audioMimeType || '',
          audioDuration: (row && row.duration) || card.audioDuration || 0,
        };
      });
      return trip;
    });
  }

  function revokeRuntimeUrls(){
    objectUrls.forEach(url => URL.revokeObjectURL(url));
    objectUrls.clear();
  }

  return { loadTrips, saveTrips, revokeRuntimeUrls };
})();
