/* EchoTrip cloud repository.
   Uses anonymous installation identity for the demo phase. No fake AI response is
   generated here: if the backend or AI secret is unavailable, callers receive a
   typed error and can explicitly remain in local prototype mode. */
const CloudAPI = (() => {
  const configuredBase = String(window.ECHOTRIP_CONFIG?.apiBase || '').trim().replace(/\/$/, '');
  const BASE = `${configuredBase}/api/v1`;
  const INSTALLATION_KEY = 'echotrip-installation-id';
  const SESSION_KEY = `echotrip-session:${configuredBase || 'same-origin'}`;
  let availability;
  let sessionPromise;
  const geocodeCache = new Map();
  let geocodeQueue = Promise.resolve(), lastPublicGeocodeAt = 0;

  function installationId(){
    let value = localStorage.getItem(INSTALLATION_KEY);
    if(!value){ value = `install_${crypto.randomUUID()}`; localStorage.setItem(INSTALLATION_KEY, value); }
    return value;
  }

  async function sessionToken(){
    const cached = localStorage.getItem(SESSION_KEY);
    if(cached) return cached;
    if(sessionPromise) return sessionPromise;
    sessionPromise = fetch(BASE + '/sessions/anonymous', {
      method:'POST', headers:{ 'content-type':'application/json' },
      body:JSON.stringify({ installationId:installationId(), timezone:Intl.DateTimeFormat().resolvedOptions().timeZone, locale:navigator.language }),
    }).then(async response => {
      const payload = await response.json().catch(() => ({}));
      if(!response.ok) throw Object.assign(new Error(payload.error?.message || '无法建立安全会话'), { code:payload.error?.code || 'SESSION_FAILED', status:response.status });
      if(payload.installationId && payload.installationId !== installationId()) localStorage.setItem(INSTALLATION_KEY, payload.installationId);
      if(payload.token) localStorage.setItem(SESSION_KEY, payload.token);
      return payload.token || '';
    }).finally(() => { sessionPromise = null; });
    return sessionPromise;
  }

  async function request(path, options = {}, retrySession = true){
    const { timeoutMs = 0, ...fetchOptions } = options;
    const headers = new Headers(options.headers || {});
    headers.set('x-echotrip-installation', installationId());
    if(path !== '/health' && path !== '/sessions/anonymous'){
      const token = await sessionToken();
      if(token) headers.set('authorization', `Bearer ${token}`);
    }
    const controller = timeoutMs ? new AbortController() : null;
    const timeout = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
    if(controller && options.signal) options.signal.addEventListener('abort', () => controller.abort(), { once:true });
    let response;
    try{
      response = await fetch(BASE + path, { ...fetchOptions, headers, signal:controller?.signal || options.signal });
    }catch(cause){
      if(cause?.name === 'AbortError') throw Object.assign(new Error('AI 分析等待超时，正在检查后台结果'), { code:'REQUEST_TIMEOUT' });
      throw cause;
    }finally{
      if(timeout) clearTimeout(timeout);
    }
    const payload = await response.json().catch(() => ({}));
    if(!response.ok){
      if(response.status === 401 && payload.error?.code === 'SESSION_REQUIRED' && retrySession){
        localStorage.removeItem(SESSION_KEY);
        return request(path, options, false);
      }
      const err = new Error(payload.error?.message || `EchoTrip API ${response.status}`);
      err.code = payload.error?.code || 'API_ERROR';
      err.status = response.status;
      err.details = payload.error?.details;
      throw err;
    }
    return payload;
  }

  async function status(){
    if(availability) return availability;
    availability = request('/health').catch(() => null);
    return availability;
  }

  async function analysisPreview(blob){
    try{
      const bitmap = await createImageBitmap(blob);
      const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * scale)); canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      canvas.getContext('2d', { alpha:false }).drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close();
      return await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', .8));
    }catch(e){ return null; }
  }

  function normalizeGeocode(payload){
    const address = payload?.address || {};
    const names = payload?.namedetails || {};
    const city = address.city || address.town || address.village || address.municipality || address.county || null;
    const detail = address.attraction || address.tourism || address.building || address.neighbourhood || address.suburb || address.road || null;
    return {
      locationName:names['name:zh-Hans'] || names['name:zh'] || names['name:zh-Hant'] || [city, detail].filter((value, index, list) => value && list.indexOf(value) === index).join(' · ') || payload?.name || null,
      city, country:address.country || null, countryCode:(address.country_code || '').toUpperCase() || null,
      provider:'openstreetmap-nominatim',
    };
  }

  async function reverseGeocode(latitude, longitude){
    if(!Number.isFinite(latitude) || !Number.isFinite(longitude) || (latitude === 0 && longitude === 0)) return null;
    const key = `${latitude.toFixed(3)},${longitude.toFixed(3)},${navigator.language || 'zh-CN'}`;
    if(geocodeCache.has(key)) return geocodeCache.get(key);
    const task = async () => {
      try{
        const result = await request(`/geocode/reverse?lat=${encodeURIComponent(latitude)}&lon=${encodeURIComponent(longitude)}`, { headers:{ 'accept-language':navigator.language || 'zh-CN' } });
        if(result.location) return result.location;
      }catch(e){
        if(!['127.0.0.1', 'localhost'].includes(location.hostname)) return null;
      }
      const wait = Math.max(0, 1100 - (Date.now() - lastPublicGeocodeAt));
      if(wait) await new Promise(resolve => setTimeout(resolve, wait));
      const url = new URL('https://nominatim.openstreetmap.org/reverse');
      url.searchParams.set('format', 'jsonv2'); url.searchParams.set('lat', latitude); url.searchParams.set('lon', longitude);
      url.searchParams.set('zoom', '16'); url.searchParams.set('addressdetails', '1'); url.searchParams.set('namedetails', '1'); url.searchParams.set('accept-language', 'zh-CN,zh;q=0.9');
      const response = await fetch(url, { headers:{ accept:'application/json' } });
      lastPublicGeocodeAt = Date.now();
      return response.ok ? normalizeGeocode(await response.json()) : null;
    };
    geocodeQueue = geocodeQueue.then(task, task);
    const resultPromise = geocodeQueue.then(result => { geocodeCache.set(key, result); return result; });
    geocodeCache.set(key, resultPromise);
    return resultPromise;
  }

  async function createAndUploadTrip(trip, onProgress){
    const health = await status();
    if(!health?.ok) return null;
    const created = await request('/trips', {
      method:'POST', headers:{ 'content-type':'application/json' },
      body:JSON.stringify({ installationId:installationId(), name:trip.name, destination:trip.destination, timezone:Intl.DateTimeFormat().resolvedOptions().timeZone, locale:navigator.language }),
    });
    trip.cloudId = created.trip.id;
    let nextIndex = 0, uploadedCount = 0;
    const uploadOne = async i => {
      const photo = trip.photos[i];
      if(!(photo.blob instanceof Blob)) return;
      const form = new FormData();
      form.set('installationId', installationId());
      form.set('photo', photo.blob, photo.name || `photo-${i + 1}.jpg`);
      const preview = await analysisPreview(photo.blob);
      if(preview) form.set('analysisPhoto', preview, `analysis-${i + 1}.jpg`);
      form.set('metadata', JSON.stringify({
        takenAt: photo.time instanceof Date ? photo.time.toISOString() : photo.time,
        timeSource: photo.timeSource || null,
        latitude: photo.latitude ?? null, longitude: photo.longitude ?? null, altitude: photo.altitude ?? null,
        locationName:photo.location || null, city:photo.city || null, country:photo.country || null, countryCode:photo.countryCode || null,
        locationSource:photo.locationSource || null, locale:navigator.language || 'zh-CN',
        width: photo.width || null, height: photo.height || null, sortOrder:i,
      }));
      const uploaded = await request(`/trips/${trip.cloudId}/photos`, { method:'POST', body:form });
      photo.cloudId = uploaded.photo.id;
      if(uploaded.photo.location){
        photo.location = uploaded.photo.location.locationName || photo.location;
        photo.city = uploaded.photo.location.city || photo.city;
        photo.country = uploaded.photo.location.country || photo.country;
        photo.countryCode = uploaded.photo.location.countryCode || photo.countryCode;
        photo.locationSource = uploaded.photo.location.provider || photo.locationSource;
      }
      uploadedCount += 1;
      onProgress && onProgress({ uploaded:uploadedCount, total:trip.photos.length });
    };
    const worker = async () => {
      while(nextIndex < trip.photos.length){
        const index = nextIndex++;
        await uploadOne(index);
      }
    };
    const concurrency = Math.min(3, Math.max(1, trip.photos.length));
    await Promise.all(Array.from({ length:concurrency }, worker));
    return trip.cloudId;
  }

  async function analyzeTrip(trip, onProgress){
    if(!trip.cloudId) throw Object.assign(new Error('Trip has not been uploaded'), { code:'TRIP_NOT_UPLOADED' });
    const readTrip = () => request(`/trips/${trip.cloudId}`, { timeoutMs:15000 }).then(result => result.trip);
    const initial = await readTrip();
    if(initial.status === 'ready') return initial;
    let remaining = (initial.photos || []).filter(photo => photo.analysis_status !== 'complete').length;
    let analyzed = Math.max(0, trip.photos.length - remaining), rounds = 0;
    const maxRounds = Math.ceil(Math.max(1, trip.photos.length) / 16) + 1;
    while(remaining > 0){
      if(rounds++ >= maxRounds) throw Object.assign(new Error('照片分析没有按预期完成，请稍后重试'), { code:'ANALYSIS_NO_PROGRESS' });
      const previousRemaining = remaining;
      let result;
      try{
        result = await request(`/trips/${trip.cloudId}/analyze`, {
          method:'POST', headers:{ 'content-type':'application/json' }, body:JSON.stringify({ installationId:installationId() }), timeoutMs:60000,
        });
      }catch(cause){
        const latest = await readTrip().catch(() => null);
        if(latest?.status === 'ready') return latest;
        throw cause;
      }
      analyzed += result.job?.analyzed || 0;
      remaining = result.job?.remaining || 0;
      if(remaining > 0 && remaining >= previousRemaining) throw Object.assign(new Error('照片分析进度停滞，已停止自动重试'), { code:'ANALYSIS_NO_PROGRESS' });
      onProgress && onProgress({ analyzed, remaining, total:trip.photos.length });
    }
    return readTrip();
  }

  function audioFilename(blob){
    const type = blob?.type || '';
    if(type.includes('mp4')) return 'memory.m4a';
    if(type.includes('ogg')) return 'memory.ogg';
    if(type.includes('wav')) return 'memory.wav';
    return 'memory.webm';
  }

  async function saveMemory(trip, moment, transcript, voice){
    if(!trip?.cloudId || !moment?.id) throw Object.assign(new Error('旅程尚未同步到云端'), { code:'TRIP_NOT_UPLOADED' });
    const form = new FormData();
    form.set('installationId', installationId());
    form.set('transcript', transcript || '');
    form.set('transcriptSource', voice?.transcriptSource || 'user-text');
    form.set('audioDuration', String(voice?.duration || 0));
    if(voice?.blob instanceof Blob && voice.blob.size) form.set('audio', voice.blob, audioFilename(voice.blob));
    return request(`/trips/${trip.cloudId}/moments/${moment.id}/memory`, { method:'POST', body:form });
  }

  async function recordForegroundContext(context){
    return request('/context-events', { method:'POST', headers:{ 'content-type':'application/json' }, body:JSON.stringify({ ...context, installationId:installationId() }) });
  }

  async function captureForegroundContext(){
    if(!navigator.geolocation) throw Object.assign(new Error('当前设备不支持定位'), { code:'GEOLOCATION_UNAVAILABLE' });
    const position = await new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy:false, timeout:10000, maximumAge:15 * 60 * 1000 }));
    return recordForegroundContext({
      eventType:'foreground_context', occurredAt:new Date().toISOString(), source:'web_foreground',
      latitude:position.coords.latitude, longitude:position.coords.longitude,
      payload:{ accuracyMeters:Math.round(position.coords.accuracy || 0) },
    });
  }

  async function listEchoes(){ return (await request('/echoes')).echoes; }

  return { installationId, sessionToken, status, reverseGeocode, createAndUploadTrip, analyzeTrip, saveMemory, recordForegroundContext, captureForegroundContext, listEchoes };
})();
