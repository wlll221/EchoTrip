/* ============================================================
   EchoTrip · data.js
   数据结构 + Mock AI 层
   ------------------------------------------------------------
   ⚠️ FUTURE AI INTEGRATION（未来接入真实 AI 时阅读这里）：
   本文件是整个"AI 能力"的唯一数据源。所有以 ai* 开头的函数
   都是 Mock 实现，未来替换为真实 API 调用时，只需：
     1. 保持函数签名与返回结构不变（Promise + 相同 JSON shape）
     2. 将函数体替换为 fetch('/api/...') 调用
   例如：
     async function aiAnalyzeTrip(trip, onStage){
       const res = await fetch('/api/trips/analyze', {
         method:'POST',
         headers:{ 'Content-Type':'application/json' },
         body: JSON.stringify({ tripId: trip.id, photoCount: trip.photos.length })
       })
       return res.json()   // → { timeline, moments } 与本文件结构一致
     }
   页面层（app.js）不感知数据来自 Mock 还是真实模型。
   ============================================================ */

/* ---------- 实体结构 ----------
   Trip:       { id, name, destination, startDate, endDate, photos[], photosCount, timeline[] }
   TimelineNode: { day, date, weekday, time, location, tag, photoIds[], photoCount }
   Moment:     { id, imageSrc, imageAlt, date, location, title, reason, prompt,
                 transcript, tidied, cardTitle, context, userAdded? }
   MemoryCard: { id, momentId, title, imageSrc, imageAlt, memory, date, location, context }
   Echo:       { id, memoryCardId, triggerType, triggerReason, echoDate }
---------------------------------------------------------- */

/* 示例照片库（用户不上传照片时使用；也是"添加自己的瞬间"的选择池） */
const SAMPLE_PHOTOS = [
  { id:'p01', file:'assets/photos/p01.svg', time:'2026-06-18T14:32', location:'羽田机场',        alt:'舷窗外的黄昏' },
  { id:'p02', file:'assets/photos/p02.svg', time:'2026-06-18T15:40', location:'京急线',          alt:'车窗与掠过的风景' },
  { id:'p03', file:'assets/photos/p03.svg', time:'2026-06-18T16:35', location:'新宿 · 酒店',     alt:'酒店房间的一角' },
  { id:'p04', file:'assets/photos/p04.svg', time:'2026-06-18T18:15', location:'新宿街头',        alt:'黄昏的街与霓虹' },
  { id:'p05', file:'assets/photos/p05.svg', time:'2026-06-18T19:47', location:'新宿 · 歌舞伎町后巷', alt:'吧台上的那碗拉面' },
  { id:'p06', file:'assets/photos/p06.svg', time:'2026-06-18T19:52', location:'新宿 · 歌舞伎町后巷', alt:'雨中的拉面店门口' },
  { id:'p07', file:'assets/photos/p07.svg', time:'2026-06-20T06:07', location:'筑地附近',        alt:'清晨无人的街道' },
  { id:'p08', file:'assets/photos/p08.svg', time:'2026-06-19T09:20', location:'明治神宫',        alt:'参道与鸟居' },
  { id:'p09', file:'assets/photos/p09.svg', time:'2026-06-19T11:47', location:'一家搜不到名字的咖啡馆', alt:'窗边的咖啡' },
  { id:'p10', file:'assets/photos/p10.svg', time:'2026-06-19T14:05', location:'美术馆',          alt:'展厅的一角' },
  { id:'p11', file:'assets/photos/p11.svg', time:'2026-06-19T20:10', location:'涩谷',            alt:'涩谷的夜与人流' },
  { id:'p12', file:'assets/photos/p12.svg', time:'2026-06-19T17:32', location:'幡谷 · 一个普通的路口', alt:'普通的小路口' },
  { id:'p13', file:'assets/photos/p13.svg', time:'2026-06-19T13:12', location:'表参道后巷',      alt:'巷子里的自动贩卖机' },
  { id:'p14', file:'assets/photos/p14.svg', time:'2026-06-19T20:41', location:'涩谷',            alt:'失焦的灯光' },
  { id:'p15', file:'assets/photos/p15.svg', time:'2026-06-20T06:25', location:'筑地市场',        alt:'市场的早晨' },
  { id:'p16', file:'assets/photos/p16.svg', time:'2026-06-20T11:20', location:'前往机场的列车',  alt:'车窗外的海岸线' },
];
const sampleSrc = id => (SAMPLE_PHOTOS.find(p => p.id === id) || {}).file || '';

/* Mock 的旅行 Timeline（AI 重建结果） */
const SAMPLE_TIMELINE = [
  { day:1, date:'6月18日', weekday:'星期四', time:'14:32', location:'羽田机场',        tag:'落地',      photoIds:['p01'],          photoCount:3 },
  { day:1, date:'6月18日', weekday:'星期四', time:'15:40', location:'京急线 → 品川',   tag:'移动',      photoIds:['p02'],          photoCount:5 },
  { day:1, date:'6月18日', weekday:'星期四', time:'16:35', location:'新宿 · 酒店',     tag:'入住',      photoIds:['p03'],          photoCount:2 },
  { day:1, date:'6月18日', weekday:'星期四', time:'18:15', location:'新宿街头',        tag:'黄昏散步',  photoIds:['p04'],          photoCount:6 },
  { day:1, date:'6月18日', weekday:'星期四', time:'19:40', location:'拉面店 · 雨',     tag:'晚餐',      photoIds:['p05','p06'],    photoCount:3 },
  { day:2, date:'6月19日', weekday:'星期五', time:'09:20', location:'明治神宫',        tag:'上午',      photoIds:['p08'],          photoCount:12 },
  { day:2, date:'6月19日', weekday:'星期五', time:'11:47', location:'一家咖啡馆',      tag:'咖啡',      photoIds:['p09'],          photoCount:4 },
  { day:2, date:'6月19日', weekday:'星期五', time:'14:00', location:'美术馆',          tag:'下午',      photoIds:['p10'],          photoCount:9 },
  { day:2, date:'6月19日', weekday:'星期五', time:'17:32', location:'幡谷 · 路口',     tag:'路过',      photoIds:['p12'],          photoCount:11 },
  { day:2, date:'6月19日', weekday:'星期五', time:'20:10', location:'涩谷',            tag:'夜景',      photoIds:['p11','p14'],    photoCount:14 },
  { day:3, date:'6月20日', weekday:'星期六', time:'06:07', location:'筑地市场',        tag:'清晨',      photoIds:['p15','p07'],    photoCount:8 },
  { day:3, date:'6月20日', weekday:'星期六', time:'11:20', location:'前往机场的列车',  tag:'回程',      photoIds:['p16'],          photoCount:6 },
  { day:3, date:'6月20日', weekday:'星期六', time:'13:55', location:'羽田机场',        tag:'返程',      photoIds:[],              photoCount:0 },
];

/* Mock 的 8 个 Moments（AI 发现结果）
   原则：AI 只陈述观察与上下文，不解释情感意义 —— 意义由用户提供。 */
const SAMPLE_MOMENTS = [
  {
    id:'rain_ramen',
    imageSrc: sampleSrc('p05'),
    imageAlt:'雨夜，吧台上的一碗拉面',
    date:'2026-06-18T19:47',
    location:'新宿 · 歌舞伎町后巷',
    title:'雨里的那碗拉面',
    reason:'那天下午的雨突然变大。这是你在室内连续拍下的 3 张照片之一——对一个只是落脚躲雨的地方来说，快门次数有点多。',
    prompt:'那天下雨的时候，这里发生了什么？',
    transcript:'那天下特别大的雨，我们本来就想进去躲一下，结果发现这家拉面特别好吃。',
    tidied:'那天下着很大的雨，我们本来只是想进去躲一下，结果发现这家拉面特别好吃。',
    cardTitle:'雨里的那碗拉面',
    context:'这是你那天下午步行 4.2 km 之后，坐下来的第一个地方。',
  },
  {
    id:'first_photo',
    imageSrc: sampleSrc('p01'),
    imageAlt:'舷窗外的黄昏',
    date:'2026-06-18T14:32',
    location:'羽田机场',
    title:'落地后的第一张照片',
    reason:'这是你抵达东京后拍下的第一张照片。旅程的第一张照片很少有人精选，但它记得一切是怎么开始的。',
    prompt:'落地那一刻，你在想什么？',
    transcript:'落地的时候其实已经很累了，但是看到窗外的天突然觉得，啊，真的来了。',
    tidied:'落地的时候其实已经很累了，但看到窗外的天突然觉得——啊，真的来了。',
    cardTitle:'落地之后',
    context:'拍下它时，你离开家门已经 11 个小时。',
  },
  {
    id:'morning_street',
    imageSrc: sampleSrc('p07'),
    imageAlt:'清晨无人的街道',
    date:'2026-06-20T06:07',
    location:'筑地市场附近',
    title:'清晨 6 点的街道',
    reason:'这是整趟旅行中唯一一张在清晨 6 点前拍下的照片。那几天的你，只有这一次醒得比城市早。',
    prompt:'那天为什么起得这么早？',
    transcript:'就想着去筑地看看，结果太早了，店都没开，就在附近瞎逛。',
    tidied:'就想着去筑地看看，结果到得太早了，店都没开，就在附近瞎逛。',
    cardTitle:'比城市醒得早',
    context:'这是你全程步行速度最快的一段路——1.8 km，21 分钟。',
  },
  {
    id:'eleven_shots',
    imageSrc: sampleSrc('p12'),
    imageAlt:'一个普通的小路口',
    date:'2026-06-19T17:32',
    location:'幡谷 · 一个普通的路口',
    title:'连拍了 11 张的小路口',
    reason:'你在这里连续按了 11 次快门，而这里并不是任何攻略里的景点。有些地方会留住我们，说不清为什么。',
    prompt:'还记得为什么在这里停下来吗？',
    transcript:'说不上来，就是觉得那个路口的光很好看，电线杆啊自行车啊都在合适的位置。',
    tidied:'说不上来，就是觉得那个路口的光很好看，电线杆、自行车都在合适的位置。',
    cardTitle:'11 次快门',
    context:'这 11 张照片之间，你只挪动了两步。',
  },
  {
    id:'between_plans',
    imageSrc: sampleSrc('p13'),
    imageAlt:'巷子里的自动贩卖机',
    date:'2026-06-19T13:12',
    location:'表参道后巷',
    title:'两段行程之间',
    reason:'这张照片夹在两个计划好的行程之间——不在出发前的时间表上，也不在去下一站的路上。它可能是一段没有计划过的停留。',
    prompt:'这段没有计划的停留里，发生了什么？',
    transcript:'等朋友买水，就在巷子口站着，看到那台贩卖机亮得特别好看。',
    tidied:'等朋友买水，就在巷子口站着，看到那台贩卖机亮得特别好看。',
    cardTitle:'两段行程之间',
    context:'你在这条巷子里停留了 9 分钟。',
  },
  {
    id:'blurry',
    imageSrc: sampleSrc('p14'),
    imageAlt:'失焦的灯光',
    date:'2026-06-19T20:41',
    location:'涩谷',
    title:'一张有点模糊的照片',
    reason:'这张照片失焦了，但你没有删掉它。拍糊的瞬间往往说明：当时你正忙着经历，而不是记录。',
    prompt:'按下快门那一秒，正在发生什么？',
    transcript:'人太多了，被人流推着走，手一抖就拍糊了，但是那些灯真的很好看。',
    tidied:'人太多了，被人流推着走，手一抖就拍糊了，但那些灯真的很好看。',
    cardTitle:'拍糊的那一秒',
    context:'这是 Day 2 你拍的第 87 张，也是最后一张。',
  },
  {
    id:'coffee',
    imageSrc: sampleSrc('p09'),
    imageAlt:'窗边的咖啡',
    date:'2026-06-19T11:47',
    location:'一家搜不到名字的咖啡馆',
    title:'没写进行程的咖啡',
    reason:'这趟旅行你拍过好几家咖啡馆，只有这一家不在任何计划里。它出现的位置，离你原本要去的店隔了两条街。',
    prompt:'为什么会走进这家店？',
    transcript:'本来要去另一家的，走错了路，看到这家窗边位置很空就进去了。',
    tidied:'本来要去另一家的，走错了路，看到这家窗边的位置很空，就进去了。',
    cardTitle:'搜不到名字的咖啡',
    context:'这张照片之后，你把相机收进了包里——直到傍晚才再拿出来。',
  },
  {
    id:'window_ride',
    imageSrc: sampleSrc('p16'),
    imageAlt:'车窗外的海岸线',
    date:'2026-06-20T11:20',
    location:'前往机场的列车',
    title:'40 分钟的窗外',
    reason:'这是一段 40 分钟的车程。你拍了窗外——没有景点，没有人物，只有路。旅行的最后一天，人常常会安静下来。',
    prompt:'回程的车上，你在想什么？',
    transcript:'有点舍不得，就一直在看窗外，也没在想什么具体的事。',
    tidied:'有点舍不得，就一直在看窗外，也没在想什么具体的事。',
    cardTitle:'最后的 40 分钟',
    context:'这是这段旅程的第 214 张，也是最后一张照片。',
  },
];

/* AI 分析阶段的文案（Analyzing 页） */
const ANALYZE_STAGES = [
  { key:'time',    label:'正在读取照片里的时间和地点',   ms:1900 },
  { key:'events',  label:'正在识别连续发生的场景',       ms:1700 },
  { key:'tl',      label:'正在重新拼起这趟旅行',         ms:1600 },
  { key:'moments', label:'正在寻找可能值得记住的瞬间',   ms:1900 },
];

let _uid = 0;
const uid = prefix => `${prefix}_${Date.now().toString(36)}${(_uid++).toString(36)}`;

/* ============================================================
   Mock AI 函数 —— 未来全部替换为真实 API，签名与结构保持不变
   ============================================================ */

/**
 * 构建一次 Trip（把用户上传的照片映射到 Mock Timeline / Moments）
 * ⚠️ FUTURE AI：上传照片后应由后端真实分析（视觉 + EXIF），
 *   返回同样结构的 { timeline, moments }。
 * @param {string} name 旅程名
 * @param {string} destination 目的地
 * @param {Array<{src,time?,location?,name?}>} userPhotos 用户上传的照片（可为空）
 */
function _photoDate(photo){
  if(photo.time instanceof Date && !Number.isNaN(photo.time.getTime())) return photo.time;
  if(photo.time){ const d = new Date(photo.time); if(!Number.isNaN(d.getTime())) return d; }
  return null;
}
function _dateKey(date){ return date ? `${date.getFullYear()}-${_pad0(date.getMonth() + 1)}-${_pad0(date.getDate())}` : ''; }
function _dayTag(date){
  if(!date) return '照片';
  const h = date.getHours();
  if(h < 7) return '清晨';
  if(h < 12) return '上午';
  if(h < 17) return '下午';
  if(h < 20) return '傍晚';
  return '夜晚';
}
function _dayLabel(date){ return date ? `${date.getMonth() + 1}月${date.getDate()}日` : '日期待补充'; }
function _weekday(date){ return date ? `星期${'日一二三四五六'[date.getDay()]}` : '' ; }
function _timeLabel(date){ return date ? `${_pad0(date.getHours())}:${_pad0(date.getMinutes())}` : '--:--'; }

function _distanceKm(a, b){
  if(!Number.isFinite(a?.latitude) || !Number.isFinite(a?.longitude) || !Number.isFinite(b?.latitude) || !Number.isFinite(b?.longitude)) return null;
  const rad = value => value * Math.PI / 180;
  const dLat = rad(b.latitude - a.latitude), dLon = rad(b.longitude - a.longitude);
  const lat1 = rad(a.latitude), lat2 = rad(b.latitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}
function _placeKey(value){ return String(value || '').trim().toLowerCase().replace(/[·,，\s]+/g, ''); }
function _hasChinese(value){ return /[\u3400-\u9fff]/.test(String(value || '')); }
function _countryNameZh(code){
  if(!code) return '';
  try{ return new Intl.DisplayNames(['zh-CN'], { type:'region' }).of(String(code).toUpperCase()) || ''; }
  catch(e){ return ''; }
}
function _analysisOf(photo){ return photo?.analysis || photo?.aiAnalysis || {}; }
const _PLACE_ZH_ALIASES = [
  [/zlatibor|златибор/i, '兹拉蒂博尔'],
  [/zemun|земун/i, '泽蒙'],
  [/novi\s*beograd|нови\s*београд/i, '新贝尔格莱德'],
  [/beograd|belgrade|београд/i, '贝尔格莱德'],
  [/novi\s*sad|нови\s*сад/i, '诺维萨德'],
];
function _knownPlaceFromText(values){
  const text = (values || []).filter(Boolean).join(' · ');
  return _PLACE_ZH_ALIASES.find(([pattern]) => pattern.test(text))?.[1] || '';
}
function _knownPlaceFromCoordinates(photo){
  const lat = Number(photo?.latitude), lon = Number(photo?.longitude);
  if(!Number.isFinite(lat) || !Number.isFinite(lon)) return '';
  if(lat >= 43.55 && lat <= 43.86 && lon >= 19.45 && lon <= 19.98) return '兹拉蒂博尔';
  if(lat >= 44.79 && lat <= 44.95 && lon >= 20.25 && lon <= 20.45) return '泽蒙';
  if(lat >= 44.68 && lat <= 44.94 && lon >= 20.25 && lon <= 20.68) return '贝尔格莱德';
  if(lat >= 45.15 && lat <= 45.38 && lon >= 19.65 && lon <= 20.05) return '诺维萨德';
  return '';
}
function _localizedPhotoLocation(photo){
  const analysis = _analysisOf(photo);
  const candidates = [analysis.place_name_zh, analysis.landmark_guess, photo.location, photo.city];
  const known = _knownPlaceFromCoordinates(photo) || _knownPlaceFromText(candidates);
  if(known) return known;
  const chinese = candidates.find(_hasChinese);
  if(chinese) return String(chinese).trim().slice(0, 24);
  const country = _countryNameZh(photo.countryCode);
  return country ? `${country}·当地街区` : '地点待补充';
}
function _overlapCount(a, b){
  const values = new Set((a || []).map(_placeKey).filter(Boolean));
  return (b || []).map(_placeKey).filter(value => values.has(value)).length;
}
function _timelineEventTitle(photos){
  const analyses = photos.map(_analysisOf);
  const explicit = mostCommon(analyses.map(analysis => analysis.event_title_zh));
  if(explicit && _hasChinese(explicit)) return Array.from(explicit).slice(0, 8).join('');
  const group = mostCommon(analyses.map(analysis => analysis.semantic_group)) || 'other';
  const groupTitles = { sightseeing:'探访城市地标', food:'品尝当地美食', transport:'旅途移动', shopping:'街区购物', nature:'亲近自然', people:'旅伴相聚', lodging:'入住休息', leisure:'悠闲漫步' };
  if(groupTitles[group]) return groupTitles[group];
  const date = _photoDate(photos[0]);
  const period = !date ? '' : date.getHours() < 7 ? '清晨' : date.getHours() < 12 ? '上午' : date.getHours() < 18 ? '午后' : '夜间';
  return `${period}城市漫游` || '旅行途中';
}
function _legacyTimelineTitle(node){
  const text = `${node?.location || ''} ${node?.tag || ''}`;
  if(/餐|饭|拉面|咖啡|甜点|蛋糕|杯面/.test(text)) return '品尝当地美食';
  if(/海|港|湖|沙滩|河畔/.test(text)) return '水岸漫步';
  if(/机场|列车|渡轮|缆车|移动|回程|返程/.test(text)) return '旅途移动';
  if(/酒店|入住|民宿/.test(text)) return '入住休息';
  if(/会展|展位|美术|博物|神宫|寺|塔|广场|大学|地标/.test(text)) return '探访城市地标';
  if(/购物|便利店|商场|市场/.test(text)) return '街区购物';
  if(/合影|朋友|旅伴/.test(text)) return '旅伴相聚';
  return '城市漫游';
}
function _timelineTitleCandidates(node){
  const place = String(node.location || '');
  const category = node.category || 'other';
  const timeHour = Number(String(node.time || '').split(':')[0]);
  const period = timeHour < 7 ? '清晨' : timeHour < 12 ? '上午' : timeHour < 18 ? '午后' : '夜间';
  const placeTitles = [];
  if(place.includes('泽蒙')) placeTitles.push('泽蒙小镇漫步', '泽蒙河畔时光');
  if(place.includes('兹拉蒂博尔')) placeTitles.push('兹拉蒂博尔游览', '山间自然时光');
  if(place.includes('贝尔格莱德')) placeTitles.push('贝城文化漫游', '老城街头漫步');
  if(place.includes('诺维萨德')) placeTitles.push('诺城街区漫步');
  const byCategory = {
    nature:['湖畔漫步', '公园观鸟', '山野时光', '自然风光'],
    food:['品尝当地美食', '午间用餐', '街头美食', '旅途晚餐'],
    sightseeing:['探访城市地标', '老城建筑漫游', '文化景点参观'],
    shopping:['街区购物', '逛店买手信'],
    transport:['旅途移动', '沿途风景'],
    people:['旅伴相聚', '旅途合影'],
    leisure:['悠闲漫步', '小镇慢时光'],
    other:['沿途见闻', '城市随拍', '街区漫步', '旅途片段'],
  };
  return [...placeTitles, ...(byCategory[category] || byCategory.other), `${period}沿途见闻`, `${period}旅途片段`]
    .map(value => Array.from(value).slice(0, 8).join(''));
}
function _fillTimelineLocations(nodes){
  const isSpecific = value => value && value !== '地点待补充' && !value.endsWith('·当地街区');
  nodes.forEach((node, index) => {
    if(isSpecific(node.location)) return;
    const minute = Number(String(node.time || '').slice(0, 2)) * 60 + Number(String(node.time || '').slice(3, 5));
    const nearby = nodes.map((candidate, candidateIndex) => ({ candidate, candidateIndex }))
      .filter(item => item.candidate.day === node.day && isSpecific(item.candidate.location))
      .map(item => {
        const candidateMinute = Number(String(item.candidate.time || '').slice(0, 2)) * 60 + Number(String(item.candidate.time || '').slice(3, 5));
        return { ...item, gap:Math.abs(candidateMinute - minute), orderGap:Math.abs(item.candidateIndex - index) };
      })
      .filter(item => item.gap <= 180)
      .sort((a, b) => a.gap - b.gap || a.orderGap - b.orderGap);
    if(!nearby.length) return;
    const closePlaces = [...new Set(nearby.filter(item => item.gap <= 120).map(item => item.candidate.location))];
    if(closePlaces.length === 1 || (nearby[1] && nearby[0].candidate.location === nearby[1].candidate.location)){
      node.location = nearby[0].candidate.location;
      node.tag = node.location;
      node.locationInferred = true;
    }
  });
  return nodes;
}
function _polishTimelineTitles(nodes){
  const usedByDay = new Map();
  nodes.forEach(node => {
    const used = usedByDay.get(node.day) || new Set();
    usedByDay.set(node.day, used);
    let title = Array.from(node.title || '').slice(0, 8).join('');
    const generic = /^(上午|午后|清晨|夜间)?城市漫游$|^旅行途中$/.test(title);
    if(generic || used.has(title)) title = _timelineTitleCandidates(node).find(candidate => !used.has(candidate)) || title;
    if(used.has(title)){
      const suffix = used.size + 1;
      title = Array.from(`${title}${suffix}`).slice(0, 8).join('');
    }
    node.title = title || '旅途片段';
    used.add(node.title);
  });
  return nodes;
}
function _shouldMergeTimelinePhoto(node, photo, date){
  const previous = node.__lastPhoto;
  const previousDate = node.__lastDate;
  if(!previous || !date || !previousDate || _dateKey(date) !== _dateKey(previousDate)) return false;
  const gapMinutes = (date.getTime() - previousDate.getTime()) / 60000;
  const durationMinutes = node.__startDate ? (date.getTime() - node.__startDate.getTime()) / 60000 : gapMinutes;
  if(gapMinutes < 0 || gapMinutes > 180 || durationMinutes > 300) return false;
  const distance = _distanceKm(previous, photo);
  const previousPlace = _placeKey(previous.location), currentPlace = _placeKey(photo.location);
  const previousAnalysis = _analysisOf(previous), currentAnalysis = _analysisOf(photo);
  let score = gapMinutes <= 30 ? 4 : gapMinutes <= 75 ? 3 : gapMinutes <= 120 ? 2 : 1;
  if(distance != null){
    if(distance <= 2) score += 3;
    else if(distance <= 8) score += 2;
    else if(distance > 80) score -= 5;
    else if(distance > 25) score -= 2;
  }
  if(previousPlace && currentPlace && previousPlace === currentPlace) score += 3;
  if(previous.city && photo.city && _placeKey(previous.city) === _placeKey(photo.city)) score += 1;
  if(previous.countryCode && photo.countryCode && previous.countryCode === photo.countryCode) score += 1;
  if(previousAnalysis.semantic_group && previousAnalysis.semantic_group === currentAnalysis.semantic_group) score += 2;
  if(previousAnalysis.scene && previousAnalysis.scene === currentAnalysis.scene) score += 1;
  score += Math.min(2, _overlapCount(previousAnalysis.activities, currentAnalysis.activities));
  const previousLandmark = _placeKey(previousAnalysis.landmark_guess), currentLandmark = _placeKey(currentAnalysis.landmark_guess);
  if(previousLandmark && currentLandmark) score += previousLandmark === currentLandmark ? 2 : -1;
  return gapMinutes <= 15 || score >= 5;
}
function _nodeLocation(photos){
  const known = photos.map(_localizedPhotoLocation).filter(value => value && value !== '地点待补充');
  return mostCommon(known) || '地点待补充';
}

function buildRealTimeline(photos){
  const ordered = [...photos].sort((a, b) => {
    const at = _photoDate(a)?.getTime() ?? Infinity, bt = _photoDate(b)?.getTime() ?? Infinity;
    return at - bt || (a.sortOrder || 0) - (b.sortOrder || 0);
  });
  const days = [];
  const dayIndex = new Map();
  ordered.forEach((photo, index) => {
    const date = _photoDate(photo);
    const key = _dateKey(date) || 'unknown';
    if(!dayIndex.has(key)){ dayIndex.set(key, days.length + 1); days.push(key); }
    const last = photo.__timelineNode;
    void last;
    photo.__day = dayIndex.get(key);
    photo.__order = index;
  });

  const nodes = [];
  ordered.forEach(photo => {
    const date = _photoDate(photo);
    const prev = nodes[nodes.length - 1];
    if(prev && _shouldMergeTimelinePhoto(prev, photo, date)){
      prev.photoIds.push(photo.id);
      prev.photoCount += 1;
      prev.__lastDate = date;
      prev.__lastPhoto = photo;
      prev.__photos.push(photo);
      prev.location = _nodeLocation(prev.__photos);
      prev.title = _timelineEventTitle(prev.__photos);
      prev.category = mostCommon(prev.__photos.map(item => _analysisOf(item).semantic_group || _analysisOf(item).scene)) || prev.category;
      return;
    }
    nodes.push({
      key: uid('node'), day: photo.__day, date: _dayLabel(date), weekday: _weekday(date),
      time: _timeLabel(date), title:_timelineEventTitle([photo]), location:_localizedPhotoLocation(photo), tag:_localizedPhotoLocation(photo), category:_analysisOf(photo).semantic_group || _analysisOf(photo).scene || 'other',
      photoIds: [photo.id], photoCount: 1, __startDate:date, __lastDate: date, __lastPhoto:photo, __photos:[photo],
    });
  });
  const cleaned = nodes.map(node => { delete node.__startDate; delete node.__lastDate; delete node.__lastPhoto; delete node.__photos; return node; });
  return _polishTimelineTitles(_fillTimelineLocations(cleaned));
}

function buildRealMoments(photos){
  const candidates = [];
  const add = i => { if(i >= 0 && i < photos.length && !candidates.includes(i)) candidates.push(i); };
  add(0);
  photos.forEach((photo, i) => { if(i === 0 || photo.__day !== photos[i - 1].__day) add(i); });
  add(Math.floor((photos.length - 1) / 2));
  add(photos.length - 1);
  return candidates.slice(0, 6).map((index, momentIndex) => {
    const photo = photos[index];
    const date = _photoDate(photo);
    const isFirst = index === 0, isLast = index === photos.length - 1;
    const title = isFirst ? '旅程的第一张照片' : isLast ? '旅程的最后一张照片' : `Day ${photo.__day} 的一个瞬间`;
    const orderText = `这是本次导入中按${date ? '拍摄时间' : '选择顺序'}排列的第 ${index + 1} 张照片。`;
    return {
      id: uid('moment'), photoId: photo.id, imageSrc: photo.src, imageAlt: photo.alt || photo.name || '旅行照片',
      date: date ? date.toISOString() : null, location: photo.location || '地点待补充', title,
      reason: orderText, prompt: isFirst ? '这趟旅行是从这一刻开始的吗？' : isLast ? '拍下它时，你知道旅程快结束了吗？' : '关于这个瞬间，你还记得什么？',
      transcript: '', tidied: '', cardTitle: title,
      context: date ? `拍摄于 ${_dayLabel(date)} ${_timeLabel(date)}。` : `这是本次导入的第 ${index + 1} 张照片。`,
      source: 'local-metadata', rank: momentIndex,
    };
  });
}

function mostCommon(values){
  const counts = new Map();
  values.filter(Boolean).forEach(value => counts.set(value, (counts.get(value) || 0) + 1));
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '';
}
function countryDisplayName(code){
  if(!code) return '';
  try{ return new Intl.DisplayNames(['en'], { type:'region' }).of(String(code).toUpperCase()) || ''; }
  catch(e){ return ''; }
}
function refreshTripGeography(trip){
  const photos = trip.photos || [];
  const country = mostCommon(photos.map(photo => photo.country));
  const countryCode = mostCommon(photos.map(photo => photo.countryCode));
  const cities = [...new Set(photos.map(photo => photo.city).filter(Boolean))];
  const locations = [...new Set(photos.map(photo => photo.location).filter(Boolean))];
  trip.destination = [country, cities[0]].filter(Boolean).join(' · ') || locations[0] || trip.destination || '地点待补充';
  trip.cities = (cities.length ? cities : locations).slice(0, 3).join(' · ') || '地点待补充';
  trip.bigName = countryDisplayName(countryCode) || country || cities[0] || 'Journey';
  return trip;
}

function buildTrip(name, destination, userPhotos){
  const usingSample = !userPhotos || userPhotos.length === 0;
  if(usingSample){
    const trip = {
      id: uid('trip'), name: name || '六月的东京', destination: destination || '东京 Tokyo',
      startDate:'2026-06-18', endDate:'2026-06-20',
      photos: SAMPLE_PHOTOS.map(p => ({ src:p.file, time:p.time, location:p.location, alt:p.alt, sampleId:p.id })),
      photosCount: 83, usingSample: true, sample: true, cards: [],
    };
    trip.timeline = SAMPLE_TIMELINE.map(n => ({ ...n, key: uid('node') }));
    trip.moments = SAMPLE_MOMENTS.map(m => ({ ...m }));
    return normalizeTripData(trip);
  }

  const photos = userPhotos.map((photo, index) => ({ ...photo, id: photo.id || uid('photo'), sortOrder: index }));
  const dated = photos.map(_photoDate).filter(Boolean).sort((a, b) => a - b);
  const first = dated[0] || null, last = dated[dated.length - 1] || first;
  const knownLocations = photos.map(p => p.location).filter(Boolean);
  const realDestination = destination || knownLocations[0] || '地点待补充';
  const defaultName = first ? `${first.getFullYear()}年${first.getMonth() + 1}月的旅程` : '我的新旅程';
  const trip = {
    id: uid('trip'), name: name || defaultName, destination: realDestination,
    cities: [...new Set(knownLocations)].slice(0, 3).join(' · ') || '地点待补充',
    startDate: first ? _dateKey(first) : _dateKey(new Date()),
    endDate: last ? _dateKey(last) : _dateKey(new Date()),
    photos, photosCount: photos.length, usingSample: false, sample: false,
    coverPhotoId: photos[0].id, coverSrc: photos[0].src, bigName: 'Journey', cards: [],
  };
  refreshTripGeography(trip);
  trip.timeline = buildRealTimeline(photos);
  trip.timelineAlgorithmVersion = 4;
  trip.moments = buildRealMoments(photos);
  photos.forEach(photo => { delete photo.__day; delete photo.__order; });
  return normalizeTripData(trip);
}

/* 所有数量与关联关系都从真实数组派生，禁止展示字段与实际数据脱节。 */
function normalizeTripData(trip){
  if(!trip) return trip;
  trip.photos = Array.isArray(trip.photos) ? trip.photos : [];
  trip.moments = Array.isArray(trip.moments) ? trip.moments : [];
  trip.cards = Array.isArray(trip.cards) ? trip.cards : [];
  trip.timeline = Array.isArray(trip.timeline) ? trip.timeline : [];
  trip.timeline.forEach(node => { node.title = node.title || _legacyTimelineTitle(node); });

  trip.photos.forEach((photo, index) => {
    photo.id = photo.id || photo.sampleId || uid('photo');
    photo.sortOrder = Number.isFinite(photo.sortOrder) ? photo.sortOrder : index;
  });

  const bySrc = new Map(trip.photos.filter(p => p.src).map(p => [p.src, p]));
  const byId = new Map(trip.photos.map(p => [p.id, p]));
  trip.moments.forEach(moment => {
    const photo = (moment.photoId && byId.get(moment.photoId)) || bySrc.get(moment.imageSrc);
    if(photo){ moment.photoId = photo.id; moment.imageSrc = photo.src; }
    moment.userMemory = trip.cards.some(card => card.momentId === moment.id) || !!moment.userMemory;
  });
  trip.cards.forEach(card => {
    card.id = card.id || uid('card');
    const photo = (card.photoId && byId.get(card.photoId)) || bySrc.get(card.imageSrc);
    if(photo){ card.photoId = photo.id; card.imageSrc = photo.src; photo.hasMemory = true; }
  });

  /*
   * 每张照片只归属一个 Timeline 节点，节点数量之和严格等于相册照片数。
   * 已经由地点 + 时间聚类得到的合法归属必须保留；只有旧数据缺失/重复归属时，
   * 才使用按日期和时间就近分桶的兼容修复。此前无条件重新分桶会破坏地点聚类。
   */
  if(trip.timeline.length){
    const validPhotoIds = new Set(trip.photos.map(photo => photo.id));
    const assignedIds = trip.timeline.flatMap(node => Array.isArray(node.photoIds) ? node.photoIds : []);
    const uniqueAssignedIds = new Set(assignedIds);
    const assignmentIsComplete = assignedIds.length === trip.photos.length
      && uniqueAssignedIds.size === trip.photos.length
      && assignedIds.every(photoId => validPhotoIds.has(photoId));

    let buckets = trip.timeline.map(node => Array.isArray(node.photoIds) ? [...node.photoIds] : []);
    if(!assignmentIsComplete){
      buckets = trip.timeline.map(() => []);
      const nodeMinutes = node => {
        const m = String(node.time || '').match(/(\d{1,2}):(\d{2})/);
        return m ? (+m[1] * 60 + +m[2]) : 0;
      };
      const nodeMD = node => {
        const m = String(node.date || '').match(/(\d{1,2})\D+(\d{1,2})/);
        return m ? `${+m[1]}-${+m[2]}` : '';
      };
      trip.photos.forEach((photo, photoIndex) => {
        const d = _photoDate(photo);
        const md = d ? `${d.getMonth() + 1}-${d.getDate()}` : '';
        const minute = d ? d.getHours() * 60 + d.getMinutes() : 0;
        const candidates = trip.timeline
          .map((node, index) => ({ index, md: nodeMD(node), delta: Math.abs(nodeMinutes(node) - minute) }))
          .filter(item => md && item.md === md)
          .sort((a, b) => a.delta - b.delta);
        const target = candidates.length
          ? candidates[0].index
          : Math.min(trip.timeline.length - 1, Math.floor(photoIndex * trip.timeline.length / Math.max(1, trip.photos.length)));
        buckets[target].push(photo.id);
      });
    }
    trip.timeline.forEach((node, index) => {
      node.key = node.key || uid('node');
      node.photoIds = buckets[index];
      node.photoCount = buckets[index].length;
    });
  }

  trip.photosCount = trip.photos.length;
  trip.memoryCount = trip.cards.length;
  trip.metadataStats = {
    total:trip.photos.length,
    withTime:trip.photos.filter(photo => !!_photoDate(photo)).length,
    withCoordinates:trip.photos.filter(photo => Number.isFinite(photo.latitude) && Number.isFinite(photo.longitude)).length,
    withLocation:trip.photos.filter(photo => !!photo.location).length,
    timelineNodes:trip.timeline.length,
    assignedToTimeline:trip.timeline.reduce((sum, node) => sum + (node.photoIds || []).length, 0),
  };
  if(trip.photos[0]){
    trip.coverPhotoId = trip.coverPhotoId || trip.photos[0].id;
    trip.coverSrc = (byId.get(trip.coverPhotoId) || trip.photos[0]).src;
  }
  return trip;
}

/** 供 Timeline chips 使用的循环取图器（优先使用该 trip 自己的照片池） */
function makeChipCycler(trip){
  const pool = (trip && trip.photos && trip.photos.length)
    ? trip.photos.map(p => p.src)
    : SAMPLE_PHOTOS.map(p => p.file);
  let i = 0;
  return () => pool[i++ % pool.length];
}

function applyCloudTripAnalysis(trip, cloud){
  const localByCloudId = new Map(trip.photos.filter(photo => photo.cloudId).map(photo => [photo.cloudId, photo]));
  (cloud.photos || []).forEach(remote => {
    const local = localByCloudId.get(remote.id);
    if(!local) return;
    local.location = remote.location_name || local.location;
    local.city = remote.city || local.city;
    local.country = remote.country || local.country;
    local.countryCode = remote.country_code || local.countryCode;
    local.locationSource = remote.location_source || local.locationSource;
    local.analysis = remote.analysis || local.analysis;
  });
  refreshTripGeography(trip);
  const dateParts = value => {
    const date = value ? new Date(value) : null;
    return date && !Number.isNaN(date.getTime()) ? {
      date:`${date.getMonth() + 1}月${date.getDate()}日`, weekday:`星期${'日一二三四五六'[date.getDay()]}`,
      time:`${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`,
    } : { date:'日期待补充', weekday:'', time:'--:--' };
  };
  const dayNumbers = new Map();
  trip.timeline = (cloud.timeline || []).map((node) => {
    const labels = dateParts(node.starts_at);
    if(!dayNumbers.has(labels.date)) dayNumbers.set(labels.date, dayNumbers.size + 1);
    const photoIds = (node.photo_ids || []).map(cloudId => localByCloudId.get(cloudId)?.id).filter(Boolean);
    const location = _hasChinese(node.place_name) ? node.place_name : '地点待补充';
    return { key:node.id || uid('node'), day:dayNumbers.get(labels.date), ...labels, title:node.title || '旅行途中', location, tag:location, category:node.category || 'other', photoIds, photoCount:photoIds.length, confidence:node.confidence };
  });
  trip.timelineAlgorithmVersion = 4;
  trip.moments = (cloud.moments || []).map((moment, index) => {
    const photo = localByCloudId.get(moment.photo_id) || trip.photos[index % Math.max(1, trip.photos.length)];
    return {
      id:moment.id || uid('moment'), photoId:photo?.id, imageSrc:photo?.src, imageAlt:photo?.alt || photo?.name || '旅行照片',
      date:photo?.time instanceof Date ? photo.time.toISOString() : photo?.time || null,
      location:photo?.location || moment.evidence?.location || '地点待补充', title:moment.title, reason:moment.reason, prompt:moment.prompt,
      transcript:'', tidied:'', cardTitle:moment.title, context:[moment.evidence?.weather, moment.evidence?.scene].filter(Boolean).join(' · '),
      source:'cloud-ai', rank:index, score:moment.score,
    };
  });
  trip.status = cloud.status || 'ready';
  normalizeTripData(trip);
  return { timeline:trip.timeline, moments:trip.moments };
}

/**
 * Production path: uploads originals to R2, asks the server-side vision model for
 * schema-validated analysis, then applies the durable D1 result to the UI.
 * Local metadata grouping remains available only when no backend is running.
 */
async function aiAnalyzeTrip(trip, onStage){
  let cloudId = trip.cloudId || null;
  if(trip.__cloudSyncPromise){
    onStage({ key:'upload', label:'正在安全上传原始照片' }, .12);
    cloudId = await trip.__cloudSyncPromise;
    delete trip.__cloudSyncPromise;
  }
  if(cloudId){
    onStage({ key:'vision', label:'正在识别人物、风景与场景' }, .3);
    const cloud = await CloudAPI.analyzeTrip(trip, progress => {
      const completed = Math.max(0, progress.total - progress.remaining);
      onStage({ key:'vision', label:`正在分析第 ${Math.min(progress.total, completed)} / ${progress.total} 张照片` }, .3 + .48 * completed / Math.max(1, progress.total));
    });
    onStage({ key:'timeline', label:'正在生成真实行程时间线与回忆推荐' }, .92);
    const result = applyCloudTripAnalysis(trip, cloud);
    await Store.save([trip, ...((typeof S !== 'undefined' && S.trips) ? S.trips.filter(item => item.id !== trip.id) : [])]);
    onStage({ key:'done', label:'旅程已经整理完成' }, 1);
    return result;
  }
  onStage({ key:'local', label:'当前为本地演示：按照片时间整理' }, .2);
  return new Promise(resolve => setTimeout(() => {
    onStage({ key:'local-done', label:'本地时间线已经整理完成' }, 1);
    resolve({ timeline:trip.timeline, moments:trip.moments, mode:'local-metadata' });
  }, 900));
}

/**
 * ⚠️ FUTURE AI：语音转写。当前为模拟——返回该 Moment 预置的
 * "轻度整理后"文本（保留用户口吻，不做文学化改写）。
 * 未来替换为真实 ASR（如 Whisper 类接口）+ 轻度整理 LLM 调用。
 */
function aiTranscribe(moment){
  return new Promise(resolve => {
    setTimeout(() => resolve(moment.tidied || ''), 1400);
  });
}

/**
 * ⚠️ FUTURE AI：由 Moment + 用户回忆生成 Memory Card。
 * 未来：标题与上下文补充由 LLM 生成（原则：只补充事实，不改写情绪）。
 */
function aiGenerateCard(moment, memory){
  return {
    id: uid('card'),
    momentId: moment.id,
    photoId: moment.photoId || null,
    title: moment.cardTitle || moment.title,
    imageSrc: moment.imageSrc,
    imageAlt: moment.imageAlt,
    memory: memory.trim(),
    date: moment.date,
    location: moment.location,
    context: moment.context || '',
  };
}

/* ============================================================
   Echo 首页 · 今日回响 Feed
   ⚠️ FUTURE AI：真实场景由推送服务按上下文（天气 / 周年 /
   地理位置 / 随机）决定何时唤醒哪张卡。此处 Mock 为精选 3 张：
   第一张严格对应设计稿（Positano），其余为待切换的回响。
   ============================================================ */
const MONTHS_EN = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
function echoDateLabel(iso){
  if(!iso) return 'SOMEDAY';
  const d = new Date(iso);
  return `${MONTHS_EN[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

/* Echo 推荐策略：每一条回响都说明“为什么偏偏今天想起它”。 */
const ECHO_TRIGGER_TYPES = ['time', 'location', 'weather', 'daily', 'surprise'];
const ECHO_TRIGGER_ALIASES = {
  time:'time', 时间:'time', anniversary:'time',
  location:'location', place:'location', 地点:'location',
  weather:'weather', 天气:'weather',
  daily:'daily', context:'daily', scene:'daily', person:'daily', 日常:'daily', 人物:'daily', 情境:'daily',
  surprise:'surprise', random:'surprise', 随机:'surprise', 随机掉落:'surprise',
};

function echoCardText(card){
  return [card.title, card.memory, card.context, card.location, card.imageAlt]
    .map(value => String(value || ''))
    .join(' ');
}

/* 当前 Echo 胶囊两行可完整容纳约 24 个中文字符；拉丁字符按半宽估算。 */
function echoCopyUnits(value){
  return Array.from(String(value || '')).reduce((total, char) =>
    total + (/[^\u0000-\u00ff]/.test(char) ? 1 : .55), 0);
}

function echoCopyFits(value){
  return echoCopyUnits(value) <= 24;
}

function normalizeEchoTriggerType(card, index){
  const provided = String(card.echoTriggerType || card.triggerType || '').trim().toLowerCase();
  if(ECHO_TRIGGER_ALIASES[provided]) return ECHO_TRIGGER_ALIASES[provided];

  const text = echoCardText(card);
  /* 演示数据也遵循可解释规则；真实线上结果优先使用后端 triggerType。 */
  if(/等雾散|雾中小镇|雾里的|云一直没散/.test(text)) return 'surprise';
  if(/东京塔|仰头的二十张|夜里的东京塔/.test(text)) return 'time';
  if(/湖上索道|湖上缆车|蓝得不太真实|镜面湖/.test(text)) return 'location';
  if(/缆车|山顶|风太大|残雪|雪没化/.test(text)) return 'weather';
  if(/蛋糕|甜点|咖啡|吐舌头|朋友|悉尼|她|人物/.test(text)) return 'daily';
  return ECHO_TRIGGER_TYPES[index % ECHO_TRIGGER_TYPES.length];
}

function echoStrategyCopies(card, type){
  const text = echoCardText(card);
  const location = String(card.location || '');
  const place = location.split(/[·,，]/)[0].trim();

  if(type === 'time'){
    if(/东京塔|仰头的二十张/.test(text)) return ['去年的这晚，你在东京拍了二十多张夜景。'];
    return [
      '去年的今天，你正走在这趟旅行里。',
      '又到这一天了，那一刻还亮着。',
    ];
  }

  if(type === 'location'){
    if(/湖上索道|湖上缆车|蓝得不太真实|镜面湖/.test(text)) return ['今天来到湖边，有没有想起这片蓝？'];
    if(/海|港|沙滩|海岸/.test(text)) return ['你又来到海边了，想起那天的风。'];
    return [
      place && place !== '地点待补充' && Array.from(place).length <= 6
        ? `又走到${place}附近，想起那天。`
        : '走到相似的地方，忽然想起那天。',
      '走到相似的街角，旧日脚步又靠近。',
    ];
  }

  if(type === 'weather'){
    if(/缆车|山顶|风太大/.test(text)) return ['今天风很大，想起你在山顶拍的这张。'];
    if(/雪|残雪|雪没化/.test(text)) return ['天气一凉，就想起山上那片没化的雪。'];
    if(/雨/.test(text)) return ['今天也在下雨，那天的窗景忽然回来了。'];
    return ['今天的天气，很像照片里的那一天。', '风从窗边经过，也把这一刻带了回来。'];
  }

  if(type === 'daily'){
    if(/蛋糕|甜点|舒芙蕾|甜/.test(text)) return ['今天又吃了甜点，有没有想起这块热蛋糕？'];
    if(/悉尼|东海岸/.test(text)) return ['今天又拍了她，想起悉尼海边那阵风。'];
    if(/她|朋友|吐舌头|合影|笑/.test(text)) return ['今天又拍到她笑，想起旅途中那个没忍住的瞬间。'];
    if(/餐|饭|拉面|咖啡|吃/.test(text)) return ['今天熟悉的味道，让旅行那一餐又热了。'];
    return ['今天遇见相似的一幕，忽然想起当时的你。', '刚才那个小动作，和旅途中那一刻很像。'];
  }

  if(/等雾散|雾中小镇|雾里的|云一直没散/.test(text)) return ['一段记忆，刚好今天回来。'];
  return ['没有特别的理由，只是这段记忆今天回来了。', '一段很久没见的时光，今天随机掉落。'];
}

function resolveEchoRecommendation(card, index, used){
  const type = normalizeEchoTriggerType(card, index);
  const preferred = String(card.echoTrigger || card.recommendationCopy || '').trim();
  const choices = preferred && echoCopyFits(preferred)
    ? [preferred, ...echoStrategyCopies(card, type)]
    : echoStrategyCopies(card, type);
  for(const copy of choices){
    if(copy && echoCopyFits(copy) && !used.has(copy)){
      used.add(copy);
      return { type, copy };
    }
  }
  const fallback = index ? '另一段旧时光，刚好今天回来。' : '一段旧时光，刚好今天回来。';
  used.add(fallback);
  return { type, copy:fallback };
}

const ECHO_TODAY = [
  { key:'et_r1', imageSrc:'assets/photos/real/r1.jpg', dateLabel:'SEP 12, 2025',
    location:'Amalfi Coast, Italy', region:'Amalfi Coast, Italy',
    titleLines:['悬崖下的','那片蓝'],
    quote:'落地后的第一件事，就是去海边看船。',
    triggerType:'location', trigger:'你又来到海边了，想起那天的风。' },
  { key:'et_r2', imageSrc:'assets/photos/real/r2.jpg', dateLabel:'SEP 12, 2025',
    location:'Positano, Italy', region:'Amalfi Coast, Italy',
    titleLines:['雾里的','海边小镇'],
    quote:'山把小镇抱在怀里，云一直没散，我们也没走。',
    triggerType:'surprise', trigger:'一段记忆，刚好今天回来。' },
  { key:'et_r3', imageSrc:'assets/photos/real/r3.jpg', dateLabel:'SEP 13, 2025',
    location:'Amalfi Coast, Italy', region:'Amalfi Coast, Italy',
    titleLines:['赶在太阳','落山之前'],
    quote:'沿着海岸公路一直开，就为了在天黑前看它一眼。',
    triggerType:'time', trigger:'去年的今天，你还在追那场落日。' },
  { key:'et_r5', imageSrc:'assets/photos/real/r5.jpg', dateLabel:'SEP 15, 2025',
    location:'Zlatibor, Serbia', region:'Zlatibor, Serbia',
    titleLines:['雪没化完','的山上'],
    quote:'山上还很冷，但太阳照过来的时候，谁都不想进屋。',
    triggerType:'weather', trigger:'天气一凉，就想起山上那片没化的雪。' },
  { key:'et_r7', imageSrc:'assets/photos/real/r7.jpg', dateLabel:'SEP 17, 2025',
    location:'Republic Sq, Belgrade', region:'Belgrade, Serbia',
    titleLines:['广场上','的黄昏'],
    quote:'雕像、博物馆和晚风，我们在广场上一直待到亮灯。',
    triggerType:'weather', trigger:'今晚的风，把广场亮灯那一刻带回来了。' },
];

/**
 * 有真实用户回忆时只展示真实数据；尚无数据时才显示示例内容。
 */
function echoFeedFor(userCards){
  const usedTriggers = new Set();
  const mine = (userCards || []).map((c, index) => {
    const recommendation = resolveEchoRecommendation(c, index, usedTriggers);
    return {
      key: 'uc_' + c.id,
      imageSrc: c.imageSrc,
      imageAlt: c.imageAlt || c.title,
      dateLabel: echoDateLabel(c.date),
      location: c.location,
      region: (c.location || '').split('·')[0].trim() || '那次旅行',
      titleLines: [c.title],
      quote: c.memory,
      triggerType: recommendation.type,
      trigger: recommendation.copy,
    };
  });
  return mine.length ? mine : ECHO_TODAY;
}

/* ============================================================
   本地持久化 —— Trips 首页 / Echo 首页的数据来源。
   真实照片 Blob 由 storage.js 写入 IndexedDB，刷新后重新生成 object URL。
   ⚠️ FUTURE：接入云端后保持 Store 接口，内部换成远程 Repository。
   ============================================================ */
function _pad0(n){ return String(n).padStart(2, '0'); }
function _iso0(t){
  return t instanceof Date
    ? `${t.getFullYear()}-${_pad0(t.getMonth() + 1)}-${_pad0(t.getDate())}T${_pad0(t.getHours())}:${_pad0(t.getMinutes())}`
    : (t || null);
}
function resolveSrc(src, refId){
  if(src && !String(src).startsWith('blob:')) return src;
  const base = SAMPLE_MOMENTS.find(m => m.id === refId);
  if(base) return base.imageSrc;
  let h = 0; const s = String(refId || 'x');
  for(let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return SAMPLE_PHOTOS[h % SAMPLE_PHOTOS.length].file;
}

const Store = {
  KEY: 'echotrip.v16',
  READY: 'echotrip.indexeddb.ready',
  _pending: Promise.resolve(),
  async save(trips){
    /* 所有写入串行化，避免快速点击时多个 clear/put 事务互相覆盖。 */
    let snapshot;
    if(typeof structuredClone === 'function'){
      try{
        snapshot = structuredClone(trips);
      }catch(error){
        /* 上传中的 Trip 会暂挂 Promise；它是运行时状态，不能写入 IndexedDB。 */
        const persistable = trips.map(trip => Object.fromEntries(
          Object.entries(trip).filter(([key, value]) => !key.startsWith('__') && !(value instanceof Promise) && typeof value !== 'function')
        ));
        snapshot = structuredClone(persistable);
      }
    }else{
      snapshot = trips.slice();
    }
    this._pending = this._pending.then(async () => {
      await LocalDB.saveTrips(snapshot);
      localStorage.setItem(this.READY, '1');
    }).catch(e => { console.warn('EchoTrip local save failed', e); });
    return this._pending;
  },
  async load(){
    try{
      const saved = await LocalDB.loadTrips();
      if(saved.length || localStorage.getItem(this.READY) === '1') return saved;
      const raw = localStorage.getItem(this.KEY);
      if(!raw) return null;
      const data = JSON.parse(raw);
      if(!data || !Array.isArray(data.trips)) return null;
      await this.save(data.trips);
      return data.trips;
    }catch(e){ console.warn('EchoTrip local load failed', e); return null; }
  },
};

/**
 * 首次访问的种子数据：一段完整的示例旅程 + 3 张已经写好回忆的
 * Memory Cards —— 让 Echo 首页在第一次打开时就有"回音"可听。
 */
/* ---------- 塞尔维亚示例旅程：真实照片 + 可替换文案 ---------- */
const SERBIA_PHOTOS = [
  { src:'assets/photos/real/r1.jpg', time:'2025-09-12T16:40', location:'阿马尔菲海岸 · 悬崖海湾', alt:'悬崖下的蓝海湾', aiHint:'落地第一站就拍个不停，为什么？' },
  { src:'assets/photos/real/r2.jpg', time:'2025-09-12T19:10', location:'波西塔诺 · 雾中的小镇', alt:'雾里层叠的海边小镇', hasMemory:true },
  { src:'assets/photos/real/r3.jpg', time:'2025-09-13T18:25', location:'阿马尔菲 · 海岸公路', alt:'落日前的高崖与海', aiHint:'在这里等了很久日落吗？' },
  { src:'assets/photos/real/r4.jpg', time:'2025-09-15T11:03', location:'兹拉蒂博尔 · 缆车站', alt:'栏杆边闭眼笑的人' },
  { src:'assets/photos/real/td3.jpg', time:'2025-09-15T11:35', location:'兹拉蒂博尔 · 山顶缆车站', alt:'栅栏边仰面微笑' },
  { src:'assets/photos/real/td1.jpg', time:'2025-09-15T12:20', location:'兹拉蒂博尔 · 山地公园', alt:'摇椅上托腮微笑' },
  { src:'assets/photos/real/r5.jpg', time:'2025-09-15T15:40', location:'兹拉蒂博尔 · 山间木屋', alt:'雪没化完的木屋前' },
  { src:'assets/photos/real/td8.jpg', time:'2025-09-15T16:25', location:'兹拉蒂博尔 · 缆车厢内', alt:'缆车里躺椅大笑', aiHint:'为什么笑得这么开心？' },
  { src:'assets/photos/real/td4.jpg', time:'2025-09-16T11:05', location:'兹拉蒂博尔 · 湖边', alt:'湖边张开双臂', aiHint:'风大吗？喊出来了没有？' },
  { src:'assets/photos/real/td7.jpg', time:'2025-09-16T11:50', location:'兹拉蒂博尔 · 镜面湖', alt:'倒映云天的湖面' },
  { src:'assets/photos/real/td9.jpg', time:'2025-09-16T12:30', location:'兹拉蒂博尔 · 天鹅湖', alt:'湖岸与白天鹅', aiHint:'天鹅是突然出现的吗？' },
  { src:'assets/photos/real/r7.jpg', time:'2025-09-17T19:30', location:'贝尔格莱德 · 共和国广场', alt:'广场雕像与黄昏' },
  { src:'assets/photos/real/r8.jpg', time:'2025-09-18T14:05', location:'湖上索道', alt:'缆车俯瞰蓝色湖面', hasMemory:true },
];
const SERBIA_TIMELINE = [
  { day:1, date:'9月12日', weekday:'星期五', time:'16:40', location:'阿马尔菲 · 悬崖海湾', tag:'落脚', photoCount:14 },
  { day:1, date:'9月12日', weekday:'星期五', time:'19:10', location:'波西塔诺', tag:'黄昏', photoCount:9 },
  { day:2, date:'9月13日', weekday:'星期六', time:'18:25', location:'海岸公路', tag:'日落', photoCount:21 },
  { day:4, date:'9月15日', weekday:'星期一', time:'11:03', location:'兹拉蒂博尔缆车站', tag:'上山', photoCount:17 },
  { day:4, date:'9月15日', weekday:'星期一', time:'15:40', location:'山间木屋', tag:'下午', photoCount:8 },
  { day:6, date:'9月17日', weekday:'星期三', time:'19:30', location:'共和国广场', tag:'亮灯', photoCount:12 },
  { day:7, date:'9月18日', weekday:'星期四', time:'14:05', location:'湖上索道', tag:'俯瞰', photoCount:16 },
];
const SERBIA_MOMENTS = [
  { id:'st_bay', imageSrc:'assets/photos/real/r1.jpg', imageAlt:'悬崖下的蓝海湾',
    date:'2025-09-12T16:40', location:'阿马尔菲海岸 · 悬崖海湾', title:'悬崖下的那片蓝',
    reason:'落地后的第一站。你在海湾边站了很久，快门按了十四次——这是第一天状态最好的时候。',
    prompt:'第一天到海边的时候，在想什么？',
    transcript:'时差还没倒过来就想先看海，结果一站就是一个小时，船开来开去都看不够。',
    tidied:'时差还没倒过来就想先看海，结果一站就是一个小时，船开来开去都看不够。',
    cardTitle:'船开来开去', context:'这是这段旅程的第 6 张照片，也是你停留最久的一个机位。' },
  { id:'st_positano', imageSrc:'assets/photos/real/r2.jpg', imageAlt:'雾里层叠的海边小镇',
    date:'2025-09-12T19:10', location:'波西塔诺 · 雾中的小镇', title:'雾没散，我们也没走',
    reason:'本来只是路过。雾把山和小镇裹在一起，你们在防波堤上等到天色全暗才离开。',
    prompt:'那天为什么在堤上待那么久？',
    transcript:'云一直压着不散，反而好看，我们就一直等，等到路灯全亮了才走。',
    tidied:'云一直压着不散，反而好看，我们就一直等，等到路灯全亮了才走。',
    cardTitle:'等雾散的人', context:'这九张照片里，有六张是在同一个位置原地转身拍的。' },
  { id:'st_road', imageSrc:'assets/photos/real/r3.jpg', imageAlt:'落日前的高崖与海',
    date:'2025-09-13T18:25', location:'阿马尔菲 · 海岸公路', title:'赶在太阳落山之前',
    reason:'沿着海岸公路开了四十分钟，就为了在天黑前找到一个能停车的弯道。这张是熄火后跑上坡顶拍的。',
    prompt:'为什么一定要赶这一趟？',
    transcript:'就想着天黑前再看一眼海，拐过一个弯突然就开阔了，赶紧停车跑上去。',
    tidied:'就想着天黑前再看一眼海，拐过一个弯突然就开阔了，赶紧停车跑上去。',
    cardTitle:'拐过弯的开阔', context:'这是全程你们唯一一次为了拍照在路边熄火。' },
  { id:'st_fence', imageSrc:'assets/photos/real/r4.jpg', imageAlt:'栏杆边闭眼笑的人',
    date:'2025-09-15T11:03', location:'兹拉蒂博尔 · 缆车站', title:'闭眼的那一张',
    reason:'在缆车站的木栏杆边，风很大，你闭着眼笑了。这是全程唯一一张"摆拍"之外的人像。',
    prompt:'那一刻是什么感觉？',
    transcript:'风吹得眼睛睁不开，索性就闭着眼笑，拍出来反而最喜欢这张。',
    tidied:'风吹得眼睛睁不开，索性就闭着眼笑，拍出来反而最喜欢这张。',
    cardTitle:'风太大，索性闭眼', context:'2 小时的缆车排队，你在栏杆边只留了这一张。' },
  { id:'st_lodge', imageSrc:'assets/photos/real/r5.jpg', imageAlt:'雪没化完的木屋前',
    date:'2025-09-15T15:40', location:'兹拉蒂博尔 · 山间木屋', title:'雪没化完的山上',
    reason:'九月山上还有残雪。木屋前晒到太阳的那块地方，你们坐了一下午。',
    prompt:'山上冷吗？',
    transcript:'挺冷的，但太阳照过来那一下就都不想动了，在露台坐了一下午。',
    tidied:'挺冷的，但太阳照过来那一下就都不想动了，在露台坐了一下午。',
    cardTitle:'晒太阳的一下午', context:'这是全程海拔最高的一张照片。' },
  { id:'st_square', imageSrc:'assets/photos/real/r7.jpg', imageAlt:'广场雕像与黄昏',
    date:'2025-09-17T19:30', location:'贝尔格莱德 · 共和国广场', title:'待到亮灯的广场',
    reason:'旅程倒数第二天。博物馆关门后，你们在广场的雕像下坐到整条街亮灯。',
    prompt:'那天晚上聊了什么？',
    transcript:'也没聊什么正经的，就是看人来人往，看灯一盏一盏亮起来。',
    tidied:'也没聊什么正经的，就是看人来人往，看灯一盏一盏亮起来。',
    cardTitle:'看灯亮起来', context:'离开贝尔格莱德前的最后一个傍晚。' },
  { id:'st_gondola', imageSrc:'assets/photos/real/r8.jpg', imageAlt:'缆车俯瞰蓝色湖面',
    date:'2025-09-18T14:05', location:'湖上索道', title:'湖上缆车',
    reason:'回程前的最后一个上午。缆车跨过整片湖面，你们谁都没说话，只顾着看。',
    prompt:'在缆车上看到了什么？',
    transcript:'整个湖都在脚下面，蓝得不太真实，全程没人说话。',
    tidied:'整个湖都在脚下面，蓝得不太真实，全程没人说话。',
    cardTitle:'蓝得不太真实', context:'这是这段旅程的最后一张照片。' },
];

/* ---------- 澳大利亚示例旅程：悉尼（真实照片 a1-a6） ---------- */
const AU_PHOTOS = [
  { src:'assets/photos/real/a1.jpg', time:'2024-07-06T17:15', location:'悉尼 · 东海岸沙滩', alt:'海风里的笑容' },
  { src:'assets/photos/real/a6.jpg', time:'2024-07-07T10:20', location:'悉尼港 · 渡轮上', alt:'海面眺望歌剧院' },
  { src:'assets/photos/real/a3.jpg', time:'2024-07-08T15:05', location:'悉尼大学 · 四方院钟楼', alt:'仰拍的哥特钟楼' },
  { src:'assets/photos/real/a2.jpg', time:'2024-07-08T17:30', location:'悉尼大学 · 主楼', alt:'黄金时刻的砂岩建筑' },
  { src:'assets/photos/real/a4.jpg', time:'2024-07-08T18:10', location:'悉尼大学 · 四方院前', alt:'比耶的合影' },
  { src:'assets/photos/real/a5.jpg', time:'2024-07-09T19:40', location:'达令港 · 指路牌', alt:'红色指路牌与暮色海港' },
];
const AU_TIMELINE = [
  { day:1, date:'7月6日', weekday:'星期六', time:'17:15', location:'东海岸沙滩', tag:'黄昏', photoCount:21 },
  { day:2, date:'7月7日', weekday:'星期日', time:'10:20', location:'悉尼港渡轮', tag:'渡轮', photoCount:18 },
  { day:3, date:'7月8日', weekday:'星期一', time:'15:05', location:'悉尼大学', tag:'哥特楼', photoCount:34 },
  { day:3, date:'7月8日', weekday:'星期一', time:'18:10', location:'四方院前', tag:'合影', photoCount:9 },
  { day:4, date:'7月9日', weekday:'星期二', time:'19:40', location:'达令港', tag:'暮色', photoCount:13 },
];
const AU_MOMENTS = [
  { id:'au_beach', imageSrc:'assets/photos/real/a1.jpg', imageAlt:'海风里的笑容',
    date:'2024-07-06T17:15', location:'悉尼 · 东海岸沙滩', title:'海风里的笑容',
    reason:'落地第一天冲到海边。风把头发吹得乱七八糟，但你笑得比阳光还亮。',
    prompt:'那天在海边待了多久？',
    transcript:'风特别大，头发全糊脸上了，但是海很好看，就一直待到天快黑。',
    tidied:'风特别大，头发全糊脸上了，但海很好看，一直待到天快黑。',
    cardTitle:'头发糊脸也没关系', context:'这是你在南半球拍的第一张照片。' },
  { id:'au_opera', imageSrc:'assets/photos/real/a6.jpg', imageAlt:'海面眺望歌剧院',
    date:'2024-07-07T10:20', location:'悉尼港 · 渡轮上', title:'渡轮上的歌剧院',
    reason:'明信片视角的由来：不是在陆地上拍的，是在渡轮上。船身晃，你也晃，但快门没停过。',
    prompt:'在渡轮上看到了什么？',
    transcript:'船一转弯歌剧院就在正前方，白色的帆被太阳照得特别亮，所有人都挤到一边拍照。',
    tidied:'船一转弯歌剧院就在正前方，白帆被太阳照得特别亮，所有人都挤到一边拍照。',
    cardTitle:'船一转弯', context:'渡轮全程 22 分钟，你在右舷站了 20 分钟。' },
  { id:'au_quad', imageSrc:'assets/photos/real/a3.jpg', imageAlt:'仰拍的哥特钟楼',
    date:'2024-07-08T15:05', location:'悉尼大学 · 四方院钟楼', title:'哈利波特楼',
    reason:'所有人都叫它哈利波特楼。你仰着头拍钟楼的时候，鸽子绕着塔尖飞了一圈。',
    prompt:'为什么仰拍？',
    transcript:'楼太高了不仰拍拍不全，结果拍出来反而最好看，天特别蓝。',
    tidied:'楼太高了不仰拍拍不全，结果拍出来反而最好看，天特别蓝。',
    cardTitle:'仰拍才装得下', context:'这座四方院完工于 1909 年，比澳大利亚联邦还小两岁。' },
  { id:'au_gold', imageSrc:'assets/photos/real/a2.jpg', imageAlt:'黄金时刻的砂岩建筑',
    date:'2024-07-08T17:30', location:'悉尼大学 · 主楼', title:'砂岩变金的那十分钟',
    reason:'你掐着黄金时刻回到主楼前。砂岩被落日染成蜂蜜色的那十分钟，你一张没错过。',
    prompt:'等了很久吗？',
    transcript:'提前半小时就到了，就为了等阳光把楼照成金色，真的就十分钟，特别值。',
    tidied:'提前半小时就到了，就为了等阳光把楼照成金色，真的就十分钟，特别值。',
    cardTitle:'提前半小时', context:'这十分钟里你按了 12 次快门。' },
  { id:'au_yeah', imageSrc:'assets/photos/real/a4.jpg', imageAlt:'比耶的合影',
    date:'2024-07-08T18:10', location:'悉尼大学 · 四方院前', title:'四方院前比个耶',
    reason:'一天里最放松的一张。哥特楼、草坪、牛仔裤，还有一个标准的游客比耶。',
    prompt:'这张照片想留下什么？',
    transcript:'就是想在这么好看的楼前面留个影，比个耶，特别游客但是特别开心。',
    tidied:'就是想在这么好看的楼前面留个影，比个耶，特别游客但特别开心。',
    cardTitle:'特别游客的耶', context:'这是这段旅程里你唯一的一张比耶照。' },
  { id:'au_sign', imageSrc:'assets/photos/real/a5.jpg', imageAlt:'红色指路牌与暮色海港',
    date:'2024-07-09T19:40', location:'达令港 · 指路牌', title:'红色的指路牌',
    reason:'行程最后一晚。暮色里这柱红色的路牌像一棵方向树，每块牌子都是你没来得及去的地方。',
    prompt:'最后一天在想什么？',
    transcript:'看着路牌上那些地名，好多都没去，想着下次再来，就把路牌拍下来了。',
    tidied:'看着路牌上那些地名，好多都没去，想着下次再来，就把路牌拍下来了。',
    cardTitle:'下次再来的理由', context:'牌子上有 8 个地名，你去了 3 个。' },
];
function seedAustraliaTrip(){
  const trip = {
    id: uid('trip'),
    name: '南半球的冬天', destination: '澳大利亚 · 悉尼', cities: 'Sydney',
    bigName: 'Australia', lastEchoDays: 12,
    startDate: '2024-07-06', endDate: '2024-07-09',
    photosCount: 95, usingSample: false, sample: true,
    coverSrc: 'assets/photos/real/a6.jpg',
    photos: AU_PHOTOS.map(p => ({ ...p })),
    timeline: AU_TIMELINE.map(n => ({ ...n, key: uid('node'), photoIds: [] })),
    moments: AU_MOMENTS.map(m => ({ ...m })),
    cards: [],
  };
  ['au_beach','au_gold','au_sign'].forEach(id => {
    const m = trip.moments.find(x => x.id === id);
    if(m) trip.cards.push(aiGenerateCard(m, m.tidied));
  });
  return trip;
}

/* ---------- 日本示例旅程：东京·横滨（SIGGRAPH Asia 2024，真实照片 j1-j6） ---------- */
const JP_PHOTOS = [
  { src:'assets/photos/real/j1.jpg', time:'2024-12-05T17:48', location:'横滨 · 港畔', alt:'蓝调时刻的钓鱼人' },
  { src:'assets/photos/real/j4.jpg', time:'2024-12-05T20:12', location:'东京 · 芝公园方向', alt:'夜里的东京塔' },
  { src:'assets/photos/real/j2.jpg', time:'2024-12-06T13:20', location:'便利店', alt:'整墙的杯面' },
  { src:'assets/photos/real/j3.jpg', time:'2024-12-07T10:40', location:'会展中心 · VR 展位', alt:'白纱帘后的 VR 体验' },
  { src:'assets/photos/real/j5.jpg', time:'2024-12-07T16:05', location:'SIGGRAPH Asia 会场', alt:'粉色野猪面具' },
  { src:'assets/photos/real/j6.jpg', time:'2024-12-08T11:32', location:'表参道 · amigo', alt:'芝士蛋糕的手提袋' },
];
const JP_TIMELINE = [
  { day:1, date:'12月5日', weekday:'星期四', time:'17:48', location:'横滨 · 港畔', tag:'蓝调', photoCount:14 },
  { day:1, date:'12月5日', weekday:'星期四', time:'20:12', location:'东京塔下', tag:'夜景', photoCount:22 },
  { day:2, date:'12月6日', weekday:'星期五', time:'13:20', location:'便利店', tag:'杯面墙', photoCount:9 },
  { day:3, date:'12月7日', weekday:'星期六', time:'10:40', location:'会展 · VR 展位', tag:'会场', photoCount:28 },
  { day:3, date:'12月7日', weekday:'星期六', time:'16:05', location:'SIGGRAPH Asia', tag:'面具', photoCount:17 },
  { day:4, date:'12月8日', weekday:'星期日', time:'11:32', location:'表参道', tag:'甜点', photoCount:11 },
];
const JP_MOMENTS = [
  { id:'jp_yokohama', imageSrc:'assets/photos/real/j1.jpg', imageAlt:'蓝调时刻的钓鱼人',
    date:'2024-12-05T17:48', location:'横滨 · 港畔', title:'蓝调时刻的钓鱼人',
    reason:'大会第一天结束，你沿着横滨港走回酒店，看到这个在暮色里钓鱼的人，站了很久。',
    prompt:'那天傍晚的港口是什么样的？',
    transcript:'一个人在暮色里钓鱼，海对面全是灯，就特别安静，我站在那看了很久。',
    tidied:'一个人在暮色里钓鱼，海对面全是灯，特别安静，我在那站了很久。',
    cardTitle:'暮色里的钓鱼人', context:'拍下它时，你刚从会场走了 2.3 km 回酒店。' },
  { id:'jp_tower', imageSrc:'assets/photos/real/j4.jpg', imageAlt:'夜里的东京塔',
    date:'2024-12-05T20:12', location:'东京 · 芝公园方向', title:'夜里的东京塔',
    reason:'冬天的东京塔亮灯时间刚好是晚饭后。你仰着头找了很久没有电线的角度。',
    prompt:'为什么拍了这么多张塔？',
    transcript:'就是觉得它亮起来那一瞬间特别好看，仰着头拍了二十多张，脖子都酸了。',
    tidied:'它亮起来那一瞬间特别好看，我仰着头拍了二十多张，脖子都酸了。',
    cardTitle:'仰头的二十张', context:'这 22 张东京塔里，有 19 张是同一个仰角。' },
  { id:'jp_cupnoodle', imageSrc:'assets/photos/real/j2.jpg', imageAlt:'整墙的杯面',
    date:'2024-12-06T13:20', location:'便利店', title:'整墙的杯面',
    reason:'一个再普通不过的便利店。你说要买"明天的早餐"，结果在杯面墙前站了五分钟。',
    prompt:'最后买了哪个？',
    transcript:'站在墙前面挑了半天，最后买了两个，一个辣的一个不辣的，都好吃。',
    tidied:'在墙前面挑了半天，最后买了两个，一个辣的一个不辣的，都好吃。',
    cardTitle:'选择困难现场', context:'这趟旅行你在便利店一共花了 40 分钟。' },
  { id:'jp_vr', imageSrc:'assets/photos/real/j3.jpg', imageAlt:'白纱帘后的 VR 体验',
    date:'2024-12-07T10:40', location:'会展中心 · VR 展位', title:'白纱帘后的世界',
    reason:'这是 SIGGRAPH Asia 的 VR 展位。你排了四十分钟队，就为了体验十分钟的 demo。',
    prompt:'那十分钟里看到了什么？',
    transcript:'排队四十分钟，体验十分钟，但值——伸手就能摸到光点，特别不真实。',
    tidied:'排队四十分钟，体验十分钟，但值——伸手就能摸到光点，特别不真实。',
    cardTitle:'十分钟的 Demo', context:'这是你全场排队最久的一个展位。' },
  { id:'jp_mask', imageSrc:'assets/photos/real/j5.jpg', imageAlt:'粉色野猪面具',
    date:'2024-12-07T16:05', location:'SIGGRAPH Asia 会场', title:'粉色野猪面具',
    reason:'会场里的手机支架面具。她把它举到脸前的那一秒，你按下了快门。',
    prompt:'为什么最喜欢这张？',
    transcript:'本来就是个手机支架，她举起来吐舌头那一秒特别好笑，就拍下来了。',
    tidied:'本来就是个手机支架，她举起来吐舌头那一秒特别好笑，就拍下来了。',
    cardTitle:'吐舌头的那一秒', context:'这是这段旅程你笑得最开心的一张照片。' },
  { id:'jp_cake', imageSrc:'assets/photos/real/j6.jpg', imageAlt:'芝士蛋糕的手提袋',
    date:'2024-12-08T11:32', location:'表参道 · amigo', title:'手提袋里的蛋糕',
    reason:'回程前的最后一站。为了这盒舒芙蕾芝士蛋糕，你多走了两公里。',
    prompt:'值得吗？',
    transcript:'值得。在公园边上吃完的，冬天的风里吃热乎的蛋糕，特别幸福。',
    tidied:'值得。在公园边上吃完的，冬天的风里吃热乎的蛋糕，特别幸福。',
    cardTitle:'冬天里的热蛋糕', context:'这是这段旅程的最后一张照片。' },
];
function seedJapanTrip(){
  const trip = {
    id: uid('trip'),
    name: '冬天的东京与横滨', destination: '日本 Japan', cities: 'Tokyo · Yokohama',
    bigName: 'Japan', lastEchoDays: 7,
    startDate: '2024-12-05', endDate: '2024-12-08',
    photosCount: 101, usingSample: false, sample: true,
    coverSrc: 'assets/photos/real/j4.jpg',
    photos: JP_PHOTOS.map(p => ({ ...p })),
    timeline: JP_TIMELINE.map(n => ({ ...n, key: uid('node'), photoIds: [] })),
    moments: JP_MOMENTS.map(m => ({ ...m })),
    cards: [],
  };
  ['jp_tower','jp_mask','jp_cake'].forEach(id => {
    const m = trip.moments.find(x => x.id === id);
    if(m) trip.cards.push(aiGenerateCard(m, m.tidied));
  });
  return trip;
}

function seedSerbiaTrip(){
  const photos = SERBIA_PHOTOS.map(p => ({ ...p }));
  const trip = {
    id: uid('trip'),
    name: '夏天的海岸与群山',
    destination: '意大利 · 塞尔维亚', cities: 'Belgrade · Zemun · Zlatibor',
    startDate: '2025-09-12', endDate: '2025-09-18',
    photos, photosCount: 100,
    usingSample: false, sample: true,
    bigName: 'Serbia', lastEchoDays: 3,
    coverSrc: 'assets/photos/real/r1.jpg',
    timeline: SERBIA_TIMELINE.map(n => ({ ...n, key: uid('node'), photoIds: [] })),
    moments: SERBIA_MOMENTS.map(m => ({ ...m })),
    cards: [],
  };
  ['st_positano','st_gondola'].forEach(id => {
    const m = trip.moments.find(x => x.id === id);
    if(m) trip.cards.push(aiGenerateCard(m, m.tidied));
  });
  return trip;
}
