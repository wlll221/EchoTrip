/* ============================================================
   EchoTrip · app.js
   单页状态机（新 IA）：
     · echohome  Echo 首页 —— 每日回响卡片堆（产品的"现在"）
     · trips     Trips 首页 —— 旅程列表（产品的"过去"）
     · create → analyzing → timeline → moments → capture
       → cardpreview → cards —— 单段旅程的线性创作流程
   线性流程中隐藏底部 Dock；两个首页 + Cards 之间自由切换。
   ============================================================ */
(() => {
'use strict';

/* ---------- tiny helpers ---------- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
const wait = ms => new Promise(r => setTimeout(r, ms));
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
const pad = n => String(n).padStart(2, '0');

function fmtMD(iso){ if(!iso) return '旅程中'; const d = new Date(iso); return `${d.getMonth()+1}月${d.getDate()}日`; }
function fmtMDT(iso){
  if(!iso) return '旅程中';
  const d = new Date(iso);
  return `${d.getMonth()+1}月${d.getDate()}日 ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function shortLoc(loc){ return (loc || '').split('·')[0].trim() || '那次旅行'; }
function toIso(d){
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/* ---------- icons ---------- */
const SW = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
const ICON = {
  mic:   `<svg width="22" height="22" viewBox="0 0 24 24" ${SW}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>`,
  stop:  `<svg width="24" height="24" viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2.5" fill="currentColor"/></svg>`,
  skip:  `<svg width="17" height="17" viewBox="0 0 24 24" ${SW}><path d="M5 5l7 7-7 7M13 5l7 7-7 7"/></svg>`,
  arrow: `<svg width="17" height="17" viewBox="0 0 24 24" ${SW}><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,
  upload:`<svg width="26" height="26" viewBox="0 0 24 24" ${SW}><path d="M12 15V4M7 8.5L12 3.5l5 5"/><path d="M4 15v3.5A2.5 2.5 0 0 0 6.5 21h11a2.5 2.5 0 0 0 2.5-2.5V15"/></svg>`,
  spark: `<svg width="21" height="21" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M10 2c.8 5 2.6 7.6 8 8.6-5.4 1-7.2 3.6-8 8.6-.8-5-2.6-7.6-8-8.6 5.4-1 7.2-3.6 8-8.6z"/><path d="M18.3 14.2c.35 2.2 1.15 3.35 3.55 3.8-2.4.45-3.2 1.6-3.55 3.8-.35-2.2-1.15-3.35-3.55-3.8 2.4-.45 3.2-1.6 3.55-3.8z" opacity=".9"/></svg>`,
  ripple:`<svg width="16" height="16" viewBox="0 0 24 24" ${SW}><circle cx="12" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="6" opacity=".6"/><circle cx="12" cy="12" r="10" opacity=".32"/></svg>`,
  plus:  `<svg width="15" height="15" viewBox="0 0 24 24" ${SW}><path d="M12 5v14M5 12h14"/></svg>`,
  check: `<svg width="17" height="17" viewBox="0 0 24 24" ${SW}><path d="M5 13l4 4L19 7"/></svg>`,
  chevL: `<svg width="20" height="20" viewBox="0 0 24 24" ${SW}><path d="M15 6l-6 6 6 6"/></svg>`,
  chevR: `<svg width="20" height="20" viewBox="0 0 24 24" ${SW}><path d="M9 6l6 6-6 6"/></svg>`,
  cal:   `<svg width="13" height="13" viewBox="0 0 24 24" ${SW}><rect x="4" y="5" width="16" height="16" rx="4"/><path d="M8 3v4M16 3v4M4 10.5h16"/></svg>`,
  pin:   `<svg width="13" height="13" viewBox="0 0 24 24" ${SW}><path d="M12 21s-7-5.1-7-11a7 7 0 0 1 14 0c0 5.9-7 11-7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>`,
  plane: `<svg width="20" height="20" viewBox="0 0 24 24" ${SW}><path d="M12 8v8"/><path d="M8 12h8"/></svg>`,
  plusCircle: `<svg width="23" height="23" viewBox="0 0 24 24" ${SW}><path d="M12 5v14"/><path d="M5 12h14"/></svg>`,
  arrowR: `<svg width="17" height="17" viewBox="0 0 24 24" ${SW}><path d="M4.5 12h14"/><path d="M13 6.5l5.5 5.5-5.5 5.5"/></svg>`,
  cal: `<svg width="13" height="13" viewBox="0 0 24 24" ${SW}><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M8 2.8v4M16 2.8v4M3.5 10h17"/></svg>`,
  dots:  `<svg width="18" height="18" viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.9" fill="currentColor"/><circle cx="12" cy="12" r="1.9" fill="currentColor"/><circle cx="19" cy="12" r="1.9" fill="currentColor"/></svg>`,
  play:  `<svg width="15" height="15" viewBox="0 0 24 24"><path d="M8.5 5.5v13l10.5-6.5z" fill="currentColor"/></svg>`,
  pause: `<svg width="15" height="15" viewBox="0 0 24 24"><rect x="7" y="5.5" width="3.4" height="13" rx="1.2" fill="currentColor"/><rect x="13.6" y="5.5" width="3.4" height="13" rx="1.2" fill="currentColor"/></svg>`,
  replay:`<svg width="16" height="16" viewBox="0 0 24 24" ${SW}><path d="M3 12a9 9 0 1 0 3.2-6.9L3 8"/><path d="M3 3v5h5"/></svg>`,
  back:  `<svg width="16" height="16" viewBox="0 0 24 24" ${SW}><path d="M19 12H5M11 6l-6 6 6 6"/></svg>`,
  rain:  `<svg width="13" height="13" viewBox="0 0 24 24" ${SW}><path d="M20 15.5A4.5 4.5 0 0 0 18 7h-1.3A7 7 0 1 0 4 14.8"/><path d="M8 18.5v2.5M12 16.5v2.5M16 18.5v2.5"/></svg>`,
  camera:`<svg width="34" height="34" viewBox="0 0 24 24" ${SW}><path d="M4 8h3.2L9 5.5h6L16.8 8H20v11H4z"/><circle cx="12" cy="13" r="3.2"/></svg>`,
  bigRipple:`<svg width="34" height="34" viewBox="0 0 24 24" ${SW}><circle cx="12" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="6" opacity=".6"/><circle cx="12" cy="12" r="10" opacity=".3"/></svg>`,
};

/* ---------- state ---------- */
const S = {
  trips: [],           // 所有旅程（Trips 首页数据源，Store 持久化）
  trip: null,          // 当前打开的 Trip
  moments: [],         // 当前 Trip 的全部 Moments（含用户添加）
  idx: 0,              // deck 当前索引
  pendingIdx: null,    // 正在 capture 的 moment 索引
  userPhotos: [],      // 本次创建流程中 {src, name, time:Date|null}
  sortNote: '已按导入顺序排列',
  photoDetail: null,    // 沉浸照片详情页：{trip, items, index, backView}
  timers: [],          // 定时器（视图切换时统一清理）
  cleanup: null,       // 视图卸载清理（如键盘监听）
};
const T = (fn, ms) => S.timers.push(setTimeout(fn, ms));
const tripPhotoCount = trip => (trip && Array.isArray(trip.photos) ? trip.photos.length : 0);
const tripMemoryCount = trip => (trip && Array.isArray(trip.cards) ? trip.cards.length : 0);
const fmtDuration = seconds => {
  const value = Math.max(0, Math.round(Number(seconds) || 0));
  return `${Math.floor(value / 60)}:${pad(value % 60)}`;
};

/* 真实语音采集：MediaRecorder 保存音频，SpeechRecognition 实时转写。 */
let whisperPipelinePromise = null;
let whisperPipelineInstance = null;

async function decodeSpeechAudio(blob){
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if(!AudioCtx) throw new Error('当前浏览器无法解码录音');
  const ctx = new AudioCtx();
  try{
    const decoded = await ctx.decodeAudioData((await blob.arrayBuffer()).slice(0));
    const mono = new Float32Array(decoded.length);
    for(let channel = 0; channel < decoded.numberOfChannels; channel++){
      const values = decoded.getChannelData(channel);
      for(let i = 0; i < values.length; i++) mono[i] += values[i] / decoded.numberOfChannels;
    }
    if(decoded.sampleRate === 16000) return mono;
    const targetLength = Math.max(1, Math.round(mono.length * 16000 / decoded.sampleRate));
    const output = new Float32Array(targetLength);
    const ratio = decoded.sampleRate / 16000;
    for(let i = 0; i < targetLength; i++){
      const pos = i * ratio;
      const left = Math.floor(pos);
      const right = Math.min(left + 1, mono.length - 1);
      const mix = pos - left;
      output[i] = mono[left] * (1 - mix) + mono[right] * mix;
    }
    return output;
  }finally{
    await ctx.close();
  }
}

async function getWhisperPipeline(onStatus){
  if(!whisperPipelinePromise){
    whisperPipelinePromise = (async () => {
      onStatus && onStatus('首次使用：正在下载约 80MB 的中文语音模型…');
      const { pipeline, env } = await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1');
      env.allowRemoteModels = true;
      env.useBrowserCache = true;
      whisperPipelineInstance = await pipeline(
        'automatic-speech-recognition',
        'onnx-community/whisper-base',
        {
          dtype:'q8',
          progress_callback: info => {
            if(info.status === 'progress' && Number.isFinite(info.progress)){
              onStatus && onStatus(`首次使用：正在下载中文语音模型 ${Math.round(info.progress)}%`);
            }else if(info.status === 'ready'){
              onStatus && onStatus('中文语音模型已就绪，正在转成文字…');
            }
          },
        },
      );
      return whisperPipelineInstance;
    })().catch(error => {
      whisperPipelinePromise = null;
      whisperPipelineInstance = null;
      throw error;
    });
  }
  return whisperPipelinePromise;
}

async function transcribeAudioLocally(blob, onStatus){
  if(!(blob instanceof Blob) || !blob.size) throw new Error('录音内容为空');
  onStatus && onStatus('浏览器在线识别不可用，正在启用本地 Whisper…');
  const [transcriber, audio] = await Promise.all([
    getWhisperPipeline(onStatus),
    decodeSpeechAudio(blob),
  ]);
  onStatus && onStatus('正在本机转成文字…');
  const result = await transcriber(audio, { language:'chinese', task:'transcribe' });
  return String(result && result.text || '').trim();
}

window.addEventListener('pagehide', () => {
  if(whisperPipelineInstance && whisperPipelineInstance.dispose){
    Promise.resolve(whisperPipelineInstance.dispose()).catch(() => {});
    whisperPipelineInstance = null;
    whisperPipelinePromise = null;
  }
});

function createVoiceSession(onTranscript, onStatus){
  let stream = null, recorder = null, recognition = null, chunks = [];
  let finalText = '', interimText = '', startedAt = 0, stopping = false, recognitionError = '';
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  const publish = () => onTranscript && onTranscript((finalText + interimText).trim());
  return {
    async start(){
      if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('当前浏览器不支持麦克风录音');
      if(typeof MediaRecorder === 'undefined') throw new Error('当前浏览器不支持音频录制');
      stream = await navigator.mediaDevices.getUserMedia({ audio:{ echoCancellation:true, noiseSuppression:true, autoGainControl:true } });
      const preferred = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find(type => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(type));
      recorder = preferred ? new MediaRecorder(stream, { mimeType:preferred }) : new MediaRecorder(stream);
      recorder.ondataavailable = event => { if(event.data && event.data.size) chunks.push(event.data); };
      recorder.start(250);
      startedAt = Date.now();

      if(SpeechRecognition){
        recognition = new SpeechRecognition();
        recognition.lang = 'zh-CN';
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.onresult = event => {
          interimText = '';
          for(let i = event.resultIndex; i < event.results.length; i++){
            const value = event.results[i][0].transcript;
            if(event.results[i].isFinal) finalText += value;
            else interimText += value;
          }
          publish();
        };
        recognition.onerror = event => {
          recognitionError = event && event.error ? event.error : 'recognition-error';
        };
        recognition.onend = () => {
          if(!stopping && recorder && recorder.state === 'recording'){
            try{ recognition.start(); }catch(e){}
          }
        };
        try{ recognition.start(); }catch(e){ recognition = null; }
      }
    },
    async stop(){
      stopping = true;
      if(recognition){ try{ recognition.stop(); }catch(e){} }
      const blob = await new Promise(resolve => {
        if(!recorder || recorder.state === 'inactive') return resolve(new Blob(chunks, { type:(recorder && recorder.mimeType) || 'audio/webm' }));
        recorder.onstop = () => resolve(new Blob(chunks, { type:recorder.mimeType || 'audio/webm' }));
        recorder.stop();
      });
      if(stream) stream.getTracks().forEach(track => track.stop());
      await wait(280);
      let transcript = (finalText + interimText).trim();
      let transcriptSource = transcript ? 'browser-speech' : 'audio-only';
      if(!transcript && blob.size){
        try{
          transcript = await transcribeAudioLocally(blob, onStatus);
          if(transcript){ transcriptSource = 'whisper-local'; onTranscript && onTranscript(transcript); }
        }catch(localError){
          recognitionError = recognitionError || (localError && localError.message) || 'transcription-failed';
        }
      }
      return {
        blob,
        url: blob.size ? URL.createObjectURL(blob) : '',
        transcript,
        duration: Math.max(0, (Date.now() - startedAt) / 1000),
        mimeType: blob.type,
        transcriptSource,
        recognitionError,
      };
    },
    cancel(){
      stopping = true;
      if(recognition){ try{ recognition.abort(); }catch(e){} }
      if(recorder && recorder.state !== 'inactive'){ try{ recorder.stop(); }catch(e){} }
      if(stream) stream.getTracks().forEach(track => track.stop());
    },
  };
}

let activeCardAudio = null;
function toggleCardAudio(card, voiceEl){
  if(!card || !card.audioUrl){ toast('这段回忆暂无可播放的原始录音'); return; }
  if(activeCardAudio && activeCardAudio.__cardId === card.id){
    if(activeCardAudio.paused){ activeCardAudio.play(); voiceEl.closest('.td-vc')?.classList.add('playing'); }
    else{ activeCardAudio.pause(); voiceEl.closest('.td-vc')?.classList.remove('playing'); }
    return;
  }
  if(activeCardAudio){ activeCardAudio.pause(); document.querySelectorAll('.td-vc.playing').forEach(el => el.classList.remove('playing')); }
  const audio = new Audio(card.audioUrl);
  audio.__cardId = card.id;
  activeCardAudio = audio;
  const owner = voiceEl.closest('.td-vc');
  audio.onended = () => owner && owner.classList.remove('playing');
  audio.play().then(() => owner && owner.classList.add('playing')).catch(() => toast('暂时无法播放这段录音'));
}

/* ============================================================
   视图渲染器 —— 新 IA：两个首页 + 创作流程
   · echohome  Echo 首页（现在）：每日回响卡片堆
   · trips     Trips 首页（过去）：旅程列表 + 创建入口
   · create → analyzing → timeline → moments → capture
     → cardpreview → cards：单段旅程的线性流程
   ============================================================ */
const RENDER = { echohome, trips, tripdetail, photodetail, create, analyzing, timeline, moments, capture, cardpreview, cards };

/* ---------- 沉浸照片详情 ---------- */
function photoDetailItem(trip, photo, fallback = {}){
  const moments = (trip && trip.moments) || [];
  const cards = (trip && trip.cards) || [];
  const src = photo.src || photo.imageSrc || fallback.imageSrc || '';
  const photoId = photo.id || photo.photoId || fallback.photoId;
  const moment = moments.find(m => (photoId && m.photoId === photoId) || (src && m.imageSrc === src));
  const card = cards.find(c => (photoId && c.photoId === photoId) || (moment && c.momentId === moment.id) || (src && c.imageSrc === src));
  const location = card?.location || moment?.location || photo.location || fallback.location || trip?.cities || trip?.destination || '旅程途中';
  const title = card?.title || moment?.cardTitle || moment?.title || photo.title || photo.alt || fallback.title || '被光记住的一刻';
  const hasMemory = !!(card || moment?.userMemory || moment?.audioUrl || fallback.memory);
  const memory = hasMemory ? (card?.memory || moment?.tidied || moment?.transcript || fallback.memory || '') : '';
  const prompt = moment?.prompt || photo.aiHint || fallback.prompt || `回到${shortLoc(location)}的这一刻，你最先想起了什么？`;
  return {
    id:photoId || card?.id || moment?.id || src,
    src,
    alt:photo.alt || photo.imageAlt || fallback.imageAlt || title,
    location,
    title,
    memory,
    prompt,
    moment,
    card,
    hasMemory,
    audioUrl:card?.audioUrl || moment?.audioUrl || '',
    audioDuration:Number(card?.audioDuration || moment?.audioDuration || 0),
  };
}

function buildPhotoDetailItems(trip, selected = {}){
  const base = (trip && trip.photos && trip.photos.length) ? trip.photos : [];
  const extras = [selected, ...((trip && trip.cards) || []), ...((trip && trip.moments) || [])];
  const seen = new Set();
  const raw = [...base, ...extras].filter(item => {
    const src = item && (item.src || item.imageSrc);
    if(!src || seen.has(src)) return false;
    seen.add(src);
    return true;
  });
  return raw.map(item => photoDetailItem(trip, item, item === selected ? selected : {}));
}

function openPhotoDetail(trip, selected, backView = 'tripdetail'){
  const activeTrip = trip || S.trip || S.trips[0];
  if(!activeTrip || !selected) return;
  S.trip = activeTrip;
  S.moments = activeTrip.moments || [];
  const items = buildPhotoDetailItems(activeTrip, selected);
  const selectedSrc = selected.src || selected.imageSrc;
  const index = Math.max(0, items.findIndex(item => item.src === selectedSrc));
  const returnTab = backView === 'tripdetail'
    ? (($('#tdTabs button.on') || {}).dataset?.t || 'moments')
    : null;
  S.photoDetail = { trip:activeTrip, items, index:index < 0 ? 0 : index, backView, returnTab };
  if(backView === 'tripdetail') S.tdReveal = { tab:returnTab, reveal:false };
  go('photodetail');
}

function openEchoPhotoDetail(entry){
  const trip = S.trips.find(t => (t.photos || []).some(p => p.src === entry.imageSrc) || (t.cards || []).some(c => c.imageSrc === entry.imageSrc));
  if(trip){
    const selected = (trip.photos || []).find(p => p.src === entry.imageSrc)
      || (trip.cards || []).find(c => c.imageSrc === entry.imageSrc)
      || entry;
    openPhotoDetail(trip, selected, 'echohome');
    return;
  }
  const virtualTrip = {
    id:'echo-today', destination:entry.region, cities:entry.region,
    photos:ECHO_TODAY.map((e, i) => ({ id:e.key, src:e.imageSrc, alt:e.imageAlt || e.titleLines.join(''), location:e.location, title:e.titleLines.join('') })),
    moments:ECHO_TODAY.map((e, i) => ({ id:`echo_m_${i}`, photoId:e.key, imageSrc:e.imageSrc, location:e.location, title:e.titleLines.join(''), prompt:`回到${shortLoc(e.location)}的这一刻，你最先想起了什么？` })),
    cards:ECHO_TODAY.map((e, i) => ({ id:`echo_c_${i}`, photoId:e.key, momentId:`echo_m_${i}`, imageSrc:e.imageSrc, location:e.location, title:e.titleLines.join(''), memory:e.quote, audioDuration:28 })),
  };
  openPhotoDetail(virtualTrip, virtualTrip.photos.find(p => p.src === entry.imageSrc), 'echohome');
}

function photodetail(){
  const state = S.photoDetail;
  if(!state || !state.items.length) return el('<section class="view pd-view"></section>');
  const waveBars = Array.from({ length:22 }, (_, i) => `<i style="height:${[7,12,18,10,22,15,9,20,13,24,16,8,18,12,21,14,9,17,11,15,8,12][i]}px"></i>`).join('');
  const renderCard = item => item.hasMemory ? `
    <div class="pd-location">${ICON.pin}<span>${esc(item.location)}</span></div>
    <h1>${esc(item.title)}</h1>
    ${item.memory ? `<p class="pd-memory">${esc(item.memory)}</p>` : ''}
    <div class="pd-memory-actions">
      <button class="pd-player" id="pdPlayer" type="button" aria-label="播放回忆语音">
        <span class="pd-play-icon">${ICON.play}</span>
        <span class="pd-wave" aria-hidden="true">${waveBars}</span>
        <span class="pd-duration">${fmtDuration(item.audioDuration || 28)}</span>
      </button>
      <button class="pd-action pd-action-secondary" id="pdRemember" type="button">${ICON.mic}<span>补充回忆</span></button>
    </div>` : `
    <div class="pd-location">${ICON.pin}<span>${esc(item.location)}</span></div>
    <p class="pd-question">${esc(item.prompt)}</p>
    <button class="pd-quick-mic" id="pdRemember" type="button" aria-label="开始回忆">${ICON.mic}</button>`;

  const v = el(`<section class="view pd-view">
    <div class="pd-bg-wrap"><img class="pd-bg-blur" id="pdBgBlur" src="${esc(state.items[state.index].src)}" alt="" aria-hidden="true"><img class="pd-bg" id="pdBg" src="${esc(state.items[state.index].src)}" alt="${esc(state.items[state.index].alt)}"><span class="pd-bg-shade" aria-hidden="true"></span></div>
    <div class="pd-card ${state.items[state.index].hasMemory ? 'is-memory' : 'is-empty'}" id="pdCard">${renderCard(state.items[state.index])}</div>
    <div class="pd-thumbs" id="pdThumbs" role="tablist" aria-label="切换照片">
      ${state.items.map((item, i) => `<button class="pd-thumb${i === state.index ? ' on' : ''}" type="button" role="tab" aria-selected="${i === state.index}" data-pdi="${i}"><img src="${esc(item.src)}" alt="${esc(item.alt)}"></button>`).join('')}
    </div>
  </section>`);

  v._mount(function(){
    let audio = null;
    const stopAudio = () => {
      if(audio){ audio.pause(); audio = null; }
      const player = $('#pdPlayer', v);
      if(player){ player.classList.remove('playing'); $('.pd-play-icon', player).innerHTML = ICON.play; }
    };
    const bindCard = item => {
      const remember = $('#pdRemember', v);
      if(remember) remember.onclick = () => {
        let moment = item.moment;
        if(!moment){
          moment = {
            id:uid('mm'), photoId:item.id, imageSrc:item.src, imageAlt:item.alt,
            date:state.trip.startDate || '', location:item.location,
            title:item.title, prompt:item.prompt, cardTitle:item.title,
            transcript:'', tidied:'', userAdded:true,
          };
          state.trip.moments = state.trip.moments || [];
          state.trip.moments.push(moment);
          S.moments = state.trip.moments;
          item.moment = moment;
          Store.save(S.trips);
        }
        stopAudio();
        openRecordSheet(state.trip, v, {
          moments:[moment],
          single:true,
          onSaved:() => {
            const sourcePhoto = (state.trip.photos || []).find(photo => photo.src === item.src) || item;
            state.items[state.index] = photoDetailItem(state.trip, sourcePhoto);
            select(state.index);
          },
        });
      };
      const player = $('#pdPlayer', v);
      if(player) player.onclick = () => {
        if(!item.audioUrl){ toast('这段回忆保留了文字，暂无原始录音'); return; }
        if(audio && !audio.paused){ stopAudio(); return; }
        audio = new Audio(item.audioUrl);
        audio.onended = stopAudio;
        audio.ontimeupdate = () => {
          const progress = audio.duration ? audio.currentTime / audio.duration : 0;
          player.style.setProperty('--pd-progress', `${Math.round(progress * 100)}%`);
          $('.pd-duration', player).textContent = fmtDuration(Math.max(0, audio.duration - audio.currentTime));
        };
        audio.play().then(() => {
          player.classList.add('playing');
          $('.pd-play-icon', player).innerHTML = ICON.pause;
        }).catch(() => toast('暂时无法播放这段录音'));
      };
    };
    const select = index => {
      stopAudio();
      state.index = index;
      const item = state.items[index];
      const bg = $('#pdBg', v);
      const blur = $('#pdBgBlur', v);
      bg.classList.add('changing');
      const syncOrientation = () => v.classList.toggle('is-landscape', bg.naturalWidth > bg.naturalHeight);
      setTimeout(() => {
        bg.onload = () => { syncOrientation(); bg.classList.remove('changing'); };
        blur.src = item.src;
        bg.src = item.src;
        bg.alt = item.alt;
        if(bg.complete){ syncOrientation(); bg.classList.remove('changing'); }
      }, 120);
      const card = $('#pdCard', v);
      card.classList.add('changing');
      setTimeout(() => {
        card.classList.toggle('is-memory', item.hasMemory);
        card.classList.toggle('is-empty', !item.hasMemory);
        card.innerHTML = renderCard(item);
        card.classList.remove('changing');
        bindCard(item);
      }, 120);
      $$('.pd-thumb', v).forEach((thumb, i) => {
        thumb.classList.toggle('on', i === index);
        thumb.setAttribute('aria-selected', i === index ? 'true' : 'false');
      });
      const selected = $(`.pd-thumb[data-pdi="${index}"]`, v);
      selected?.scrollIntoView({ behavior:'smooth', block:'nearest', inline:'center' });
    };
    $$('.pd-thumb', v).forEach(thumb => thumb.onclick = () => select(+thumb.dataset.pdi));
    const initialBg = $('#pdBg', v);
    const syncInitialOrientation = () => v.classList.toggle('is-landscape', initialBg.naturalWidth > initialBg.naturalHeight);
    initialBg.onload = syncInitialOrientation;
    if(initialBg.complete) syncInitialOrientation();
    bindCard(state.items[state.index]);
    S.cleanup = stopAudio;
  });
  return v;
}

/* ============================================================
   Echo 首页 —— 产品的"现在"
   极简三段式：顶部极简信息 / 三张堆叠回忆卡 / 底部 Tab。
   主卡 = 今日回响；背后两张待切换；滑动或点背后卡前进。
   背景取主卡照片做高斯模糊氛围填充（见 .amb）。
   ============================================================ */
function echohome(){
  const mine = S.trips.flatMap(t => t.cards || []);
  const feed = echoFeedFor(mine);
  let fi = 0;       // 当前回响索引（循环）
  let ambA = true;  // 氛围背景当前显示层

  const v = el(`<section class="view echo-home">
    <div class="amb">
      <img class="amb-img a" alt="" aria-hidden="true" onerror="this.onerror=null;this.src='assets/photos/p16.svg'">
      <img class="amb-img b" alt="" aria-hidden="true" onerror="this.onerror=null;this.src='assets/photos/p16.svg'">
      <div class="amb-scrim"></div>
    </div>
    <div class="eh-top">
      <button class="eh-avatar-btn" type="button" aria-label="查看个人主页">
        <img class="eh-avatar" src="assets/img/avatar_real.webp" alt="你的头像">
      </button>
      <div class="eh-brand">
        <h1>EchoTrip</h1>
        <button class="eh-loc" type="button" aria-label="切换回音城市">${ICON.pin}<span id="ehRegion"></span><svg class="chev" width="10" height="10" viewBox="0 0 24 24" ${SW}><path d="M6 9l6 6 6-6"/></svg></button>
      </div>
      <button class="eh-plane" aria-label="新建旅程" title="新建旅程">${ICON.plusCircle}</button>
    </div>
    <div class="eh-stage" id="ehStage"></div>
  </section>`);

  function cardHTML(e){
    return `<article class="e-card">
      <img class="ec-img" src="${esc(e.imageSrc)}" alt="${esc(e.imageAlt || '')}" draggable="false" onerror="this.onerror=null;this.src='assets/photos/p16.svg'">
      <div class="ec-scrim"></div>
      <div class="ec-info">
        <div class="ec-when">${esc(e.dateLabel)}</div>
        <div class="ec-loc">${ICON.pin}<span>${esc(e.location)}</span></div>
      </div>
      <div class="ec-main">
        <h3 class="ec-title">${e.titleLines.map(esc).join('<br>')}</h3>
        <p class="ec-quote">“${esc(e.quote)}”</p>
      </div>
      <div class="ec-trigger">${ICON.spark}<span class="tt-main">${esc(e.trigger)}</span></div>
      <button class="ec-play" aria-label="下一段回忆">${ICON.arrowR}</button>
    </article>`;
  }

  /* 氛围背景：双层交叉淡入到当前主卡照片 */
  function setAmbient(src){
    const a = $('.amb-img.a', v), b = $('.amb-img.b', v);
    const show = ambA ? a : b, hide = ambA ? b : a;
    if(show.dataset.init !== '1'){
      show.src = src; show.style.opacity = '1'; show.dataset.init = '1';
      return;
    }
    hide.src = src;
    hide.style.opacity = '1';
    show.style.opacity = '0';
    ambA = !ambA;
  }

  function renderDeck(){
    const stage = $('#ehStage', v);
    stage.innerHTML = '<div class="eh-deck"></div>';
    const deck = stage.firstElementChild;
    for(let d = 0; d < 3; d++){
      const e = feed[(fi + d) % feed.length];
      const card = el(cardHTML(e));
      card.style.zIndex = String(10 - d);
      if(d === 0){
        card.addEventListener('animationend', () => { card.style.animation = 'none'; }, { once: true });
        attachEchoDrag(card);
        const play = $('.ec-play', card);
        play.onclick = ev => { ev.stopPropagation(); advance(); };
        card.onclick = ev => {
          if(ev.target.closest('.ec-play') || card.__echoMoved) return;
          openEchoPhotoDetail(e);
        };
      }else{
        card.classList.add('behind');
        card.style.animation = 'none';
        /* 交错堆叠：反向微旋转 + 左右错位 + 逐级收窄（参考稿几何） */
        const POSE = { 1:{y:-40,x:-6,r:-1.2,s:.92}, 2:{y:-72,x:7,r:1.8,s:.85} };
        const p = POSE[d] || {y:-24*d,x:0,r:0,s:1-.05*d};
        card.style.transform = `translate(${p.x}px, ${p.y}px) rotate(${p.r}deg) scale(${p.s})`;
        card.style.filter = d === 1 ? 'blur(.5px) brightness(.9)' : 'blur(1.5px) brightness(.78)';
        card.onclick = () => advance();
      }
      deck.appendChild(card);
    }
    $('#ehRegion', v).textContent = feed[fi].region;
    setAmbient(feed[fi].imageSrc);
  }

  function advance(){ fi = (fi + 1) % feed.length; renderDeck(); }

  /* 任意方向轻扫：主卡飞出，下一张浮现（循环） */
  function attachEchoDrag(card){
    let sx = 0, sy = 0, dx = 0, dy = 0, dragging = false;
    card.addEventListener('pointerdown', e => {
      if(e.button !== 0 || e.target.closest('.ec-play')) return;
      dragging = true; sx = e.clientX; sy = e.clientY; dx = dy = 0;
      card.setPointerCapture(e.pointerId);
      card.classList.add('dragging');
    });
    card.addEventListener('pointermove', e => {
      if(!dragging) return;
      dx = e.clientX - sx; dy = e.clientY - sy;
      if(Math.hypot(dx, dy) > 7) card.__echoMoved = true;
      const k = Math.min(Math.hypot(dx, dy) / 130, 1);
      card.style.transform = `translate(${dx}px, ${dy * .6}px) rotate(${dx * .04}deg) scale(${1 - k * .05})`;
      card.style.opacity = String(1 - k * .35);
    });
    const end = () => {
      if(!dragging) return;
      dragging = false;
      card.classList.remove('dragging');
      if(Math.abs(dx) > 90 || dy < -70){
        const horiz = Math.abs(dx) >= Math.abs(dy);
        card.style.transition = 'transform .45s cubic-bezier(.3,.6,.4,1), opacity .35s ease';
        card.style.transform = horiz
          ? `translate(${Math.sign(dx) * 640}px, -30px) rotate(${Math.sign(dx) * 10}deg) scale(.92)`
          : 'translate(0, -560px) scale(.9)';
        card.style.opacity = '0';
        setTimeout(advance, 250);
      }else{
        card.style.transition = 'transform .4s var(--ease-spring), opacity .3s ease';
        card.style.transform = '';
        card.style.opacity = '';
        setTimeout(() => { card.style.transition = ''; }, 420);
      }
      dx = dy = 0;
      setTimeout(() => { card.__echoMoved = false; }, 0);
    };
    card.addEventListener('pointerup', end);
    card.addEventListener('pointercancel', end);
  }

  v._mount(function(){
    renderDeck();
    $('.eh-plane', v).onclick = () => { S.userPhotos = []; go('create'); };
    $('.eh-avatar-btn', v).onclick = () => toast('个人主页将在登录功能上线后开放');
    $('.eh-loc', v).onclick = () => toast('城市切换正在准备中，当前展示与回音关联的地点');
    const keyNav = e => {
      if(e.key === 'ArrowRight' || e.key === 'ArrowLeft') advance();
    };
    document.addEventListener('keydown', keyNav);
    S.cleanup = () => document.removeEventListener('keydown', keyNav);
  });
  return v;
}

/* ============================================================
   Trips 首页 —— 产品的"过去"
   看到已经留下了哪些旅程，以及开始新的旅程。
   ============================================================ */
function trips(){
  const ambSrc = (S.trips[0] && ((S.trips[0].photos && S.trips[0].photos[0] && S.trips[0].photos[0].src) || S.trips[0].coverSrc)) || 'assets/photos/real/r1.jpg';
  /* 按年份分组（倒序） */
  const groups = {};
  S.trips.forEach(t => { const y = new Date(t.startDate).getFullYear(); (groups[y] = groups[y] || []).push(t); });
  const years = Object.keys(groups).sort((x, y) => y - x);
  const chev = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 9l7 7 7-7"/></svg>`;
  return el(`<section class="view trips-view">
    <span class="tr-amb" aria-hidden="true"><img src="${esc(ambSrc)}" alt=""></span>
    <span class="tr-ghost" aria-hidden="true">YOUR TRIPS</span>
    <div class="trips-wrap">
      <button class="tr-newbtn" id="trAdd">${ICON.plus} 新建旅程</button>
      ${years.map((y, gi) => `
        <div class="tr-year" role="button" tabindex="0" data-year="${y}" aria-expanded="true" aria-label="收起 ${y} 年旅程" style="animation-delay:${(.04 + gi * .07).toFixed(2)}s">
          <span class="tr-year-num">${y}</span>
          <span class="tr-chev" aria-hidden="true">${chev}</span>
        </div>
        <div class="tr-list" data-year="${y}"></div>`).join('')}
      ${!years.length ? '<div class="tr-empty">还没有旅程。<br>从一次出门、几张照片开始。</div>' : ''}
    </div>
  </section>`)
  ._mount(function(){
    const add = $('#trAdd', this);
    if(add) add.onclick = () => { S.userPhotos = []; go('create'); };
    $$('.tr-list', this).forEach(list => {
      const year = list.dataset.year;
      (groups[year] || []).forEach((trip, i) => {
        const cover = trip.coverSrc || (trip.photos && trip.photos[0] && trip.photos[0].src) || sampleSrc('p01');
        const cards = trip.cards || [];
        const big = String(trip.bigName || trip.destination || 'Journey').toUpperCase();
        const d0 = new Date(trip.startDate), d1 = new Date(trip.endDate);
        const p2 = n => String(n).padStart(2, '0');
        const echo = cards.length ? `回音 · ${trip.lastEchoDays || 1} 天前` : '还没有回音';
        const card = el(`<div class="tr-card" role="button" tabindex="0" style="animation-delay:${(.08 + i * .12).toFixed(2)}s">
          <span class="tr-cover"><img src="${esc(cover)}" alt="" onerror="this.onerror=null;this.src='assets/photos/p01.svg'"></span>
          <span class="tr-scrim" aria-hidden="true"></span>
          <span class="tr-stat">${tripPhotoCount(trip)} 张照片 · ${tripMemoryCount(trip)} 段回忆</span>
          <button class="tr-del" aria-label="删除这段旅程" title="删除这段旅程">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1.5 1.5 0 0 1 1.5-1.5h5A1.5 1.5 0 0 1 16 4v2"/><path d="M19 6l-.8 13.1a2 2 0 0 1-2 1.9H7.8a2 2 0 0 1-2-1.9L5 6"/><path d="M10 11v6M14 11v6"/></svg>
          </button>
          <span class="tr-big" aria-hidden="true">${esc(big)}</span>
          <span class="tr-info">
            <span class="tr-loc">${ICON.pin}<span>${esc(trip.cities || trip.destination || 'City')}</span></span>
            <span class="tr-foot">${ICON.cal}<span>${d0.getFullYear()}.${p2(d0.getMonth() + 1)}.${p2(d0.getDate())} – ${p2(d1.getMonth() + 1)}.${p2(d1.getDate())}</span><em>｜</em><span>${echo}</span></span>
          </span>
        </div>`);
        const enter = () => openTrip(trip);
        card.onclick = e => { if(e.target.closest('.tr-del')) return; enter(); };
        card.onkeydown = e => {
          if(e.target.closest('.tr-del')) return;
          if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); enter(); }
        };
        $('.tr-del', card).onclick = e => { e.stopPropagation(); confirmDeleteTrip(trip); };
        list.appendChild(card);
      });
    });
    $$('.tr-year', this).forEach(head => {
      const list = $(`.tr-list[data-year="${head.dataset.year}"]`, this);
      const toggle = () => {
        const collapsed = head.getAttribute('aria-expanded') === 'true';
        head.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        head.setAttribute('aria-label', `${collapsed ? '展开' : '收起'} ${head.dataset.year} 年旅程`);
        head.classList.toggle('collapsed', collapsed);
        if(list) list.hidden = collapsed;
      };
      head.onclick = toggle;
      head.onkeydown = e => {
        if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); toggle(); }
      };
    });
  });
}

/* ---------- Trip Detail（照片合集 · Moments / Timeline · 参考稿） ---------- */
function tripdetail(){
  const trip = S.trip || S.trips[0];
  const photos = trip.photos || [];
  const mts = trip.moments || [];
  const cards = trip.cards || [];
  const big = String(trip.bigName || trip.destination || 'Journey').toUpperCase();
  const stats = `${tripPhotoCount(trip)} 张照片 · ${tripMemoryCount(trip)} 段回忆`;
  const cover = trip.coverSrc || (photos[0] && photos[0].src) || 'assets/photos/real/r1.jpg';
  const wave = n => Array.from({ length: n }, (_, i) =>
    `<i style="height:${[6, 11, 8, 14, 9, 5, 12, 7, 10, 6, 13, 8][i % 12]}px"></i>`).join('');
  const sparkSm = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M10 2c.8 5 2.6 7.6 8 8.6-5.4 1-7.2 3.6-8 8.6-.8-5-2.6-7.6-8-8.6 5.4-1 7.2-3.6 8-8.6z"/></svg>`;
  const iGrid = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg>`;
  const iList = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8.5 6h11M8.5 12h11M8.5 18h11"/><circle cx="4.2" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.2" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.2" cy="18" r="1.3" fill="currentColor" stroke="none"/></svg>`;

  /* 精选语音回忆卡（横向滑动，两侧 peek） */
  const caroHTML = cards.length ? `
    <div class="td-caro" id="tdCaro">
      ${cards.map((c, i) => `
      <article class="td-vc" data-ci="${i}" role="button" tabindex="0" aria-label="查看回忆：${esc(c.title)}">
        <img src="${esc(c.imageSrc)}" alt="${esc(c.imageAlt || '')}">
        <span class="td-vc-scrim" aria-hidden="true"></span>
        <div class="td-vc-txt"><b>${esc(c.title)}</b><p>"${esc(c.memory)}"</p></div>
        ${c.audioUrl
          ? `<span class="td-vc-voice"><span class="td-wave" aria-hidden="true">${wave(12)}</span><em>${fmtDuration(c.audioDuration)}</em></span>`
          : '<span class="td-vc-text-badge">文字回忆</span>'}
      </article>`).join('')}
    </div>` : '';

  /* 苹果相册式宫格 */
  const groups = [];
  for(let i = 0, g = 0; i < photos.length; g++){
    groups.push({ pat: g % 4, items: photos.slice(i, i + 3) });
    i += 3;
  }
  let pi = 0;
  const cellHTML = (p, idx, isBig) => `
      <div class="td-cell ${isBig ? 'td-cell-big' : ''}" role="button" tabindex="0" data-pi="${idx}">
        <img src="${esc(p.src)}" alt="${esc(p.alt || '')}" loading="lazy">
        ${p.hasMemory ? '<span class="td-tag">已回忆</span>' : ''}
        ${p.aiHint && !p.hasMemory ? `<span class="td-hint">${sparkSm}<span>${esc(p.aiHint)}</span></span>` : ''}
      </div>`;
  const grid = groups.map(gr => {
    const cells = gr.items.map(p => ({ p, idx: pi++ }));
    if(cells.length < 3 || gr.pat === 0 || gr.pat === 2){
      return `<div class="td-gr td-gr-row">${cells.map(c0 => cellHTML(c0.p, c0.idx, false)).join('')}</div>`;
    }
    if(gr.pat === 1){
      return `<div class="td-gr td-gr-mos">${cells.map((c0, j) => cellHTML(c0.p, c0.idx, j === 0)).join('')}</div>`;
    }
    return `<div class="td-gr td-gr-mos td-gr-mos-r">${[cells[1], cells[2], cells[0]].map((c0, j) => cellHTML(c0.p, c0.idx, j === 2)).join('')}</div>`;
  }).join('');

  /* ---- NEW Timeline pane：日期 chips + 左-轴-右 layout ---- */
  /* 按天分组 */
  const tlGroups = [];
  let curDay = null, curGroup = null;
  (trip.timeline || []).forEach((n, rawIdx) => {
    if(n.day !== curDay){
      curDay = n.day;
      curGroup = { day: n.day, date: n.date, weekday: n.weekday || '', nodes: [] };
      tlGroups.push(curGroup);
    }
    curGroup.nodes.push({ ...n, rawIdx });
  });

  /* 日期字符串 → M.D 格式：'6月18日'→'6.18' */
  const fmtChipDate = (dateStr) => {
    if(!dateStr) return dateStr;
    const m = dateStr.match(/(\d+)[月\/\-](\d+)/);
    if(m) return m[1] + '.' + m[2];
    return dateStr;
  };

  /* 时间轴标题最多 8 个字：先去掉地点分隔符和空格，再硬截断。 */
  const compactTimelineTitle = (value, max = 8) => {
    const normalized = String(value || '')
      .trim()
      .replace(/\s*[·•・—–-]\s*/g, '')
      .replace(/\s+/g, '');
    return Array.from(normalized).slice(0, max).join('');
  };

  /* 图标映射：根据 tag + location 选 emoji */
  const nodeIcon = (tag, location) => {
    const t = (tag || '') + ' ' + (location || '');
    if(/飞|机场|落地|起飞|航班/.test(t)) return '✈️';
    if(/火车|列车|新干线|高铁|铁路/.test(t)) return '🚄';
    if(/车|移动|回程|返程|大巴|公路|路上/.test(t)) return '🚌';
    if(/咖啡|café|coffee|下午茶/.test(t)) return '☕';
    if(/餐|饭|食|拉面|寿司|晚餐|午餐|早餐|吃/.test(t)) return '🍜';
    if(/住|酒店|民宿|入住/.test(t)) return '🏨';
    if(/海|湾|海岸|海滩/.test(t)) return '🌊';
    if(/山|峰|缆车|上山/.test(t)) return '⛰️';
    if(/寺|神宫|庙|神社/.test(t)) return '⛩️';
    if(/美术|博物|展/.test(t)) return '🖼️';
    if(/夜|灯|霓虹|亮灯/.test(t)) return '🌃';
    if(/清晨|早|市场/.test(t)) return '🌅';
    if(/散步|路过|街|巷/.test(t)) return '🚶';
    return '📍';
  };

  /* 每个节点的右侧照片卡 */
  const cycler2 = makeChipCycler(trip);
  const nodePhotoCard = (n) => {
    const hasPhotos = n.photoCount > 0 || (n.photoIds && n.photoIds.length > 0);
    if(!hasPhotos) return '';
    const linked = n.photoIds && n.photoIds.length
      ? photos.find(photo => photo.id === n.photoIds[0])
      : null;
    const src = (linked && linked.src) || cycler2();
    const selectedPhoto = linked || photos.find(photo => photo.src === src);
    const badge = n.photoCount > 0
      ? `<span class="tl2-pill">${n.photoCount}张</span>`
      : '';
    const actionAttrs = selectedPhoto
      ? ` role="button" tabindex="0" aria-label="查看 ${esc(n.title || n.location || '时间线')} 的照片" data-photoid="${esc(selectedPhoto.id || '')}" data-photosrc="${esc(selectedPhoto.src || '')}"`
      : '';
    return `<div class="tl2-card" data-nodekey="${esc(n.key || '')}"${actionAttrs}>
      <img src="${esc(src)}" alt="" loading="lazy">
      ${badge}
    </div>`;
  };

  /* chips bar — 只显示 M.D 格式 */
  const chipsBarHTML = tlGroups.map((g, gi) =>
    `<button class="td-tl2-chip" data-daygi="${gi}">${esc(fmtChipDate(g.date))}</button>`
  ).join('');
  const chipsOverflowClass = tlGroups.length > 5 ? ' is-overflowing' : '';

  /* 按天分组渲染节点；初始只渲染/显示第 0 天 */
  const buildDayNodes = (gi, nodes, startIdx) => {
    let h = '';
    nodes.forEach((n, i) => {
      const icon = nodeIcon(`${n.category || ''} ${n.title || ''}`, n.location);
      const title = compactTimelineTitle(n.title || n.location || '旅行途中');
      h += `<div class="td-tl2-node pre" data-nidx="${startIdx+i}" data-daygi="${gi}">` +
        `<div class="tl2-axis-col"><span class="tl2-line"></span><span class="tl2-dot"></span><span class="tl2-line tl2-line-b"></span></div>` +
        `<div class="tl2-icon-wrap"><span class="tl2-icon-bg"><span class="tl2-icon-glyph">${icon}</span></span></div>` +
        `<div class="tl2-info">` +
          `<span class="tl2-time">${esc(n.time || '')}</span>` +
          `<span class="tl2-title">${esc(title)}</span>` +
          `<span class="tl2-tag">${ICON.pin}<span>${esc(n.location || n.tag || '地点待补充')}</span></span>` +
          (n.hasMemory ? '<span class="td-tl2-mem-badge">已回忆</span>' : '') +
        `</div>` +
        `<div class="tl2-photo-col">${nodePhotoCard(n)}</div>` +
      `</div>`;
    });
    return h;
  };

  let tlNodesHTML = '';
  let totalNodeIdx = 0;
  tlGroups.forEach((g, gi) => {
    const hidden = gi !== 0 ? ' hidden' : '';
    tlNodesHTML += `<div class="tl2-day-group" data-daygi="${gi}"${hidden}>${buildDayNodes(gi, g.nodes, totalNodeIdx)}</div>`;
    totalNodeIdx += g.nodes.length;
  });

  const revealOpts = S.tdReveal || {};
  const initTab = revealOpts.tab || 'moments';
  const aiStatus = trip.analysisStatus === 'processing'
    ? '<div class="td-ai-status"><span class="td-ai-spinner" aria-hidden="true"></span><span>基础时间线已生成，AI 正在后台补充场景与回忆推荐</span></div>'
    : trip.analysisStatus === 'failed'
      ? '<button class="td-ai-status td-ai-retry" id="tdAiRetry"><span>AI 精细整理暂未完成</span><b>重新分析</b></button>'
      : '';

  return el(`<section class="view td-view">
    <div class="td-hero" aria-hidden="true"><img src="${esc(cover)}" alt=""></div>
    <div class="td-head">
      <span class="td-ghost" style="font-size:min(21vw, ${(76 / (big.length * 0.654)).toFixed(2)}vw)">${esc(big)}</span>
      <span class="td-stats" id="tdStats">${stats}</span>
      <div class="td-tabs" id="tdTabs" role="tablist" aria-label="切换视图">
        <button type="button" class="${initTab === 'moments' ? 'on' : ''}" role="tab" aria-selected="${initTab === 'moments' ? 'true' : 'false'}" data-t="moments">${iGrid} Moments</button>
        <button type="button" class="${initTab === 'timeline' ? 'on' : ''}" role="tab" aria-selected="${initTab === 'timeline' ? 'true' : 'false'}" data-t="timeline">${iList} Timeline</button>
      </div>
      ${aiStatus}
    </div>
    <div class="td-body">
      <div class="td-pane" data-pane="moments"${initTab !== 'moments' ? ' hidden' : ''}>
        ${caroHTML}
        <div class="td-grid" id="tdGrid">${grid}</div>
      </div>
      <div class="td-pane td-pane-tl" data-pane="timeline"${initTab !== 'timeline' ? ' hidden' : ''}>
        <div class="td-tl2">
          <div class="td-tl2-chips${chipsOverflowClass}" id="tdTl2Chips">${chipsBarHTML}</div>
          <div class="td-tl2-nodes" id="tdTl2Nodes">${tlNodesHTML}</div>
        </div>
      </div>
    </div>
  </section>`)
  ._mount(function(){
    const self = this;
    const tabsEl = $('#tdTabs', self);
    const panes = $$('.td-pane', self);
    const aiRetry = $('#tdAiRetry', self);
    if(aiRetry) aiRetry.onclick = () => go('analyzing');

    /* tab 切换 */
    function switchTab(t){
      $$('button', tabsEl).forEach(x => {
        const on = x.dataset.t === t;
        x.classList.toggle('on', on);
        x.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      panes.forEach(p => { p.hidden = p.dataset.pane !== t; });
    }
    $$('button', tabsEl).forEach(b => b.onclick = () => switchTab(b.dataset.t));

    /* 轮播 */
    const caroEl = $('#tdCaro', self);
    if(caroEl){
      const fit = () => {
        const vw = document.documentElement.clientWidth;
        caroEl.style.marginLeft = '0px';
        caroEl.style.marginLeft = (-caroEl.getBoundingClientRect().left) + 'px';
        caroEl.style.width = vw + 'px';
      };
      fit();
      if(caroEl.children.length >= 3){
        requestAnimationFrame(() => {
          const c1 = caroEl.children[1];
          caroEl.scrollTo({ left: c1.offsetLeft - (caroEl.clientWidth - c1.offsetWidth) / 2 });
        });
      }
      let down = false, captured = false, sx = 0, sl = 0;
      caroEl.addEventListener('pointerdown', e => {
        if(e.pointerType !== 'mouse') return;
        down = true; sx = e.clientX; sl = caroEl.scrollLeft;
        captured = false;
      });
      caroEl.addEventListener('pointermove', e => {
        if(!down) return;
        const dx = e.clientX - sx;
        if(Math.abs(dx) > 6 && !captured){
          captured = true;
          caroEl.classList.add('dragging');
          caroEl.setPointerCapture(e.pointerId);
        }
        if(!captured) return;
        caroEl.scrollLeft = sl - dx;
      });
      const endDrag = () => {
        if(!down) return;
        down = false;
        captured = false;
        caroEl.classList.remove('dragging');
      };
      caroEl.addEventListener('pointerup', endDrag);
      caroEl.addEventListener('pointercancel', endDrag);
      const upd = () => {
        const crect = caroEl.getBoundingClientRect();
        const mid = crect.left + caroEl.clientWidth / 2;
        $$('.td-vc', caroEl).forEach(c => {
          const cx = crect.left + c.offsetLeft + c.offsetWidth / 2 - caroEl.scrollLeft;
          const off = Math.min(Math.abs(cx - mid) / caroEl.clientWidth, 1);
          c.style.transformOrigin = off < .04 ? '50% 50%' : (cx < mid ? '100% 50%' : '0% 50%');
          c.style.transform = `scale(${(1 - off * .075).toFixed(3)})`;
          c.style.opacity = (1 - off * .3).toFixed(3);
        });
      };
      caroEl.addEventListener('scroll', () => requestAnimationFrame(upd), { passive: true });
      window.addEventListener('resize', () => { if(!caroEl.isConnected) return; fit(); upd(); });
      upd();
      $$('.td-vc-voice', caroEl).forEach(v => v.onclick = e => {
        e.stopPropagation();
        const vc = v.closest('.td-vc');
        const card = cards[+vc.dataset.ci];
        toggleCardAudio(card, v);
      });
      $$('.td-vc', caroEl).forEach(vc => vc.onclick = e => {
        if(e.target.closest('.td-vc-voice')) return;
        const card = cards[+vc.dataset.ci];
        if(card) openPhotoDetail(trip, card, 'tripdetail');
      });
      $$('.td-vc', caroEl).forEach(vc => vc.onkeydown = e => {
        if(e.key !== 'Enter' && e.key !== ' ') return;
        if(e.target.closest('.td-vc-voice')) return;
        e.preventDefault();
        const card = cards[+vc.dataset.ci];
        if(card) openPhotoDetail(trip, card, 'tripdetail');
      });
    }

    /* Moments 与 Timeline 中的照片统一进入沉浸照片详情。 */
    $$('.td-cell', self).forEach(cell => {
      const p = photos[+cell.dataset.pi] || {};
      const act = () => openPhotoDetail(trip, p, 'tripdetail');
      cell.onclick = act;
      cell.onkeydown = e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); act(); } };
    });
    $$('.tl2-card[role="button"]', self).forEach(card => {
      const photo = photos.find(p => (card.dataset.photoid && p.id === card.dataset.photoid) || p.src === card.dataset.photosrc);
      const act = () => { if(photo) openPhotoDetail(trip, photo, 'tripdetail'); };
      card.onclick = act;
      card.onkeydown = e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); act(); } };
    });

    /* 日期 chips → 切换该天节点（不锚点滚动） */
    let revealTimers = [];
    const switchDayGi = (gi) => {
      revealTimers.forEach(id => clearTimeout(id));
      revealTimers = [];
      $$('.td-tl2-chip', self).forEach(c => c.classList.toggle('active', c.dataset.daygi === gi));
      $$('.tl2-day-group', self).forEach(g => {
        const show = g.dataset.daygi === gi;
        g.hidden = !show;
        if(show) $$('.td-tl2-node', g).forEach(n => { n.classList.remove('pre'); n.classList.add('in'); });
      });
      const nodesEl = $('#tdTl2Nodes', self);
      if(nodesEl) nodesEl.scrollTop = 0;
    };
    $$('.td-tl2-chip', self).forEach(chip => {
      chip.onclick = () => switchDayGi(chip.dataset.daygi);
    });
    /* 初始激活第一个 chip */
    const firstChip = $('.td-tl2-chip', self);
    if(firstChip) firstChip.classList.add('active');

    /* ---- Reveal 动效 ---- */
    const doReveal = S.tdReveal && S.tdReveal.reveal;
    const firstGroup = $('.tl2-day-group[data-daygi="0"]', self);
    const firstDayNodes = firstGroup ? $$('.td-tl2-node', firstGroup) : [];

    if(!doReveal){
      /* 回访：第一天节点直接全 .in */
      firstDayNodes.forEach(n => { n.classList.remove('pre'); n.classList.add('in'); });
    } else {
      /* 首次 reveal：逐个 fadeUp，完成后 600ms 弹 sheet */
      S.tdReveal = null;
      let nodeI = 0;
      function revealNext(){
        if(nodeI >= firstDayNodes.length){
          const tid = setTimeout(() => openRecordSheet(trip, self), 600);
          S.timers.push(tid);
          return;
        }
        const node = firstDayNodes[nodeI];
        node.classList.remove('pre'); node.classList.add('in');
        nodeI++;
        const tid = setTimeout(revealNext, 260);
        revealTimers.push(tid); S.timers.push(tid);
      }
      revealNext();
    }
  });
}

/* ---- 录音 Bottom Sheet（.td-sh） ---- */
function openRecordSheet(trip, viewEl, options = {}){
  /* 推荐队列：trip.moments 中未留回忆的（无 userMemory/hasMemory 标记），最多 3 个 */
  const photoSet = new Set((trip.photos || []).filter(p => p.hasMemory).map(p => p.src));
  const queue = options.moments
    ? options.moments.slice(0, 3)
    : (trip.moments || [])
      .filter(m => !m.userMemory && !photoSet.has(m.imageSrc))
      .slice(0, 3);

  if(!queue.length){
    /* 没有推荐 → 直接弹完成态 */
    showSheetDone(0, trip, viewEl);
    return;
  }

  let qIdx = 0;
  let savedCount = 0;
  let recTimer = null, recWaveT = null, recT0 = 0, recActive = false;
  let voiceSession = null, pendingVoice = null, recBusy = false;

  /* 创建 sheet DOM */
  const sheet = document.createElement('div');
  sheet.className = 'td-sh';
  sheet.innerHTML = `
    <div class="td-sh-scrim"></div>
    <div class="td-sh-panel glass-strong">
      <div class="td-sh-content" id="tdShContent"></div>
    </div>`;
  document.body.appendChild(sheet);

  /* 进入动画 */
  requestAnimationFrame(() => sheet.classList.add('open'));

  function closeSheet(){
    if(voiceSession) voiceSession.cancel();
    sheet.classList.remove('open');
    setTimeout(() => { if(sheet.parentNode) sheet.parentNode.removeChild(sheet); }, 380);
  }

  sheet.querySelector('.td-sh-scrim').onclick = () => {
    /* 不关闭 sheet（防误碰）—— 只有明确按钮才关 */
  };

  function renderIdle(m){
    const content = sheet.querySelector('#tdShContent');
    content.innerHTML = `
      <div class="td-sh-photo-wrap">
        <img class="td-sh-photo" src="${esc(m.imageSrc)}" alt="${esc(m.imageAlt || '')}">
      </div>
      <div class="td-sh-ask">${esc(m.prompt)}</div>
      <div class="td-sh-hint">按一下麦克风，记录此刻的回忆吧。</div>
      <div class="td-sh-recorder">
        <button class="td-sh-mic" id="tdShRecord" aria-label="开始录音">${ICON.mic}</button>
        <div class="td-sh-rec-state" id="tdShRecState">点击开始录音</div>
        <span class="td-sh-idle-timer" id="tdShTimer" hidden>0:00</span>
        <div class="td-sh-live-text" id="tdShLiveText" hidden></div>
      </div>
      ${options.single ? `
        <div class="td-sh-row is-single">
          <button class="td-sh-btn-ghost" id="tdShSkip">关闭</button>
        </div>` : `
        <div class="td-sh-row">
          <button class="td-sh-btn-ghost" id="tdShSkip">跳过</button>
          <button class="td-sh-btn-next" id="tdShNext">下一个 ${ICON.arrow}</button>
        </div>`}`;
    content.querySelector('#tdShRecord').onclick = () => recActive ? stopAndSave(m) : startRec(m);
    content.querySelector('#tdShSkip').onclick = advanceQueue;
    const nextButton = content.querySelector('#tdShNext');
    if(nextButton) nextButton.onclick = advanceQueue;
  }

  async function startRec(m){
    if(recBusy) return;
    recBusy = true;
    recT0 = Date.now();
    const content = sheet.querySelector('#tdShContent');
    const mic = content.querySelector('#tdShRecord');
    const state = content.querySelector('#tdShRecState');
    const timer = content.querySelector('#tdShTimer');
    const skip = content.querySelector('#tdShSkip');
    const next = content.querySelector('#tdShNext');
    state.textContent = '正在请求麦克风权限…';
    skip.disabled = true;
      if(next) next.disabled = true;
    voiceSession = createVoiceSession(text => {
      const live = content.querySelector('#tdShLiveText');
      if(!live) return;
      live.hidden = !text;
      live.textContent = text;
    }, status => {
      if(state) state.textContent = status;
    });
    try{
      await voiceSession.start();
    }catch(error){
      voiceSession = null;
      recBusy = false;
      skip.disabled = false;
      if(next) next.disabled = false;
      state.textContent = error && error.message ? error.message : '无法启动麦克风';
      state.classList.add('error');
      toast('请允许麦克风权限后重试');
      return;
    }
    recBusy = false;
    recActive = true;
    mic.classList.add('recording');
    mic.setAttribute('aria-label', '停止并保存录音');
    mic.innerHTML = '<span class="td-sh-save-label">保存</span><span class="pulse"></span><span class="pulse p2"></span>';
    state.textContent = '正在录音，完成后点击保存';
    state.classList.add('recording');
    timer.hidden = false;
    skip.disabled = true;
    next.disabled = true;

    recTimer = setInterval(() => {
      const s = Math.floor((Date.now() - recT0) / 1000);
      const el2 = content.querySelector('#tdShTimer');
      if(el2) el2.textContent = `${Math.floor(s/60)}:${pad(s%60)}`;
    }, 250);
  }

  async function stopAndSave(m){
    if(recBusy || !voiceSession) return;
    recBusy = true;
    clearInterval(recTimer); clearInterval(recWaveT);
    recActive = false;
    const content = sheet.querySelector('#tdShContent');
    const state = content && content.querySelector('#tdShRecState');
    const mic = content && content.querySelector('#tdShRecord');
    if(mic) mic.disabled = true;
    if(state) state.textContent = '正在保存录音并整理文字…';
    try{
      pendingVoice = await voiceSession.stop();
    }catch(error){
      recBusy = false;
      if(mic) mic.disabled = false;
      if(state) state.textContent = '录音保存失败，请重试';
      toast('录音保存失败');
      return;
    }
    voiceSession = null;
    recBusy = false;
    const recognized = (pendingVoice.transcript || '').trim();
    if(!recognized){
      const live = content.querySelector('#tdShLiveText');
      if(live){
        live.hidden = false;
        live.innerHTML = `<label for="tdShTranscript">录音已保存，未识别到文字，可手动补充</label><textarea class="td-sh-transcript" id="tdShTranscript" placeholder="写下刚才说的内容…"></textarea><button class="td-sh-confirm-text" id="tdShConfirmText">保存文字</button>`;
        const input = live.querySelector('#tdShTranscript');
        live.querySelector('#tdShConfirmText').onclick = () => {
          const text = input.value.trim();
          if(!text){ input.focus(); return; }
          finalizeMemory(m, pendingVoice, text);
        };
        input.focus();
      }
      if(mic){ mic.classList.remove('recording'); mic.innerHTML = ICON.check; }
      if(state) state.textContent = '原始录音已保存，请补充文字';
      return;
    }
    finalizeMemory(m, pendingVoice, recognized);
  }

  async function finalizeMemory(m, voice, text){
    m.transcript = text;
    m.userMemory = text;
    /* 生成卡片 */
    let card = { ...aiGenerateCard(m, text), source:'user-authored' };
    if(trip.cloudId && m.source === 'cloud-ai'){
      try{
        const result = await CloudAPI.saveMemory(trip, m, text, voice);
        const remote = result.card || {};
        card = { ...card, id:remote.id || card.id, title:remote.title || card.title, memory:remote.memory || text, context:remote.context || card.context, source:'cloud-ai' };
      }catch(error){
        toast(error.code === 'AI_NOT_CONFIGURED' ? 'AI 服务尚未配置，已按你的原文保存' : 'AI 整理暂时失败，已按你的原文保存');
      }
    }
    card.audioBlob = voice.blob;
    card.audioUrl = voice.url;
    card.audioDuration = voice.duration;
    card.audioMimeType = voice.mimeType;
    card.transcriptSource = voice.transcriptSource;
    const existingIndex = trip.cards.findIndex(item => item.momentId === m.id);
    if(existingIndex >= 0) trip.cards.splice(existingIndex, 1);
    trip.cards.unshift(card);
    /* 照片标记 */
    (trip.photos || []).forEach(ph => { if(ph.src === m.imageSrc) ph.hasMemory = true; });
    /* Timeline 节点标「已回忆」 */
    markTimelineMemory(trip, m, viewEl);
    /* stats textContent */
    const statsEl = document.getElementById('tdStats');
    if(statsEl) statsEl.textContent = `${tripPhotoCount(trip)} 张照片 · ${tripMemoryCount(trip)} 段回忆`;
    /* 轮播：增量插入到首位 */
    const waveHTML = n => Array.from({ length: n }, (_, i) =>
      `<i style="height:${[6, 11, 8, 14, 9, 5, 12, 7, 10, 6, 13, 8][i % 12]}px"></i>`).join('');
    const DUR2 = ['0:28', '0:19', '0:41'];
    let caroEl = document.getElementById('tdCaro');
    if(!caroEl){
      /* 首次：创建轮播容器插入 Moments pane */
      const momentsPaneEl = viewEl.querySelector('[data-pane="moments"]');
      if(momentsPaneEl){
        caroEl = document.createElement('div');
        caroEl.className = 'td-caro';
        caroEl.id = 'tdCaro';
        momentsPaneEl.insertBefore(caroEl, momentsPaneEl.firstChild);
        /* 全出血 */
        const vw = document.documentElement.clientWidth;
        caroEl.style.marginLeft = (-caroEl.getBoundingClientRect().left) + 'px';
        caroEl.style.width = vw + 'px';
      }
    }
    if(caroEl){
      const dur = card.audioDuration ? fmtDuration(card.audioDuration) : DUR2[trip.cards.length % 3];
      const newVc = document.createElement('article');
      newVc.className = 'td-vc';
      newVc.dataset.ci = '0';
      newVc.setAttribute('role', 'button');
      newVc.tabIndex = 0;
      newVc.setAttribute('aria-label', `查看回忆：${card.title}`);
      /* Shift existing ci indices */
      [...caroEl.querySelectorAll('.td-vc')].forEach((vc, i) => { vc.dataset.ci = String(i + 1); });
      newVc.innerHTML = `<img src="${esc(card.imageSrc)}" alt="${esc(card.imageAlt || '')}">
        <span class="td-vc-scrim" aria-hidden="true"></span>
        <div class="td-vc-txt"><b>${esc(card.title)}</b><p>"${esc(card.memory)}"</p></div>
        <span class="td-vc-voice"><span class="td-wave" aria-hidden="true">${waveHTML(12)}</span><em>${dur}</em></span>`;
      caroEl.insertBefore(newVc, caroEl.firstChild);
      /* voice play/pause */
      newVc.querySelector('.td-vc-voice').onclick = e => {
        e.stopPropagation();
        toggleCardAudio(card, e.currentTarget);
      };
      /* 新保存的大卡片也统一进入沉浸照片详情。 */
      newVc.onclick = e => {
        if(e.target.closest('.td-vc-voice')) return;
        openPhotoDetail(trip, card, 'tripdetail');
      };
      newVc.onkeydown = e => {
        if(e.key !== 'Enter' && e.key !== ' ') return;
        if(e.target.closest('.td-vc-voice')) return;
        e.preventDefault();
        openPhotoDetail(trip, card, 'tripdetail');
      };
    }
    savedCount++;
    Store.save(S.trips);
    if(options.onSaved) options.onSaved(card, m, voice);
    toast('回忆已保存 ✓');
    /* 保存后停留在当前照片，等待用户主动点击“下一个”。 */
    const content = sheet.querySelector('#tdShContent');
    const mic = content && content.querySelector('#tdShRecord');
    const state = content && content.querySelector('#tdShRecState');
    const next = content && content.querySelector('#tdShNext');
    if(mic){
      mic.classList.remove('recording');
      mic.classList.add('saved');
      mic.setAttribute('aria-label', '录音已保存');
      mic.innerHTML = ICON.check;
      mic.disabled = true;
    }
    if(state){
      state.textContent = options.single ? '回忆已保存' : '回忆已保存，点击“下一个”继续';
      state.classList.remove('recording');
      state.classList.add('saved');
    }
    const close = content && content.querySelector('#tdShSkip');
    if(options.single && close){ close.textContent = '完成'; close.disabled = false; }
    if(next) next.disabled = false;
  }

  function advanceQueue(){
    if(recBusy || recActive) return;
    if(voiceSession) voiceSession.cancel();
    voiceSession = null;
    clearInterval(recTimer); clearInterval(recWaveT);
    recActive = false;
    qIdx++;
    if(qIdx >= queue.length){
      if(options.single){
        closeSheet();
        if(options.onComplete) options.onComplete(savedCount);
      }else{
        showSheetDone(savedCount, trip, viewEl, closeSheet, sheet);
      }
    } else {
      renderIdle(queue[qIdx]);
    }
  }

  renderIdle(queue[0]);
}

function markTimelineMemory(trip, moment, viewEl){
  /* 在 Timeline 节点上标「已回忆」—— 适配新 tl2-card 结构 */
  const nodes = $$('.td-tl2-node', viewEl);
  nodes.forEach(nodeEl => {
    const card = nodeEl.querySelector('.tl2-card');
    const img = card && card.querySelector('img');
    if(img && img.src && moment.imageSrc && img.src.includes(moment.imageSrc.replace(/^\//, ''))){
      if(!nodeEl.querySelector('.td-tl2-mem-badge')){
        const badge = document.createElement('span');
        badge.className = 'td-tl2-mem-badge';
        badge.textContent = '已回忆';
        const info = nodeEl.querySelector('.tl2-info');
        if(info) info.appendChild(badge);
      }
    }
  });
}

function showSheetDone(savedCount, trip, viewEl, closeSheet, sheet){
  const content = sheet ? sheet.querySelector('#tdShContent') : null;
  if(!content) return;
  content.innerHTML = `
    <div class="td-sh-done-icon">✦</div>
    <div class="td-sh-done-title">已保存 ${savedCount} 段回忆</div>
    <div class="td-sh-done-sub">旅行会结束，但回忆可以再次发生。</div>
    <button class="td-sh-btn-primary" id="tdShContinue">继续看看</button>`;
  content.querySelector('#tdShContinue').onclick = () => {
    closeSheet && closeSheet();
    /* 切到 Moments tab */
    const tabsEl = document.getElementById('tdTabs');
    if(tabsEl){
      const momBtn = tabsEl.querySelector('[data-t="moments"]');
      if(momBtn) momBtn.click();
    }
  };
}

/* 从宫格照片发起「留下回忆」：为该照片即时创建 Moment 并进入录音/文字流程 */
function startPhotoMemory(trip, photo){
  const m = {
    id: uid('mm'),
    imageSrc: photo.src,
    imageAlt: photo.alt || '',
    date: photo.time || trip.startDate || '',
    location: photo.location || trip.cities || trip.destination || '旅程中',
    title: photo.location || photo.alt || '这个瞬间',
    prompt: photo.aiHint || '这一刻，发生了什么？',
    userAdded: true,
  };
  trip.moments = trip.moments || [];
  trip.moments.push(m);
  S.moments = trip.moments;
  S.pendingIdx = trip.moments.length - 1;
  S.captureReturn = document.body.dataset.view === 'photodetail' ? 'photodetail' : 'tripdetail';
  Store.save(S.trips);
  go('capture');
}

function confirmDeleteTrip(trip){
  const name = trip.name || trip.destination || '这段旅程';
  const mask = el(`<div class="modal-mask"><div class="modal glass-strong cf-modal">
    <h3 class="cf-title">删除这段旅程？</h3>
    <p class="cf-sub">“${esc(name)}”的全部照片、回忆与回音都会被移除。<br>此操作无法撤销。</p>
    <div class="cf-row">
      <button class="cf-cancel" type="button">取消</button>
      <button class="cf-del" type="button">删除</button>
    </div>
  </div></div>`);
  mask.addEventListener('click', e => { if(e.target === mask) closeModal(); });
  $('.cf-cancel', mask).onclick = closeModal;
  $('.cf-del', mask).onclick = () => {
    S.trips = S.trips.filter(t => t !== trip);
    if(S.trip === trip){ S.trip = S.trips[0] || null; S.moments = S.trip ? S.trip.moments : []; }
    Store.save(S.trips);
    closeModal();
    go('trips');
    toast('旅程已删除');
  };
  $('#modal-root').appendChild(mask);
}

function openTrip(trip){
  S.trip = trip;
  S.moments = trip.moments;
  S.idx = 0;
  S.pendingIdx = null;
  go('tripdetail');
}

/* ---------- Create / Upload ---------- */
function create(){
  const photoIco = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="4"/><circle cx="9" cy="10" r="1.6" fill="#fff" stroke="none"/><path d="M5.5 16.5l4.4-5 3.2 3.6 2.6-2.8 3 3.4"/></svg>`;
  return el(`<section class="view create-view">
    <div class="cr-head">
      <h1>选择这趟旅行的照片</h1>
      <p>时间与地点，交给照片本身来讲述。</p>
    </div>
    <div class="cr-zone" id="dz" role="button" tabindex="0" aria-label="从相册选择照片">
      <div class="cr-icon">
        <span class="cr-deco cr-deco1" aria-hidden="true"></span>
        <span class="cr-deco cr-deco2" aria-hidden="true"></span>
        <svg width="64" height="64" viewBox="0 0 48 48" fill="none" aria-hidden="true">
          <rect x="2" y="2" width="44" height="44" rx="13" fill="#fff"/>
          <circle cx="17" cy="17.5" r="3.4" fill="#12939F"/>
          <path d="M9 34.5l8.2-9.4a2.4 2.4 0 0 1 3.6-.1L27 32l4.6-4.8a2.4 2.4 0 0 1 3.4 0L41 33.5" stroke="#12939F" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <div class="cr-title">从相册选择</div>
      <div class="cr-sub">选择这次旅行的全部照片，导入后会自动识别时间、地点和行程。</div>
    </div>
    <input type="file" id="fileInput" accept="image/*" multiple hidden>
    <div class="cr-gridwrap" id="crGridWrap" hidden>
      <button class="cr-count" id="crCount" title="继续添加照片"></button>
      <div class="thumbs" id="thumbs"></div>
    </div>
    <div class="cr-bar" id="crBar" hidden>
      <span id="crInfo"></span>
      <button id="crEdit" type="button">编辑</button>
    </div>
    <div class="cr-foot">
      <button class="cr-go" id="btnAnalyze" disabled>让 EchoTrip 读懂这趟旅行 ${ICON.arrow}</button>
      <button class="cr-sample" id="sampleHint" type="button">用示例旅程先体验 →</button>
    </div>
    <div class="cr-lb" id="crLb" hidden>
      <img id="crLbImg" alt="照片预览">
      <button class="cr-lb-x" id="crLbX" aria-label="关闭预览">×</button>
    </div>
  </section>`)
  ._mount(function(){
    const zone = $('#dz', this), input = $('#fileInput', this);
    const thumbs = $('#thumbs', this), editBtn = $('#crEdit', this);
    zone.onclick = () => input.click();
    zone.onkeydown = e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); input.click(); } };
    input.onchange = () => { addFiles(input.files); input.value = ''; };
    ['dragover','dragenter'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('dz-over'); }));
    ['dragleave','drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('dz-over'); }));
    zone.addEventListener('drop', e => addFiles(e.dataTransfer.files));
    $('#crCount', this).onclick = () => input.click();
    editBtn.onclick = () => {
      const editing = !thumbs.classList.contains('editing');
      thumbs.classList.toggle('editing', editing);
      editBtn.textContent = editing ? '完成' : '编辑';
    };
    const goBtn = $('#btnAnalyze', this);
    goBtn.onclick = () => {
      if(goBtn.disabled) return;
      goBtn.disabled = true;
      startTrip('', '', S.userPhotos);
    };
    $('#sampleHint', this).onclick = () => startTrip('六月的东京', '东京 Tokyo', []);
    const lb = $('#crLb', this);
    $('#crLbX', this).onclick = () => { lb.hidden = true; };
    lb.onclick = e => { if(e.target === lb) lb.hidden = true; };
    renderCreate(this);
  });
}

async function addFiles(files){
  const imgs = [...files].filter(f => f.type && f.type.startsWith('image/'));
  for(const f of imgs){
    const photo = {
      id: uid('photo'), src: URL.createObjectURL(f), blob: f,
      name: f.name, type: f.type, size: f.size,
      time: f.lastModified ? new Date(f.lastModified) : null,
      timeSource: f.lastModified ? 'file' : null,
      location: '', alt: f.name.replace(/\.[^.]+$/, '') || '旅行照片',
    };
    S.userPhotos.push(photo);
    /* JPEG 优先使用 EXIF 拍摄时间；否则保留文件自身最后修改时间。 */
    const ex = await EXIF.read(f);
    if(ex.date){ photo.time = ex.date; photo.timeSource = 'exif'; }
    if(Number.isFinite(ex.latitude) && Number.isFinite(ex.longitude)){
      photo.latitude = ex.latitude; photo.longitude = ex.longitude; photo.altitude = ex.altitude ?? null;
      photo.locationSource = 'exif';
    }
    try{
      const bitmap = await createImageBitmap(f);
      photo.width = bitmap.width; photo.height = bitmap.height; bitmap.close();
    }catch(e){ /* 尺寸不是关键字段，不阻塞导入 */ }
  }
  resortPhotos();
  const v = $('#app .create-view'); if(v) renderCreate(v);
  if(imgs.length) toast(`已导入 ${imgs.length} 张照片`);
  const previous = S.geocodingPromise || Promise.resolve();
  S.geocodingPromise = previous.then(async () => {
    const targets = S.userPhotos.filter(photo => !photo.location && Number.isFinite(photo.latitude) && Number.isFinite(photo.longitude));
    for(const photo of targets){
      const location = await CloudAPI.reverseGeocode(photo.latitude, photo.longitude).catch(() => null);
      if(!location) continue;
      photo.location = location.locationName || '';
      photo.city = location.city || '';
      photo.country = location.country || '';
      photo.countryCode = location.countryCode || '';
      photo.locationSource = location.provider || 'reverse-geocode';
    }
    const current = $('#app .create-view'); if(current) renderCreate(current);
  }).finally(() => { S.geocodingPromise = null; });
}

function resortPhotos(){
  const dated = S.userPhotos.filter(p => p.time);
  if(dated.length >= 2){
    S.userPhotos.sort((a, b) => (a.time ? a.time.getTime() : Infinity) - (b.time ? b.time.getTime() : Infinity));
    S.sortNote = '已按拍摄时间排序';
  }else{
    S.sortNote = '已按导入顺序排列';
  }
}

function crInfoText(){
  const n = S.userPhotos.length;
  const times = S.userPhotos.filter(p => p.time).map(p => p.time.getTime());
  if(!times.length) return `${n} 张照片`;
  const p2 = x => String(x).padStart(2, '0');
  const mn = new Date(Math.min(...times)), mx = new Date(Math.max(...times));
  const f = d => `${d.getFullYear()}.${p2(d.getMonth() + 1)}.${p2(d.getDate())}`;
  const range = mn.getTime() === mx.getTime() ? f(mn)
    : `${f(mn)}–${mx.getFullYear() !== mn.getFullYear() ? f(mx) : p2(mx.getMonth() + 1) + '.' + p2(mx.getDate())}`;
  return `${n} 张照片 · ${range}`;
}

function renderCreate(view){
  if(!view) return;
  const n = S.userPhotos.length;
  const zone = $('#dz', view), input = $('#fileInput', view), wrap = $('#crGridWrap', view), bar = $('#crBar', view);
  const count = $('#crCount', view), info = $('#crInfo', view), btn = $('#btnAnalyze', view);
  const thumbs = $('#thumbs', view);
  zone.hidden = n > 0; wrap.hidden = n === 0; bar.hidden = n === 0;
  const photoIco = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="4"/><circle cx="9" cy="10" r="1.6" fill="#fff" stroke="none"/><path d="M5.5 16.5l4.4-5 3.2 3.6 2.6-2.8 3 3.4"/></svg>`;
  count.innerHTML = `${photoIco}<b>${n}</b>`;
  info.textContent = crInfoText();
  btn.disabled = n === 0;
  const hasOverflow = n > 8;
  const visiblePhotos = S.userPhotos.slice(0, hasOverflow ? 7 : 8);
  const overflowPhotos = hasOverflow ? S.userPhotos.slice(7) : [];
  const photoTiles = visiblePhotos.map((p, i) => `
    <span class="thumb thumb-photo" data-i="${i}" style="animation-delay:${Math.min(i * .03, .45)}s">
      <img src="${esc(p.src)}" alt="${esc(p.name || '')}" loading="lazy">
      <button class="thumb-remove" data-i="${i}" aria-label="移除照片">×</button>
    </span>`).join('');
  const overflowTile = hasOverflow ? `
    <button class="thumb thumb-stack" type="button" data-i="7" aria-label="查看其余 ${overflowPhotos.length} 张照片" style="animation-delay:.24s">
      <span class="thumb-stack-grid" aria-hidden="true">
        ${overflowPhotos.slice(0, 4).map(p => `<img src="${esc(p.src)}" alt="" loading="lazy">`).join('')}
      </span>
      <span class="thumb-stack-label"><b>+${overflowPhotos.length}</b><small>更多照片</small></span>
    </button>` : '';
  const addTile = `
    <button class="thumb thumb-add" type="button" aria-label="继续从相册添加照片" style="animation-delay:${Math.min((hasOverflow ? 8 : n) * .03, .45)}s">
      <span class="thumb-add-icon" aria-hidden="true">${ICON.plus}</span>
      <span>继续添加</span>
    </button>`;
  thumbs.innerHTML = photoTiles + overflowTile + addTile;
  $$('.thumb-photo', thumbs).forEach(t => t.onclick = e => {
    if(e.target.closest('.thumb-remove')) return;
    if(thumbs.classList.contains('editing')) return;
    $('#crLbImg', view).src = t.querySelector('img').src;
    $('#crLb', view).hidden = false;
  });
  const stack = $('.thumb-stack', thumbs);
  if(stack) stack.onclick = () => {
    const photo = S.userPhotos[+stack.dataset.i];
    if(!photo) return;
    $('#crLbImg', view).src = photo.src;
    $('#crLb', view).hidden = false;
  };
  $('.thumb-add', thumbs).onclick = () => input.click();
  $$('.thumb-remove', thumbs).forEach(b => b.onclick = e => {
    e.stopPropagation();
    S.userPhotos.splice(+b.dataset.i, 1);
    resortPhotos();
    renderCreate(view);
  });
}

/* ---------- Analyzing ---------- */
function analyzing(){
  const photos = (S.trip && S.trip.photos) || [];
  const cover = (S.trip && (S.trip.coverSrc || (photos[0] && photos[0].src))) || sampleSrc('p01');
  return el(`<section class="view analyzing-view">
    <div class="an-bg" aria-hidden="true"><img src="${esc(cover)}" alt=""></div>
    <div class="an-stage">
      <div class="an-orbit-zone">
        <div class="an-rings" aria-hidden="true"><span></span><span></span><span></span></div>
        <span class="an-orbit-ring" aria-hidden="true"></span>
        <div class="an-ghosts" id="anGhosts" aria-hidden="true"></div>
        <div class="an-orb"><img src="${esc(cover)}" alt=""></div>
        <div class="an-orbit" id="anOrbit"></div>
      </div>
      <div class="an-text" id="anText">正在读取照片里的时间和地点</div>
      <div class="an-progress">
        <div class="an-bar"><i id="anBar"></i></div>
        <div class="an-pct" id="anPct">0 %</div>
      </div>
      <div class="an-actions" id="anActions" hidden>
        <button class="btn btn-ghost" id="anTrips">返回 Trips</button>
        <button class="btn btn-primary" id="anRetry">重新分析</button>
        <button class="text-link" id="anFallback">先查看本地结果</button>
      </div>
      <p class="an-quote">AI 可以发现一个值得记住的瞬间，<br>但只有你知道它为什么重要。</p>
    </div>
  </section>`)
  ._mount(function(){
    const photos = (S.trip && S.trip.photos && S.trip.photos.length) ? S.trip.photos : SAMPLE_PHOTOS.slice(0, 8).map(p => ({ src: p.file }));
    const zone = $('.an-orbit-zone', this), orbit = $('#anOrbit', this), ghosts = $('#anGhosts', this);
    /* 7 张照片沿细白轨道均匀环绕（贴纸质感：白边 + 微倾斜 + 漂浮呼吸） */
    const N = Math.min(7, Math.max(5, photos.length));
    const tilt = [-6, 4, -3, 7, -5, 3, -7];
    const placed = [];
    for(let i = 0; i < N; i++){
      const p = photos[Math.floor(i * photos.length / N)] || photos[0];
      const c = el(`<span class="an-chip${i % 3 === 1 ? ' dim' : ''}"><span class="an-chip-in" style="--d:${(8 + (i % 3) * 1.7).toFixed(1)}s; --tilt:${tilt[i % 7]}deg"><img src="${esc(p.src)}" alt=""></span></span>`);
      c.__a = (i / N) * Math.PI * 2 - Math.PI / 2; c.__r = .415;
      placed.push(c); orbit.appendChild(c);
    }
    /* 景深幽灵照：轨道外围模糊低透明，暗示尚未被唤起的记忆 */
    const GA = [-2.18, -0.26, 2.62, 0.61], GR = [.63, .58, .66, .71], GS = [46, 56, 50, 44];
    GA.forEach((a, i) => {
      const p = photos[(i * 3 + 2) % photos.length] || photos[0];
      const g = el(`<span class="an-ghost"><i style="--gs:${GS[i]}px; --d:${(11 + i * 2.3).toFixed(1)}s; --tilt:${i % 2 ? 5 : -5}deg"><img src="${esc(p.src)}" alt=""></i></span>`);
      g.__a = a; g.__r = GR[i];
      placed.push(g); ghosts.appendChild(g);
    });
    const place = () => {
      const w = zone.clientWidth || 300;
      placed.forEach(c => {
        const R = c.__r * w;
        c.style.left = (w / 2 + R * Math.cos(c.__a)) + 'px';
        c.style.top = (w / 2 + R * Math.sin(c.__a)) + 'px';
      });
    };
    place();
    window.addEventListener('resize', place);
    /* 连续进度：rAF 向目标值缓动（替代跳变） */
    const text = $('#anText', this), bar = $('#anBar', this), pct = $('#anPct', this);
    let target = 0, shown = 0, raf = 0, done = false;
    const tick = () => {
      shown += (target - shown) * .055;
      if(target - shown < .25) shown = target;
      bar.style.width = shown + '%';
      pct.textContent = Math.round(shown) + ' %';
      if(!done || shown < target) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    S.cleanup = () => { done = true; cancelAnimationFrame(raf); window.removeEventListener('resize', place); };
    /* ⚠️ FUTURE AI：这里换成真实的分析 API（见 data.js aiAnalyzeTrip） */
    const trip = S.trip;
    const updateProgress = (stage, progress) => {
      if(!this.isConnected) return;
      target = Math.round(progress * 100);
      text.textContent = stage.label;
      text.classList.remove('swap'); void text.offsetWidth; text.classList.add('swap');
    };
    const analysisPromise = trip.__activeAnalysisPromise || aiAnalyzeTrip(trip, updateProgress);
    trip.__activeAnalysisPromise = analysisPromise;
    let leftForProgressiveTimeline = false, settled = false;
    const progressiveTimer = setTimeout(async () => {
      if(settled) return;
      leftForProgressiveTimeline = true;
      trip.analysisStatus = 'processing';
      await Store.save(S.trips);
      S.tdReveal = { tab:'timeline', reveal:true };
      go('tripdetail');
    }, 3000);
    analysisPromise.then(async () => {
      settled = true;
      clearTimeout(progressiveTimer);
      delete trip.__activeAnalysisPromise;
      trip.analysisStatus = 'ready';
      await Store.save(S.trips);
      if(!leftForProgressiveTimeline){
        done = true;
        S.tdReveal = { tab:'timeline', reveal:true };
        go('tripdetail');
      }else if(document.body.dataset.view === 'tripdetail' && S.trip?.id === trip.id){
        S.tdReveal = { tab:'timeline', reveal:false };
        await go('tripdetail');
        toast('AI 已完成精细整理');
      }
    }).catch(async err => {
        settled = true;
        clearTimeout(progressiveTimer);
        delete trip.__activeAnalysisPromise;
        trip.analysisStatus = 'failed';
        await Store.save(S.trips);
        if(leftForProgressiveTimeline){
          toast('已保留基础时间线，可稍后重新分析');
          return;
        }
        done = true;
        text.textContent = err.code === 'AI_NOT_CONFIGURED' ? 'AI 服务尚未配置，请添加服务端密钥' : '照片分析失败，请稍后重试';
        text.classList.add('error');
        const actions = $('#anActions', this);
        actions.hidden = false;
        $('#anTrips', this).onclick = () => go('trips');
        $('#anRetry', this).onclick = () => go('analyzing');
        $('#anFallback', this).onclick = () => {
          S.tdReveal = { tab: 'timeline', reveal: false };
          go('tripdetail');
        };
        toast(err.message || '照片分析失败');
      });
  });
}

/* ---------- Timeline ---------- */
function timeline(){
  const cycler = makeChipCycler(S.trip);
  let html = '', day = 0;
  S.trip.timeline.forEach((n, i) => {
    if(n.day !== day){
      day = n.day;
      html += `<div class="tl-day" style="animation:fadeUp .6s var(--ease-out) both ${i * .05}s"><b>Day ${n.day} · ${n.date}</b><span>${n.weekday}</span></div>`;
    }
    const chips = S.trip.usingSample
      ? n.photoIds.map(id => `<span class="tl-chip"><img src="${esc(sampleSrc(id))}" alt=""></span>`).join('')
      : Array.from({ length: Math.min(3, n.photoCount) }, () => `<span class="tl-chip"><img src="${esc(cycler())}" alt=""></span>`).join('');
    const more = n.photoCount > 3 ? `<span class="tl-more">+${n.photoCount - 3}</span>` : '';
    html += `<div class="tl-node" style="animation-delay:${i * .06}s">
      <div class="tl-time">${n.time}</div>
      <span class="tl-dot"></span>
      <div class="tl-card glass">
        <div class="tl-loc"><b>${esc(n.location)}</b><span class="tl-tag">${esc(n.tag)}</span></div>
        ${chips ? `<div class="tl-chips">${chips}${more}</div>` : ''}
      </div>
    </div>`;
  });
  return el(`<section class="view timeline-view">
    <div class="tl-wrap wrap">
      <div class="page-head">
        <span class="kicker">Timeline</span>
        <h2>这趟旅程被重新拼好了</h2>
        <div class="trip-summary">
          <span class="sum-chip">2026年6月18日 – 20日</span>
          ${S.trip.destination ? `<span class="sum-chip">${esc(S.trip.destination)}</span>` : ''}
          <span class="sum-chip">${tripPhotoCount(S.trip)} 张照片</span>
          <span class="sum-chip">「${esc(S.trip.name)}」</span>
        </div>
      </div>
      <div class="tl"><span class="tl-spark"></span>${html}</div>
      <div class="tl-foot">
        <button class="btn btn-primary btn-lg" id="toMoments">看看 AI 发现了什么 ${ICON.arrow}</button>
        <p class="create-hint" style="margin-top:14px">8 个可能值得记住的瞬间，在等你</p>
      </div>
    </div>
  </section>`)
  ._mount(function(){ $('#toMoments', this).onclick = () => go('moments'); });
}

/* ---------- Moments Deck ---------- */
function moments(){
  return el(`<section class="view moments-view">
    <div class="moments-head">
      <span class="kicker">Moments</span>
      <h2>${S.moments.filter(m => !m.userAdded).length} 个可能值得记住的瞬间</h2>
      <p class="sub">AI 挑的不是最好看的照片，而是最可能藏着回忆的那张。</p>
      ${S.trip.cards.length ? `<div style="margin-top:10px"><button class="text-link" id="peekCards">查看已生成的 ${S.trip.cards.length} 张 Memory Cards →</button></div>` : ''}
      <div class="deck-progress"><span class="num" id="deckNum"></span><div class="dots" id="deckDots"></div></div>
    </div>
    <div class="deck-stage"><div class="deck" id="deck"></div></div>
    <div class="deck-actions">
      <button class="btn btn-ghost" id="btnSkip">${ICON.skip} 跳过</button>
      <button class="btn btn-primary" id="btnRemember">${ICON.mic} 留下回忆</button>
    </div>
    <div class="add-own"><button class="text-link" id="addOwn">${ICON.plus} 我还记得另一个瞬间</button></div>
  </section>`)
  ._mount(function(){
    $('#btnSkip', this).onclick = () => fling(-1);
    $('#btnRemember', this).onclick = () => fling(1);
    $('#addOwn', this).onclick = openPicker;
    const peek = $('#peekCards', this); if(peek) peek.onclick = () => go('cards');
    renderDeck(); renderProgress();
  });
}

function deckCardHTML(m, depth){
  return `<article class="m-card ${depth > 0 ? 'behind' : ''}">
    <div class="m-photo">
      <img src="${esc(m.imageSrc)}" alt="${esc(m.imageAlt || '')}" draggable="false">
      ${depth === 0 ? '<span class="ripple-once"></span><span class="ripple-once r2"></span>' : ''}
      ${m.userAdded ? '<span class="m-badge">YOUR MOMENT</span>' : ''}
      <span class="m-like">回忆</span><span class="m-skip">跳过</span>
    </div>
    <div class="m-body">
      <h3 class="m-title">${esc(m.title)}</h3>
      <div class="m-meta">${fmtMDT(m.date)}<i></i>${esc(m.location)}</div>
      <div class="m-why"><div class="m-why-label">WHY THIS MOMENT?</div><p>${esc(m.reason)}</p></div>
      <div class="m-prompt">${esc(m.prompt)}</div>
    </div>
  </article>`;
}

function renderDeck(){
  const deck = $('#deck'); if(!deck) return;
  deck.innerHTML = '';
  for(let d = 0; d < 3 && S.idx + d < S.moments.length; d++){
    const c = el(deckCardHTML(S.moments[S.idx + d], d));
    c.style.transform = `translateY(${-d * 16}px) scale(${1 - d * .05})`;
    c.style.zIndex = String(10 - d);
    if(d === 2) c.style.filter = 'blur(1px)';
    if(d === 0){
      c.addEventListener('animationend', () => { c.style.animation = 'none'; }, { once: true });
      attachDrag(c);
    }
    deck.appendChild(c);
  }
}

function renderProgress(){
  const total = S.moments.length;
  const num = $('#deckNum'), dots = $('#deckDots');
  if(num) num.textContent = `${Math.min(S.idx + 1, total)} / ${total}`;
  if(dots) dots.innerHTML = S.moments.map((_, i) =>
    `<span class="dot ${i < S.idx ? 'done' : i === S.idx ? 'on' : ''}"></span>`).join('');
}

let flinging = false;
function fling(dir){
  if(flinging || S.idx >= S.moments.length) return;
  const deck = $('#deck'), card = deck && deck.firstElementChild;
  if(!card){ dir > 0 ? startCapture(S.moments[S.idx]) : (S.idx++, refreshDeck()); return; }
  flinging = true;
  card.style.transition = 'transform .5s cubic-bezier(.3,.6,.4,1), opacity .42s ease';
  card.style.transform = `translateX(${dir * 760}px) translateY(-26px) rotate(${dir * 15}deg)`;
  card.style.opacity = '0';
  setTimeout(() => {
    flinging = false;
    if(dir > 0) startCapture(S.moments[S.idx]);
    else { S.idx++; refreshDeck(); }
  }, 340);
}

function refreshDeck(){
  if(S.idx >= S.moments.length){ go('cards'); return; }
  renderDeck(); renderProgress();
}

function openMoments(){
  if(S.idx >= S.moments.length) go('cards');
  else go('moments');
}

/* 拖拽滑卡：右滑=留下回忆，左滑=跳过 */
function attachDrag(card){
  let sx = 0, dx = 0, dragging = false;
  const like = $('.m-like', card), skip = $('.m-skip', card);
  card.addEventListener('pointerdown', e => {
    if(flinging || e.button !== 0) return;
    if(e.target.closest('button')) return;
    dragging = true; sx = e.clientX; dx = 0;
    card.setPointerCapture(e.pointerId);
    card.classList.add('dragging');
  });
  card.addEventListener('pointermove', e => {
    if(!dragging) return;
    dx = e.clientX - sx;
    card.style.transform = `translateX(${dx}px) translateY(-6px) rotate(${dx * .055}deg)`;
    const t = Math.min(Math.abs(dx) / 110, 1);
    like.style.opacity = dx > 24 ? t : 0;
    skip.style.opacity = dx < -24 ? t : 0;
  });
  const end = () => {
    if(!dragging) return;
    dragging = false;
    card.classList.remove('dragging');
    if(Math.abs(dx) > 105){ fling(dx > 0 ? 1 : -1); }
    else{
      card.style.transform = '';
      like.style.opacity = 0; skip.style.opacity = 0;
    }
    dx = 0;
  };
  card.addEventListener('pointerup', end);
  card.addEventListener('pointercancel', end);
}

function startCapture(m){
  S.pendingIdx = S.moments.indexOf(m);
  go('capture');
}

/* ---------- Memory Capture ---------- */
function capture(){
  const m = S.moments[S.pendingIdx] || S.moments[0];
  return el(`<section class="view capture-view">
    <div class="cap-grid">
      <div class="cap-photo-wrap">
        <div class="cap-photo"><img src="${esc(m.imageSrc)}" alt="${esc(m.imageAlt || '')}"></div>
        <span class="cap-ring"></span><span class="cap-ring r2"></span>
        <div class="cap-moment-tag">${esc(m.title)} · ${esc(m.location)}</div>
      </div>
      <div class="cap-panel glass-strong">
        <span class="kicker">Memory Capture</span>
        <h1 class="cap-q">${esc(m.prompt)}</h1>
        <p class="cap-hint">说实话就好——它不需要有趣，只需要真实。</p>
        <div class="recorder" id="recorder">
          <button class="mic-btn" id="micBtn" aria-label="开始录音">${ICON.mic}</button>
          <div class="rec-state" id="recState">点击麦克风，录一段 voice memo</div>
          <div class="wave" id="wave">${'<i></i>'.repeat(26)}</div>
        </div>
        <div id="textWrap" hidden>
          <textarea class="textarea" id="memoryText" placeholder="用你自己的话，说说那一刻……"></textarea>
          <div class="cap-note" id="capNote" hidden>已按你的语气轻度整理 · 可直接修改</div>
        </div>
        <div class="mode-toggle"><button class="text-link" id="modeToggle">改用文字输入 →</button></div>
        <div class="cap-actions">
          <button class="btn btn-quiet" id="capBack">${ICON.back} 返回</button>
          <button class="btn btn-primary" id="capDone" disabled>生成 Memory Card</button>
        </div>
      </div>
    </div>
  </section>`)
  ._mount(function(){
    const micBtn = $('#micBtn', this), recState = $('#recState', this), wave = $('#wave', this);
    const textWrap = $('#textWrap', this), note = $('#capNote', this);
    const memoryText = $('#memoryText', this), done = $('#capDone', this), toggle = $('#modeToggle', this);
    let recT = null, waveT = null, t0 = 0, textMode = false;
    let recActive = false, recBusy = false, voiceSession = null, voiceResult = null;
    S.cleanup = () => {
      clearInterval(recT); clearInterval(waveT);
      if(voiceSession) voiceSession.cancel();
    };

    const updateDone = () => { done.disabled = !memoryText.value.trim(); };
    memoryText.addEventListener('input', updateDone);

    async function startRec(){
      if(recBusy) return;
      recBusy = true;
      recState.textContent = '正在请求麦克风权限…';
      voiceSession = createVoiceSession(text => {
        textWrap.hidden = false;
        memoryText.value = text;
        note.hidden = !text;
        note.textContent = text ? '正在实时转成文字 · 可继续说' : '';
        updateDone();
      }, status => {
        recState.textContent = status;
      });
      try{
        await voiceSession.start();
      }catch(error){
        voiceSession = null;
        recBusy = false;
        recState.textContent = error && error.message ? error.message : '无法启动麦克风';
        toast('请允许麦克风权限后重试');
        return;
      }
      recBusy = false;
      recActive = true;
      micBtn.classList.add('recording');
      micBtn.innerHTML = ICON.stop + '<span class="pulse"></span><span class="pulse p2"></span>';
      recState.innerHTML = '正在录音 · 再次点击结束　<span class="rec-timer" id="recTimer">0:00</span>';
      wave.style.display = '';
      t0 = Date.now();
      recT = setInterval(() => {
        const s = Math.floor((Date.now() - t0) / 1000), t = $('#recTimer');
        if(t) t.textContent = `${Math.floor(s / 60)}:${pad(s % 60)}`;
      }, 250);
      waveT = setInterval(() => { $$('i', wave).forEach(b => { b.style.height = (5 + Math.random() * 32) + 'px'; }); }, 105);
    }

    async function stopRec(){
      if(recBusy || !voiceSession) return;
      recBusy = true;
      recActive = false;
      micBtn.classList.remove('recording');
      micBtn.disabled = true;
      clearInterval(recT); clearInterval(waveT);
      wave.style.display = 'none';
      recState.innerHTML = '<span class="transcribing">正在保存录音并整理文字<span class="dots3"><i></i><i></i><i></i></span></span>';
      try{
        voiceResult = await voiceSession.stop();
      }catch(error){
        recBusy = false;
        micBtn.disabled = false;
        micBtn.innerHTML = ICON.mic;
        recState.textContent = '录音保存失败，请重试';
        return;
      }
      voiceSession = null;
      recBusy = false;
      micBtn.disabled = false;
      micBtn.innerHTML = ICON.check;
      textWrap.hidden = false;
      const text = (voiceResult.transcript || memoryText.value || '').trim();
      memoryText.value = text;
      note.hidden = false;
      note.textContent = text ? '录音已保存并转成文字 · 可直接修改' : '录音已保存，未识别到文字，请手动补充';
      recState.textContent = text ? '录音与文字已保存' : '原始录音已保存';
      updateDone();
      if(!text) memoryText.focus();
    }

    micBtn.onclick = () => recActive ? stopRec() : startRec();

    toggle.onclick = () => {
      if(recBusy || recActive) return;
      textMode = !textMode;
      $('#recorder', this).hidden = textMode;
      if(textMode){
        textWrap.hidden = false;
        toggle.textContent = '← 使用语音输入';
        memoryText.focus();
      }else{
        toggle.textContent = '改用文字输入 →';
      }
    };

    if(S.captureReturn === 'tripdetail' || S.captureReturn === 'photodetail'){
      const returnView = S.captureReturn;
      const backTd = () => { S.captureReturn = null; go(returnView); };
      $('#capBack', this).onclick = backTd;
      setTimeout(() => { const b = $('#backBtn'); if(b) b.onclick = backTd; });
    }else{
      $('#capBack', this).onclick = () => openMoments();
    }
    done.onclick = async () => {
      const text = memoryText.value.trim();
      if(!text) return;
      done.disabled = true;
      done.textContent = 'AI 正在整理…';
      /* 状态联动：对应照片右上角变为「已回忆」 */
      (S.trip.photos || []).forEach(ph => { if(ph.src === m.imageSrc) ph.hasMemory = true; });
      let card = { ...aiGenerateCard(m, text), source:'user-authored' };
      if(S.trip.cloudId && m.source === 'cloud-ai'){
        try{
          const result = await CloudAPI.saveMemory(S.trip, m, text, voiceResult);
          const remote = result.card || {};
          card = {
            ...card,
            id:remote.id || card.id,
            title:remote.title || card.title,
            memory:remote.memory || text,
            context:remote.context || card.context,
            source:'cloud-ai',
            transcriptSource:remote.transcriptSource || voiceResult?.transcriptSource || 'user-text',
          };
        }catch(error){
          toast(error.code === 'AI_NOT_CONFIGURED' ? 'AI 服务尚未配置，已按你的原文保存' : 'AI 整理暂时失败，已按你的原文保存');
        }
      }
      m.transcript = text;
      m.userMemory = text;
      if(voiceResult){
        card.audioBlob = voiceResult.blob;
        card.audioUrl = voiceResult.url;
        card.audioDuration = voiceResult.duration;
        card.audioMimeType = voiceResult.mimeType;
        card.transcriptSource = voiceResult.transcriptSource;
      }
      const cards = S.trip.cards;
      const exist = cards.findIndex(c => c.momentId === m.id);
      if(exist >= 0) cards[exist] = card; else cards.push(card);
      if(!m.userAdded) S.idx = S.pendingIdx + 1;
      S.pendingIdx = null;
      Store.save(S.trips);
      showGenOverlay(m, () => go('cardpreview', { card }));
    };
  });
}

function showGenOverlay(moment, cb){
  const ov = el(`<div class="gen-overlay"><div class="gen-core">
    <div class="gen-rings"><span></span><span></span><span></span></div>
    <div class="gen-photo"><img src="${esc(moment.imageSrc)}" alt=""></div>
    <div class="gen-caption">正在把这段话，变成一件小小的记忆物…</div>
  </div></div>`);
  document.body.appendChild(ov);
  setTimeout(() => { ov.remove(); cb(); }, 1600);
}

/* ---------- Memory Card（复用组件） ---------- */
function memCardHTML(card, extraCls = ''){
  return `<article class="mem-card ${extraCls}">
    <div class="mc-photo"><img src="${esc(card.imageSrc)}" alt="${esc(card.imageAlt || '')}"></div>
    <div class="mc-body">
      <h3 class="mc-title">${esc(card.title)}</h3>
      <p class="mc-memory">${esc(card.memory)}</p>
      <div class="mc-meta">${fmtMD(card.date)}<i></i>${esc(card.location)}</div>
      ${card.context ? `<div class="mc-context">${esc(card.context)}</div>` : ''}
    </div>
  </article>`;
}

/* ---------- Card Preview（生成后的全屏时刻） ---------- */
function cardpreview({ card }){
  return el(`<section class="view cardpreview-view">
    <div class="pv-stage">
      <div class="pv-wrap">
        <span class="echo-ring"></span><span class="echo-ring r2"></span><span class="echo-ring r3"></span>
        ${memCardHTML(card, 'surface')}
      </div>
      <div class="pv-caption"><b>这张记忆已经被保存</b><p>它会在未来某一天，重新回到你身边。</p></div>
      <div class="pv-actions">
        <button class="btn btn-ghost" id="pvContinue">继续发现瞬间</button>
        <button class="btn btn-primary" id="pvCards">查看 Memory Cards</button>
      </div>
    </div>
  </section>`)
  ._mount(function(){
    const backTarget = S.captureReturn === 'photodetail' ? 'photodetail'
      : ((S.captureReturn === 'tripdetail' || S.pvReturn === 'tripdetail') ? 'tripdetail' : '');
    const backTd = !!backTarget;
    if(backTd){
      const back = () => { S.captureReturn = S.pvReturn = null; go(backTarget); };
      const btn = $('#pvContinue', this);
      btn.textContent = backTarget === 'photodetail' ? '回到照片' : '回到这趟旅程';
      btn.onclick = back;
      setTimeout(() => { const b = $('#backBtn'); if(b) b.onclick = back; });
    }else{
      $('#pvContinue', this).onclick = () => openMoments();
    }
    $('#pvCards', this).onclick = () => go('cards');
  });
}

/* ---------- Memory Cards Gallery ---------- */
function cards(){
  const cardList = (S.trip && S.trip.cards) || [];
  if(!cardList.length){
    return el(`<section class="view cards-view">
      <div class="empty">
        <div class="empty-art">${ICON.camera}</div>
        <h3>你还没有留下任何回忆</h3>
        <p>那些瞬间还在等你。只挑一个说说话就好——<br>它不需要有趣，只需要真实。</p>
        <button class="btn btn-primary" id="backToMoments">回到那些瞬间</button>
      </div>
    </section>`)
    ._mount(function(){ $('#backToMoments', this).onclick = () => { S.idx = Math.min(S.idx, S.moments.length - 1); openMoments(); }; });
  }
  return el(`<section class="view cards-view">
    <div class="cards-head">
      <span class="kicker">Memory Cards</span>
      <h2>你的 Memory Cards</h2>
      <div class="count-chip"><i></i>${cardList.length} 张被好好收起的回忆</div>
    </div>
    <div class="carousel">
      <button class="car-btn prev" aria-label="上一张">${ICON.chevL}</button>
      <div class="car-track" id="carTrack">
        ${cardList.map((c, i) => memCardHTML(c).replace('class="mem-card"', `class="mem-card" role="button" tabindex="0" data-ci="${i}" aria-label="查看回忆：${esc(c.title)}" style="animation-delay:${i * .08}s"`)).join('')}
      </div>
      <button class="car-btn next" aria-label="下一张">${ICON.chevR}</button>
    </div>
    <div class="cards-foot">
      <button class="btn btn-primary btn-lg" id="toEcho">看看今天的回音 ${ICON.arrow}</button>
      <p class="hint">旅行会结束，但回忆可以再次发生。</p>
    </div>
  </section>`)
  ._mount(function(){
    const track = $('#carTrack', this);
    $('.car-btn.prev', this).onclick = () => track.scrollBy({ left: -420, behavior: 'smooth' });
    $('.car-btn.next', this).onclick = () => track.scrollBy({ left: 420, behavior: 'smooth' });
    /* 鼠标拖拽滑动（触屏走原生滚动） */
    let down = false, sx = 0, sl = 0;
    track.addEventListener('pointerdown', e => {
      if(e.pointerType !== 'mouse') return;
      down = true; sx = e.clientX; sl = track.scrollLeft; track.setPointerCapture(e.pointerId);
    });
    track.addEventListener('pointermove', e => { if(down) track.scrollLeft = sl - (e.clientX - sx); });
    track.addEventListener('pointerup', () => { down = false; });
    track.addEventListener('pointercancel', () => { down = false; });
    $$('.mem-card[role="button"]', track).forEach(card => {
      const act = () => {
        const memory = cardList[+card.dataset.ci];
        if(memory) openPhotoDetail(S.trip, memory, 'cards');
      };
      card.onclick = act;
      card.onkeydown = e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); act(); } };
    });
    $('#toEcho', this).onclick = () => go('echohome');
  });
}

/* ---------- 「我还记得另一个瞬间」照片选择器 ---------- */
function openPicker(){
  const used = new Set(S.moments.map(m => m.imageSrc));
  const pool = [
    ...S.trip.photos.filter(p => p.src && !used.has(p.src))
      .map(p => ({ src: p.src, time: p.time || null, location: p.location || '旅途中', alt: p.alt || p.name || '你拍的照片' })),
    ...SAMPLE_PHOTOS.filter(p => !used.has(p.file))
      .map(p => ({ src: p.file, time: p.time, location: p.location, alt: p.alt })),
  ];
  const mask = el(`<div class="modal-mask"><div class="modal glass-strong">
    <h3 class="modal-title">我还记得另一个瞬间</h3>
    <p class="modal-sub">AI 负责发现，但你拥有最终决定权。<br>挑一张只有你自己知道为什么的照片。</p>
    <div class="picker-grid">
      ${pool.map((p, i) => `<button class="pick-tile" data-i="${i}"><img src="${esc(p.src)}" alt="${esc(p.alt)}"><span class="pt-cap">${esc(p.alt)}</span></button>`).join('')}
    </div>
    ${pool.length ? '' : '<div class="picker-empty">所有照片都已经被挑过了。</div>'}
    <div class="picker-foot" id="pickerFoot" hidden>
      <input class="input" id="umTitle" placeholder="给这个瞬间起个名字（可留空）" style="flex:1;min-width:200px" maxlength="20">
      <button class="btn btn-primary" id="umGo">${ICON.mic} 留下回忆</button>
    </div>
    <div class="picker-foot"><button class="btn btn-quiet" id="pickerClose">取消</button></div>
  </div></div>`);

  let sel = -1;
  $$('.pick-tile', mask).forEach(t => t.onclick = () => {
    $$('.pick-tile', mask).forEach(x => x.classList.remove('selected'));
    t.classList.add('selected');
    sel = +t.dataset.i;
    $('#pickerFoot', mask).hidden = false;
    $('#umTitle', mask).focus();
  });
  $('#umGo', mask).onclick = () => {
    if(sel < 0) return;
    const p = pool[sel];
    const title = $('#umTitle', mask).value.trim() || '我的瞬间';
    const dateIso = p.time ? (p.time instanceof Date ? toIso(p.time) : p.time) : null;
    S.moments.push({
      id: uid('um'), userAdded: true,
      imageSrc: p.src, imageAlt: p.alt,
      date: dateIso, location: p.location,
      title,
      reason: '这是你自己选出来的瞬间。AI 把解释权，留给你。',
      prompt: '关于这张照片，你还记得什么？',
      transcript: '', tidied: '',
      cardTitle: title, context: '',
    });
    Store.save(S.trips);
    closeModal();
    toast('已加入你的瞬间');
    S.pendingIdx = S.moments.length - 1;
    go('capture');
  };
  $('#pickerClose', mask).onclick = closeModal;
  mask.addEventListener('click', e => { if(e.target === mask) closeModal(); });
  $('#modal-root').appendChild(mask);
}
function closeModal(){ $('#modal-root').innerHTML = ''; }

/* ---------- toast ---------- */
function toast(msg){
  const t = el(`<div class="toast">${ICON.check}<span>${esc(msg)}</span></div>`);
  $('#toast-root').appendChild(t);
  setTimeout(() => t.remove(), 2900);
}

async function enrichStoredTripLocations(trip){
  const targets = (trip.photos || []).filter(photo => !photo.location && Number.isFinite(photo.latitude) && Number.isFinite(photo.longitude));
  let changed = false;
  for(const photo of targets){
    const location = await CloudAPI.reverseGeocode(photo.latitude, photo.longitude).catch(() => null);
    if(!location) continue;
    photo.location = location.locationName || '';
    photo.city = location.city || '';
    photo.country = location.country || '';
    photo.countryCode = location.countryCode || '';
    photo.locationSource = location.provider || 'reverse-geocode';
    changed = true;
  }
  if(!changed) return false;
  refreshTripGeography(trip);
  const photosById = new Map((trip.photos || []).map(photo => [photo.id, photo]));
  (trip.timeline || []).forEach(node => {
    const representative = (node.photoIds || []).map(photoId => photosById.get(photoId)).find(photo => photo?.location);
    if(representative && (!node.location || /待补充|未识别/.test(node.location))) node.location = representative.location;
  });
  return true;
}

/* ---------- trip 启动 ---------- */
function startTrip(name, dest, userPhotos){
  const trip = normalizeTripData(buildTrip(name, dest, userPhotos));
  trip.analysisStatus = userPhotos && userPhotos.length ? 'processing' : 'ready';
  if(userPhotos && userPhotos.length){
    trip.__cloudSyncPromise = CloudAPI.createAndUploadTrip(trip, progress => {
      trip.cloudUploadProgress = progress;
    });
  }
  S.trips.unshift(trip);   // 新旅程排在 Trips 首页最前
  S.trip = trip;
  S.moments = trip.moments;
  S.idx = 0;
  S.pendingIdx = null;
  Store.save(S.trips);
  S.userPhotos = [];
  go('analyzing');
}

/* ---------- 路由（单页状态机） ---------- */
const STEPS = {
  timeline: '发现 · DISCOVER',
  moments: '发现 · MOMENTS', capture: '记住 · REMEMBER', cardpreview: '记住 · REMEMBER',
  cards: '记住 · REMEMBER',
};
const DOCK_VIEWS = ['echohome', 'trips', 'cards'];

async function go(view, params = {}){
  S.prevView = document.body.dataset.view || S.prevView || '';
  if(S.cleanup){ S.cleanup(); S.cleanup = null; }
  S.timers.forEach(clearTimeout); S.timers = [];
  const app = $('#app');
  const old = app.firstElementChild;
  if(old){ old.classList.add('view-out'); await wait(190); }
  app.innerHTML = '';
  const v = RENDER[view](params);
  app.appendChild(v);
  if(typeof v.__mount === 'function') v.__mount.call(v);
  requestAnimationFrame(() => v.classList.add('view-in'));
  window.scrollTo({ top: 0 });
  if(view !== 'echohome') FX.setMode('normal');
  /* 新 IA：body 标记当前视图（CSS 据此切换氛围），Dock 只在两个首页 + Cards 显示 */
  document.body.dataset.view = view;
  document.body.classList.toggle('show-dock', DOCK_VIEWS.includes(view));
  $$('#dock .dock-item').forEach(b => b.classList.toggle('on', b.dataset.nav === view));
  /* 顶部返回导航：子页面显示返回键（记住来路），两个首页隐藏 */
  const BACK = {
    create: (S.prevView === 'echohome' ? 'echohome' : 'trips'),
    tripdetail: 'trips',
    timeline: 'trips', moments: 'timeline', capture: 'moments',
    photodetail: (S.photoDetail && S.photoDetail.backView) || 'tripdetail',
    cardpreview: 'capture', cards: 'moments',
  };
  const backBtn = $('#backBtn');
  if(BACK[view]){ backBtn.hidden = false; backBtn.onclick = () => go(BACK[view]); }
  else backBtn.hidden = true;
  const pill = $('#step-pill');
  if(STEPS[view]){ pill.hidden = false; pill.textContent = STEPS[view]; }
  else pill.hidden = true;
}

/* 元素挂载约定：el(...)._mount(fn) 注册挂载逻辑，go() 在 append 后统一调用 */
Element.prototype._mount = function(fn){ this.__mount = fn; return this; };

/* ---------- init ---------- */
document.addEventListener('DOMContentLoaded', async () => {
  FX.initBackground();
  /* 恢复历史旅程；首次访问用示例旅程 + 3 张已写好的回忆卡播种 */
  const savedTrips = await Store.load();
  S.trips = (savedTrips || [seedJapanTrip(), seedSerbiaTrip(), seedAustraliaTrip()]).map(trip => {
    normalizeTripData(trip);
    /* v2 会按拍摄日期、相邻时间、GPS 距离和地点共同聚类；自动修复旧版过度合并的真实旅程。 */
    if(!trip.sample && !trip.usingSample && trip.photos.length && trip.timelineAlgorithmVersion !== 4){
      trip.timeline = buildRealTimeline(trip.photos);
      trip.timelineAlgorithmVersion = 4;
      refreshTripGeography(trip);
      normalizeTripData(trip);
    }
    return trip;
  });
  if(!S.trip) S.trip = S.trips[0];
  S.moments = S.trip ? S.trip.moments : [];
  Store.save(S.trips);
  Promise.all(S.trips.map(enrichStoredTripLocations)).then(results => {
    if(results.some(Boolean)) Store.save(S.trips);
  }).catch(() => null);
  /* 按压涟漪（回音母题的微交互） */
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn, .pick-tile, .mic-btn');
    if(b && !b.disabled) FX.spawnRipple(b, e);
  });
  /* 双 Tab 导航 */
  $$('#dock .dock-item').forEach(b => b.onclick = () => go(b.dataset.nav));
  go('echohome');
});

})();
