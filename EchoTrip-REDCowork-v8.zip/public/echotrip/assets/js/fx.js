/* ============================================================
   EchoTrip · fx.js
   背景流体（Liquid Glass 的"空气感"来源）+ 回音涟漪微交互
   ============================================================ */

const FX = (() => {

  let canvas, ctx, W, H, blobs = [], last = 0;

  const PALETTES = {
    normal: [
      'rgba(127,207,210,.42)',   // aqua
      'rgba(169,219,208,.48)',   // seafoam
      'rgba(214,233,236,.55)',   // mist
      'rgba(147,180,205,.30)',   // mist blue
      'rgba(242,160,107,.12)',   // 一点点暖色
      'rgba(127,207,210,.20)',
    ],
    echo: [
      'rgba(120,168,178,.40)',
      'rgba(132,160,172,.38)',
      'rgba(196,216,222,.5)',
      'rgba(105,138,160,.32)',
      'rgba(242,160,107,.10)',
      'rgba(140,170,182,.24)',
    ],
  };

  function initBackground(){
    canvas = document.getElementById('bg');
    if(!canvas) return;
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
    blobs = PALETTES.normal.map((c, i) => ({
      c, r: .24 + .13 * (i % 3), sp: .00006 * (1 + i * 2.2),
      ph: i * 1.71, ox: .16 * i, oy: .13 * i,
    }));
    requestAnimationFrame(loop);
  }

  function resize(){
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function loop(t){
    requestAnimationFrame(loop);
    if(t - last < 33) return; // ~30fps 足够，省电
    last = t;
    ctx.clearRect(0, 0, W, H);
    for(const b of blobs){
      const x = W * (.5 + .44 * Math.sin(t * b.sp + b.ph + b.ox));
      const y = H * (.5 + .42 * Math.cos(t * b.sp * .8 + b.ph * 1.3 + b.oy));
      const r = Math.max(W, H) * b.r;
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, b.c);
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
    }
  }

  /* Echo 页面切换到更"雨雾"的背景情绪 */
  function setMode(mode){
    const p = PALETTES[mode] || PALETTES.normal;
    blobs.forEach((b, i) => { b.c = p[i % p.length]; });
  }

  /* 按压涟漪：在按钮等元素内产生一圈扩散环（回音母题） */
  function spawnRipple(host, e){
    if(!host) return;
    const rect = host.getBoundingClientRect();
    const el = document.createElement('span');
    el.className = 'fx-ripple';
    const x = (e && e.clientX != null ? e.clientX : rect.left + rect.width / 2) - rect.left;
    const y = (e && e.clientY != null ? e.clientY : rect.top + rect.height / 2) - rect.top;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    host.appendChild(el);
    setTimeout(() => el.remove(), 750);
  }

  return { initBackground, setMode, spawnRipple };
})();
