export default function Prototype() {
  return (
    <main className="echotrip-device-screen" aria-label="EchoTrip interactive prototype">
      <iframe
        className="echotrip-device-app"
        src="/echotrip/index.html?device-preview=1&build=117"
        title="EchoTrip"
        allow="microphone; camera; on-device-speech-recognition"
      />
    </main>
  );
}
