# Photo Detail Lightweight Memory — Design QA

## Evidence

- Current photo-detail references: `codex-clipboard-21f246ff-bd36-478c-a0ef-f9f5afadc4b7.png` and `codex-clipboard-5a16271c-1445-4164-8f56-74a6ffb2c927.png`.
- Existing recording-sheet references: `codex-clipboard-1a60fd63-608e-444b-ba13-59b042443829.png` and `codex-clipboard-1239f782-19b9-48ae-b515-62b4bd18cbaa.png`.
- Browser-rendered implementation: `http://127.0.0.1:4174/`, Codex in-app browser tab 2; full-screen captures were emitted inline during this QA pass.
- States compared: no-memory photo detail, saved-memory photo detail, no-memory recording sheet, and supplement-memory recording sheet.

## Findings and Corrections

- P2 — The former glass card concealed too much of the photo. Reduced the glass fill opacity, blur, saturation, border prominence, and shadow density while keeping text contrast readable.
- P2 — The no-memory card was unnecessarily tall because of a full-width CTA. Replaced it with a 44 px glass microphone control in the upper-right and reduced that card to 142 px tall.
- P1 — “开始回忆” previously navigated away to a separate capture route. It now opens the established recording bottom sheet over the selected photo detail, preserving context and the thumbnail rail beneath the scrim.
- P1 — “补充回忆” now uses the same sheet architecture and the same real recording/transcription pipeline.
- No remaining P0, P1, or P2 visual or interaction differences were found for this request.

## Primary Interactions Tested

- Trips → Trip Card → Moments → no-memory photo detail.
- No-memory thumbnail selection synchronizes the full-screen photo, card content, and selected thumbnail.
- Upper-right microphone opens the existing bottom sheet without changing route.
- Closing the sheet returns to the same selected photo.
- Saved-memory thumbnail restores the voice-player state.
- “补充回忆” opens the same bottom sheet.
- Sheet layering sits above the photo-detail back button and card, with the background visibly blurred beneath it.

## Runtime Checks

- `node --check public/echotrip/assets/js/app-v54.js`: passed.
- `npm run check:runtime`: passed.
- `npm run test:sites`: 6/6 passed.
- `npm run build`: passed.
- Browser console: no new application errors. Only CDN response-length warnings from the local Transformers.js dependency were present.

final result: passed
